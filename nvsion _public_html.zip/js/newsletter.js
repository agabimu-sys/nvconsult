// NVConsult Newsletter & Push Notifications — Production Grade
(function () {
    'use strict';

    var NOTIFICATION_PROMPT_KEY = 'nv_notif_prompted';
    var NOTIFICATION_GRANTED_KEY = 'nv_notif_granted';
    var LAST_POST_SEEN_KEY = 'nv_last_post_seen';
    var NEW_POST_KEY = 'nv_new_post';
    var PROMPT_DELAY = 8000; // 8 seconds after page load

    // ─── Newsletter Subscription ───
    function initNewsletter() {
        document.querySelectorAll('.footer-item .btn-primary, .newsletter-subscribe-btn').forEach(function (btn) {
            var parent = btn.closest('.position-relative') || btn.closest('.footer-item');
            if (!parent) return;
            var input = parent.querySelector('input[type="text"], input[type="email"]');
            if (!input) return;

            btn.addEventListener('click', function (e) {
                e.preventDefault();
                var email = input.value.trim();
                if (!email || !isValidEmail(email)) {
                    showToast('Invalid Email', 'Please enter a valid email address.', 'error');
                    return;
                }

                var subs = JSON.parse(localStorage.getItem('nv_newsletter_subs') || '[]');
                if (subs.find(function (s) { return s.email === email; })) {
                    showToast('Already Subscribed', 'This email is already subscribed to our newsletter.', 'info');
                    input.value = '';
                    return;
                }

                subs.push({
                    email: email,
                    date: new Date().toISOString().split('T')[0],
                    notificationsEnabled: false
                });
                localStorage.setItem('nv_newsletter_subs', JSON.stringify(subs));

                input.value = '';
                showToast('Subscribed! ✅', 'You\'ve been added to our newsletter. Stay tuned for updates!', 'success');

                // If notifications not yet granted, prompt now
                if ('Notification' in window && Notification.permission === 'default') {
                    setTimeout(function () {
                        showNotificationPrompt(email);
                    }, 2000);
                } else if ('Notification' in window && Notification.permission === 'granted') {
                    updateSubNotification(email, true);
                    registerServiceWorker();
                }
            });
        });
    }

    // ─── First-Visit Notification Prompt ───
    function showFirstVisitPrompt() {
        // Skip admin page
        if (window.location.pathname.indexOf('admin') !== -1) return;

        // Skip if already prompted this session or permission already decided
        if (sessionStorage.getItem(NOTIFICATION_PROMPT_KEY)) return;
        if (!('Notification' in window)) return;
        if (Notification.permission !== 'default') {
            if (Notification.permission === 'granted') registerServiceWorker();
            return;
        }

        // Check if user was previously prompted (don't spam on every visit)
        var promptCount = parseInt(localStorage.getItem('nv_notif_prompt_count') || '0');
        var lastPrompt = parseInt(localStorage.getItem('nv_notif_last_prompt') || '0');
        var daysSincePrompt = (Date.now() - lastPrompt) / (1000 * 60 * 60 * 24);

        // Only re-prompt if: never prompted, or 7+ days since last prompt, max 3 times
        if (promptCount > 0 && (daysSincePrompt < 7 || promptCount >= 3)) {
            sessionStorage.setItem(NOTIFICATION_PROMPT_KEY, '1');
            return;
        }

        setTimeout(function () {
            sessionStorage.setItem(NOTIFICATION_PROMPT_KEY, '1');
            showNotificationBanner();
        }, PROMPT_DELAY);
    }

    // ─── Notification Permission Banner (first visit) ───
    function showNotificationBanner() {
        // Don't show if already showing
        if (document.getElementById('nv-notif-banner')) return;

        var banner = document.createElement('div');
        banner.id = 'nv-notif-banner';
        banner.style.cssText = 'position:fixed;bottom:24px;left:50%;transform:translateX(-50%) translateY(120px);z-index:99999;' +
            'background:linear-gradient(135deg,#0B3C5D,#145580);color:#fff;padding:20px 28px;border-radius:16px;' +
            'box-shadow:0 12px 48px rgba(0,0,0,0.25);max-width:420px;width:90%;font-family:Inter,Poppins,sans-serif;' +
            'transition:transform 0.5s cubic-bezier(0.34,1.56,0.64,1);';

        banner.innerHTML =
            '<div style="display:flex;align-items:flex-start;gap:14px;">' +
                '<div style="font-size:2rem;line-height:1;">🔔</div>' +
                '<div style="flex:1;">' +
                    '<h6 style="margin:0 0 6px;font-weight:700;font-size:1rem;color:#fff;">Stay Updated!</h6>' +
                    '<p style="margin:0 0 14px;font-size:0.88rem;color:rgba(255,255,255,0.8);line-height:1.5;">Get notified about new visa updates, blog posts, and immigration news from NVConsult.</p>' +
                    '<div style="display:flex;gap:10px;">' +
                        '<button id="nv-notif-enable" style="background:#F59E0B;color:#fff;border:none;padding:8px 20px;border-radius:50px;font-weight:600;font-size:0.88rem;cursor:pointer;transition:background 0.2s;">Enable Notifications</button>' +
                        '<button id="nv-notif-dismiss" style="background:transparent;color:rgba(255,255,255,0.6);border:1px solid rgba(255,255,255,0.2);padding:8px 16px;border-radius:50px;font-size:0.85rem;cursor:pointer;transition:all 0.2s;">Not Now</button>' +
                    '</div>' +
                '</div>' +
                '<button id="nv-notif-close" style="background:none;border:none;color:rgba(255,255,255,0.5);font-size:1.3rem;cursor:pointer;padding:0;line-height:1;">&times;</button>' +
            '</div>';

        document.body.appendChild(banner);

        // Animate in
        setTimeout(function () {
            banner.style.transform = 'translateX(-50%) translateY(0)';
        }, 100);

        // Enable button
        document.getElementById('nv-notif-enable').addEventListener('click', function () {
            Notification.requestPermission().then(function (permission) {
                if (permission === 'granted') {
                    localStorage.setItem(NOTIFICATION_GRANTED_KEY, '1');
                    registerServiceWorker();
                    showToast('Notifications Enabled! 🎉', 'You\'ll receive updates about new posts and visa news.', 'success');

                    // Send a test device notification immediately
                    try {
                        var iconUrl = window.location.href.replace(/[^/]*$/, '') + 'img/about-2.png';
                        var testNotif = new Notification('✅ NVConsult Notifications Enabled', {
                            body: 'You will now receive updates about new posts, visa news, and immigration tips.',
                            icon: iconUrl,
                            tag: 'nv-welcome-' + Date.now(),
                            requireInteraction: true
                        });
                        testNotif.onclick = function () {
                            window.focus();
                            testNotif.close();
                        };
                    } catch (e) { console.warn('Test notification failed:', e); }

                    // If user has newsletter sub, update it
                    var subs = JSON.parse(localStorage.getItem('nv_newsletter_subs') || '[]');
                    if (subs.length > 0) {
                        subs[subs.length - 1].notificationsEnabled = true;
                        localStorage.setItem('nv_newsletter_subs', JSON.stringify(subs));
                    }
                }
                closeBanner(banner);
            });
            updatePromptCount();
        });

        // Dismiss button
        document.getElementById('nv-notif-dismiss').addEventListener('click', function () {
            closeBanner(banner);
            updatePromptCount();
        });

        // Close X
        document.getElementById('nv-notif-close').addEventListener('click', function () {
            closeBanner(banner);
            updatePromptCount();
        });
    }

    function closeBanner(banner) {
        banner.style.transform = 'translateX(-50%) translateY(120px)';
        setTimeout(function () { banner.remove(); }, 500);
    }

    function updatePromptCount() {
        var count = parseInt(localStorage.getItem('nv_notif_prompt_count') || '0');
        localStorage.setItem('nv_notif_prompt_count', (count + 1).toString());
        localStorage.setItem('nv_notif_last_prompt', Date.now().toString());
    }

    // ─── Notification Prompt for Newsletter Subscribers ───
    function showNotificationPrompt(email) {
        if (!('Notification' in window) || Notification.permission !== 'default') return;

        showToast(
            '🔔 Enable Notifications?',
            'Get notified when we publish new posts and immigration updates. <a href="#" id="enable-notif-btn" style="color:#F59E0B;font-weight:600;">Enable Notifications</a>',
            'info',
            12000
        );

        setTimeout(function () {
            var enableBtn = document.getElementById('enable-notif-btn');
            if (enableBtn) {
                enableBtn.addEventListener('click', function (e) {
                    e.preventDefault();
                    Notification.requestPermission().then(function (permission) {
                        if (permission === 'granted') {
                            updateSubNotification(email, true);
                            localStorage.setItem(NOTIFICATION_GRANTED_KEY, '1');
                            registerServiceWorker();
                            showToast('Notifications Enabled! 🎉', 'You\'ll receive push notifications for new posts.', 'success');
                        }
                    });
                });
            }
        }, 500);
    }

    function updateSubNotification(email, enabled) {
        var subs = JSON.parse(localStorage.getItem('nv_newsletter_subs') || '[]');
        var sub = subs.find(function (s) { return s.email === email; });
        if (sub) {
            sub.notificationsEnabled = enabled;
            localStorage.setItem('nv_newsletter_subs', JSON.stringify(subs));
        }
    }

    // ─── Service Worker Registration ───
    function registerServiceWorker() {
        if (!('serviceWorker' in navigator)) return;

        navigator.serviceWorker.register('sw.js').then(function (reg) {
            console.log('NVConsult SW registered:', reg.scope);

            // Listen for messages from the Service Worker
            navigator.serviceWorker.addEventListener('message', function (event) {
                if (event.data && event.data.type === 'CHECK_NEW_POSTS_RESPONSE') {
                    checkNewPosts();
                }
            });
        }).catch(function (err) {
            console.log('SW registration failed:', err);
        });
    }

    // ─── Check for New Posts (returning visitors) ───
    function checkNewPosts() {
        var newPostData = localStorage.getItem(NEW_POST_KEY);
        if (!newPostData) return;

        try {
            var newPost = JSON.parse(newPostData);
            var lastSeen = parseInt(localStorage.getItem(LAST_POST_SEEN_KEY) || '0');

            // Only show if this post is newer than what user last saw
            if (!newPost.timestamp || newPost.timestamp <= lastSeen) return;

            // Don't show on admin page
            if (window.location.pathname.indexOf('admin') !== -1) return;

            setTimeout(function () {
                var postUrl = newPost.slug
                    ? 'blog-post.html?slug=' + newPost.slug
                    : 'blog-post.html?id=' + newPost.id;

                // Show in-page toast
                showToast(
                    '📝 New Post!',
                    '<strong>' + newPost.title + '</strong><br>' +
                    (newPost.excerpt ? newPost.excerpt.substring(0, 80) + '... ' : '') +
                    '<a href="' + postUrl + '" style="color:#F59E0B;font-weight:600;">Read Now →</a>',
                    'info',
                    15000
                );

                // Also show native device notification
                if ('Notification' in window && Notification.permission === 'granted') {
                    try {
                        var iconUrl = window.location.href.replace(/[^/]*$/, '') + 'img/about-2.png';
                        var notif = new Notification('📝 New Post — NVConsult', {
                            body: newPost.title,
                            icon: iconUrl,
                            tag: 'nv-newpost-' + Date.now(),
                            requireInteraction: true
                        });
                        notif.onclick = function () {
                            window.focus();
                            window.location.href = postUrl;
                            notif.close();
                        };
                    } catch (e) {
                        // Fallback: use SW notification
                        if (navigator.serviceWorker && navigator.serviceWorker.controller) {
                            navigator.serviceWorker.controller.postMessage({
                                type: 'NEW_POST',
                                id: newPost.id,
                                slug: newPost.slug,
                                title: newPost.title
                            });
                        }
                    }
                }

                localStorage.setItem(LAST_POST_SEEN_KEY, Date.now().toString());
            }, 3000);
        } catch (e) {
            console.error('Error checking new posts:', e);
        }
    }

    // ─── Toast Notification ───
    function showToast(title, message, type, duration) {
        duration = duration || 5000;

        // Remove existing toast
        var existing = document.querySelector('.newsletter-toast');
        if (existing) existing.remove();

        var borderColor = type === 'error' ? '#fc8181' : type === 'success' ? '#48bb78' : '#F59E0B';

        var toast = document.createElement('div');
        toast.className = 'newsletter-toast';
        toast.style.borderLeftColor = borderColor;
        toast.innerHTML =
            '<div class="toast-header">' +
                '<h6>' + title + '</h6>' +
                '<button class="close-toast">&times;</button>' +
            '</div>' +
            '<div class="toast-body">' +
                '<p>' + message + '</p>' +
            '</div>';

        document.body.appendChild(toast);

        // Animate in
        setTimeout(function () { toast.classList.add('show'); }, 50);

        // Close button
        toast.querySelector('.close-toast').addEventListener('click', function () {
            toast.classList.remove('show');
            setTimeout(function () { toast.remove(); }, 400);
        });

        // Auto dismiss
        setTimeout(function () {
            if (document.body.contains(toast)) {
                toast.classList.remove('show');
                setTimeout(function () { toast.remove(); }, 400);
            }
        }, duration);
    }

    // ─── Utility ───
    function isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    // ─── Init ───
    document.addEventListener('DOMContentLoaded', function () {
        initNewsletter();
        checkNewPosts();

        // Auto-register SW if notifications already granted
        if ('Notification' in window && Notification.permission === 'granted') {
            registerServiceWorker();
        }

        // Show first-visit notification prompt
        showFirstVisitPrompt();
    });

})();
