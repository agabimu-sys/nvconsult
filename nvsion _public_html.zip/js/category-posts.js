// NVConsult Category Posts — Renders posts on category-specific pages
// service.html → Work Visas | study-visas.html → Study Visas | jobs-abroad.html → Jobs Abroad
(function () {
    'use strict';

    // ─── Detect which category this page belongs to ───
    function getPageCategory() {
        var path = window.location.pathname.toLowerCase();
        if (path.indexOf('service') !== -1) return 'Work Visas';
        if (path.indexOf('study-visa') !== -1) return 'Study Visas';
        if (path.indexOf('jobs-abroad') !== -1) return 'Jobs Abroad';
        // Also check for data attribute on the container
        var container = document.getElementById('category-posts-grid');
        if (container && container.dataset.category) return container.dataset.category;
        return null;
    }

    // ─── Data Layer ───
    function getPosts() {
        return JSON.parse(localStorage.getItem('nv_site_posts') || '[]');
    }

    function getPublishedByCategory(category) {
        return getPosts()
            .filter(function (p) { return p.status === 'published' && p.category === category; })
            .sort(function (a, b) { return new Date(b.date) - new Date(a.date); });
    }

    function formatDate(dateStr) {
        var d = new Date(dateStr);
        return d.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
    }

    // ─── Render Posts Section ───
    function initCategoryPosts() {
        var container = document.getElementById('category-posts-grid');
        if (!container) return;

        var category = getPageCategory();
        if (!category) return;

        var posts = getPublishedByCategory(category);

        // Hide the entire section if no posts
        var section = container.closest('.category-posts-section');
        if (posts.length === 0) {
            if (section) section.style.display = 'none';
            return;
        }

        // Show section
        if (section) section.style.display = '';

        // Show up to 6 latest posts
        var displayPosts = posts.slice(0, 6);

        container.innerHTML = displayPosts.map(function (post, i) {
            var postUrl = 'blog-post.html?slug=' + post.slug;
            var imageHtml = '';
            if (post.image) {
                imageHtml = '<div class="blog-card-img">' +
                    '<img src="' + post.image + '" alt="' + post.title + '">' +
                    '<span class="blog-category">' + post.category + '</span>' +
                '</div>';
            }
            return '<div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="' + (0.1 + (i * 0.1)) + 's">' +
                '<div class="blog-card">' +
                    imageHtml +
                    '<div class="blog-card-body">' +
                        '<div class="blog-meta">' +
                            '<span><i class="fas fa-calendar-alt"></i> ' + formatDate(post.date) + '</span>' +
                            '<span><i class="fas fa-user"></i> ' + post.author + '</span>' +
                        '</div>' +
                        '<h5><a href="' + postUrl + '">' + post.title + '</a></h5>' +
                        '<p class="blog-excerpt">' + post.excerpt + '</p>' +
                    '</div>' +
                    '<div class="blog-card-footer">' +
                        '<a href="' + postUrl + '" class="read-more">Read More <i class="fas fa-arrow-right ms-1"></i></a>' +
                    '</div>' +
                '</div>' +
            '</div>';
        }).join('');

        // Show "View All" link if more posts exist
        if (posts.length > 6) {
            var viewAllHtml = '<div class="col-12 text-center mt-4">' +
                '<a href="blog.html?category=' + encodeURIComponent(category) + '" class="btn btn-primary border-secondary rounded-pill py-2 px-4">View All ' + category + ' Posts <i class="fas fa-arrow-right ms-1"></i></a>' +
            '</div>';
            container.innerHTML += viewAllHtml;
        }

        if (typeof WOW !== 'undefined') new WOW().init();
    }

    // ─── Init ───
    document.addEventListener('DOMContentLoaded', initCategoryPosts);
})();
