// NVConsult Jobs System — Dynamic Job Board with Filtering, Detail Pages & JSON-LD
(function () {
    'use strict';

    // ─── Constants ───
    var JOBS_KEY = 'nv_site_jobs';
    var JOBS_PER_PAGE = 6;

    var COUNTRY_CODES = {
        'Germany': 'DE', 'Czech Republic': 'CZ', 'Poland': 'PL',
        'Netherlands': 'NL', 'Austria': 'AT', 'Portugal': 'PT'
    };

    var COUNTRY_FLAGS = {
        'Germany': '🇩🇪', 'Czech Republic': '🇨🇿', 'Poland': '🇵🇱',
        'Netherlands': '🇳🇱', 'Austria': '🇦🇹', 'Portugal': '🇵🇹'
    };

    // ─── Seed Data ───
    var SEED_JOBS = [
        {
            id: 'job-1',
            slug: 'forklift-operator-warehouse-specialist-brno',
            title: 'Forklift Operator / Warehouse Specialist',
            sector: 'Logistics, Warehouse & Supply Chain',
            experienceLevel: 'Entry-Level',
            city: 'Brno',
            country: 'Czech Republic',
            salaryMin: 1600,
            salaryMax: 2100,
            salaryCurrency: 'EUR',
            salaryPeriod: 'MONTH',
            salaryNote: 'Net',
            contractType: 'Full-Time',
            visaSponsorship: 'Full Visa Sponsorship',
            language: 'English Only',
            languageDetail: 'No Czech language required — English working environment',
            relocationPerks: ['Housing Assistance', 'Airport Pickup'],
            hook: 'Join one of Central Europe\'s largest logistics hubs. This position offers complete visa sponsorship and relocation support for international candidates. Perfect for those looking to start their European career journey.',
            responsibilities: [
                'Operate counterbalance and reach forklifts in a modern warehouse facility',
                'Manage incoming and outgoing shipments using WMS systems',
                'Perform daily equipment safety inspections and maintenance checks',
                'Coordinate with team leads on inventory management and order fulfillment',
                'Maintain organized storage areas following 5S methodology'
            ],
            mustHaves: [
                'Valid forklift operator license/certificate',
                'Minimum 1 year of warehouse or logistics experience',
                'Physical fitness for manual handling tasks',
                'Basic English communication skills'
            ],
            niceToHaves: [
                'Experience with SAP or WMS software',
                'Additional forklift certifications (VNA, LPG)',
                'Previous international work experience'
            ],
            hiringOrganization: 'NVConsult Recruiting Partner',
            datePosted: '2026-05-20',
            validThrough: '2026-08-20',
            status: 'published'
        },
        {
            id: 'job-2',
            slug: 'cnc-machinist-programmer-stuttgart',
            title: 'CNC Machinist / Programmer',
            sector: 'Manufacturing & Technical Trades',
            experienceLevel: 'Mid-Level',
            city: 'Stuttgart',
            country: 'Germany',
            salaryMin: 2800,
            salaryMax: 3600,
            salaryCurrency: 'EUR',
            salaryPeriod: 'MONTH',
            salaryNote: 'Gross',
            contractType: 'Full-Time, Permanent',
            visaSponsorship: 'EU Blue Card Eligible',
            language: 'German A2 Preferred',
            languageDetail: 'English working proficiency required. German A2 level preferred but training provided.',
            relocationPerks: ['1-Month Free Accommodation', 'Airport Pickup', 'Relocation Allowance'],
            hook: 'Work with a Tier-1 automotive component manufacturer in Germany\'s industrial heartland. This role offers EU Blue Card eligibility and a clear pathway to permanent residency in Europe\'s strongest economy.',
            responsibilities: [
                'Set up, program, and operate multi-axis CNC milling and turning machines',
                'Interpret complex engineering blueprints and CAD/CAM drawings',
                'Perform precision measurements using CMM and manual gauges',
                'Optimize machining parameters for quality and efficiency',
                'Collaborate with engineering teams on prototype development'
            ],
            mustHaves: [
                'Minimum 2+ years operating CNC machines (Fanuc, Siemens, or Heidenhain)',
                'Technical diploma, vocational certificate, or completed apprenticeship',
                'Ability to read and interpret mechanical engineering blueprints',
                'Working proficiency in English'
            ],
            niceToHaves: [
                'CAD/CAM programming experience (Mastercam, SolidWorks)',
                'German language skills (A2 or above)',
                'Automotive industry experience',
                'ISO 9001 quality management knowledge'
            ],
            hiringOrganization: 'NVConsult Recruiting Partner',
            datePosted: '2026-05-24',
            validThrough: '2026-08-24',
            status: 'published'
        },
        {
            id: 'job-3',
            slug: 'full-stack-developer-react-node-berlin',
            title: 'Full-Stack Developer (React & Node.js)',
            sector: 'IT, Software & Tech',
            experienceLevel: 'Mid-Level',
            city: 'Berlin',
            country: 'Germany',
            salaryMin: 4200,
            salaryMax: 5500,
            salaryCurrency: 'EUR',
            salaryPeriod: 'MONTH',
            salaryNote: 'Gross',
            contractType: 'Full-Time, Permanent',
            visaSponsorship: 'EU Blue Card Eligible',
            language: 'English Only',
            languageDetail: 'Fully English-speaking team. No German required.',
            relocationPerks: ['Relocation Allowance', 'Visa Processing Support'],
            hook: 'Join a fast-growing Berlin-based SaaS startup building next-generation supply chain tools. English-only team, flexible hybrid working, and EU Blue Card sponsorship included.',
            responsibilities: [
                'Design and build scalable web applications using React, TypeScript, and Node.js',
                'Develop and maintain RESTful APIs and GraphQL endpoints',
                'Collaborate with product and UX teams in agile sprint cycles',
                'Write comprehensive unit and integration tests',
                'Participate in code reviews and technical architecture decisions'
            ],
            mustHaves: [
                '3+ years professional experience with React and Node.js',
                'Strong proficiency in TypeScript and modern JavaScript',
                'Experience with PostgreSQL or MongoDB databases',
                'Familiarity with CI/CD pipelines and Git workflows',
                'Bachelor\'s degree in Computer Science or equivalent experience'
            ],
            niceToHaves: [
                'Experience with AWS, Docker, or Kubernetes',
                'Knowledge of GraphQL and microservices architecture',
                'Previous startup environment experience',
                'Open source contributions'
            ],
            hiringOrganization: 'NVConsult Recruiting Partner',
            datePosted: '2026-05-28',
            validThrough: '2026-08-28',
            status: 'published'
        },
        {
            id: 'job-4',
            slug: 'hotel-operations-manager-krakow',
            title: 'Hotel Operations Manager',
            sector: 'Hospitality & Catering',
            experienceLevel: 'Senior',
            city: 'Kraków',
            country: 'Poland',
            salaryMin: 2200,
            salaryMax: 3000,
            salaryCurrency: 'EUR',
            salaryPeriod: 'MONTH',
            salaryNote: 'Net',
            contractType: 'Full-Time',
            visaSponsorship: 'Full Visa Sponsorship',
            language: 'English Only',
            languageDetail: 'English fluency required. Polish language training provided on-site.',
            relocationPerks: ['Flight Ticket Covered', 'Staff Accommodation', 'Airport Pickup'],
            hook: 'Lead front-of-house operations at a premium 4-star hotel in Kraków\'s historic Old Town. Full visa sponsorship, staff accommodation, and flight reimbursement for the right candidate.',
            responsibilities: [
                'Oversee daily hotel operations including front desk, housekeeping, and F&B',
                'Manage a diverse team of 25+ staff members across departments',
                'Implement guest satisfaction improvement initiatives',
                'Handle VIP guest relations and resolve escalated complaints',
                'Coordinate with revenue management on pricing strategies'
            ],
            mustHaves: [
                '5+ years experience in hotel management or operations',
                'Proven track record in team leadership and guest relations',
                'Degree in Hospitality Management or related field',
                'Fluent English communication skills',
                'Proficiency in hotel PMS systems (Opera, Mews, etc.)'
            ],
            niceToHaves: [
                'Experience with boutique or heritage hotel properties',
                'Revenue management certification',
                'Knowledge of Polish, Russian, or Ukrainian languages',
                'Experience managing international teams'
            ],
            hiringOrganization: 'NVConsult Recruiting Partner',
            datePosted: '2026-05-15',
            validThrough: '2026-07-30',
            status: 'published'
        },
        {
            id: 'job-5',
            slug: 'electrician-industrial-maintenance-vienna',
            title: 'Electrician — Industrial Maintenance',
            sector: 'Manufacturing & Technical Trades',
            experienceLevel: 'Mid-Level',
            city: 'Vienna',
            country: 'Austria',
            salaryMin: 2600,
            salaryMax: 3200,
            salaryCurrency: 'EUR',
            salaryPeriod: 'MONTH',
            salaryNote: 'Gross',
            contractType: 'Full-Time, Permanent',
            visaSponsorship: 'Full Visa Sponsorship',
            language: 'German A2 Preferred',
            languageDetail: 'Basic German (A2) preferred. English-speaking supervisors on-site.',
            relocationPerks: ['Relocation Allowance', 'Visa Processing Support'],
            hook: 'Maintain and troubleshoot industrial electrical systems at a leading Austrian manufacturing plant. Full visa sponsorship with pathway to permanent EU residence.',
            responsibilities: [
                'Install, maintain, and repair industrial electrical systems and machinery',
                'Troubleshoot PLC-controlled production lines and automation equipment',
                'Perform preventive maintenance per scheduled plans',
                'Read and interpret electrical schematics and technical diagrams',
                'Ensure compliance with Austrian electrical safety regulations'
            ],
            mustHaves: [
                '3+ years experience in industrial electrical maintenance',
                'Recognized electrician qualification or vocational diploma',
                'Experience with PLC systems (Siemens S7 preferred)',
                'Ability to read electrical schematics and wiring diagrams'
            ],
            niceToHaves: [
                'German language skills (A2 or above)',
                'Experience with Siemens TIA Portal',
                'Knowledge of ATEX regulations',
                'Automation and robotics experience'
            ],
            hiringOrganization: 'NVConsult Recruiting Partner',
            datePosted: '2026-05-18',
            validThrough: '2026-08-18',
            status: 'published'
        },
        {
            id: 'job-6',
            slug: 'it-support-technician-prague',
            title: 'IT Support Technician (L1/L2)',
            sector: 'IT, Software & Tech',
            experienceLevel: 'Entry-Level',
            city: 'Prague',
            country: 'Czech Republic',
            salaryMin: 1800,
            salaryMax: 2400,
            salaryCurrency: 'EUR',
            salaryPeriod: 'MONTH',
            salaryNote: 'Gross',
            contractType: 'Full-Time',
            visaSponsorship: 'Full Visa Sponsorship',
            language: 'English Only',
            languageDetail: 'English-only environment. Czech language training available.',
            relocationPerks: ['Housing Assistance', 'Visa Processing Support'],
            hook: 'Provide technical support for a multinational IT services company in Prague. English-only environment with complete visa sponsorship and career growth opportunities.',
            responsibilities: [
                'Provide Level 1 and Level 2 technical support via phone, email, and ticketing system',
                'Troubleshoot Windows, macOS, and Linux workstation issues',
                'Manage Active Directory user accounts and permissions',
                'Deploy and configure hardware and software for end users',
                'Document solutions and contribute to the knowledge base'
            ],
            mustHaves: [
                '1+ year of IT support or helpdesk experience',
                'Strong knowledge of Windows 10/11 and Office 365',
                'Basic networking knowledge (TCP/IP, DNS, DHCP)',
                'Excellent English communication skills',
                'Customer-oriented mindset and problem-solving ability'
            ],
            niceToHaves: [
                'CompTIA A+ or ITIL Foundation certification',
                'Experience with ServiceNow or Jira Service Desk',
                'Linux administration basics',
                'Scripting skills (PowerShell, Bash)'
            ],
            hiringOrganization: 'NVConsult Recruiting Partner',
            datePosted: '2026-05-25',
            validThrough: '2026-08-25',
            status: 'published'
        }
    ];

    // ─── Slug Generator ───
    function generateSlug(title) {
        return title.toLowerCase()
            .replace(/[^a-z0-9\s-]/g, '')
            .replace(/\s+/g, '-')
            .replace(/-+/g, '-')
            .replace(/^-|-$/g, '');
    }

    // ─── Data Layer ───
    function getJobs() {
        var jobs = JSON.parse(localStorage.getItem(JOBS_KEY) || '[]');
        if (jobs.length === 0) {
            localStorage.setItem(JOBS_KEY, JSON.stringify(SEED_JOBS));
            jobs = SEED_JOBS;
        }
        return jobs;
    }

    function getPublishedJobs() {
        return getJobs().filter(function (j) { return j.status === 'published'; })
            .sort(function (a, b) { return new Date(b.datePosted) - new Date(a.datePosted); });
    }

    function getJobBySlug(slug) {
        return getJobs().find(function (j) { return j.slug === slug; });
    }

    // ─── Filter Engine ───
    function filterJobs(jobs, filters) {
        return jobs.filter(function (job) {
            if (filters.keyword) {
                var kw = filters.keyword.toLowerCase();
                var searchable = (job.title + ' ' + job.city + ' ' + job.country + ' ' + job.sector + ' ' + job.hook).toLowerCase();
                if (searchable.indexOf(kw) === -1) return false;
            }
            if (filters.countries && filters.countries.length > 0) {
                if (filters.countries.indexOf(job.country) === -1) return false;
            }
            if (filters.sectors && filters.sectors.length > 0) {
                if (filters.sectors.indexOf(job.sector) === -1) return false;
            }
            if (filters.visaTypes && filters.visaTypes.length > 0) {
                if (filters.visaTypes.indexOf(job.visaSponsorship) === -1) return false;
            }
            if (filters.languages && filters.languages.length > 0) {
                var match = false;
                filters.languages.forEach(function (lang) {
                    if (job.language.indexOf(lang) !== -1) match = true;
                });
                if (!match) return false;
            }
            if (filters.experience && filters.experience.length > 0) {
                if (filters.experience.indexOf(job.experienceLevel) === -1) return false;
            }
            return true;
        });
    }

    // ─── Visa Badge HTML ───
    function badgeHtml(icon, text, cls) {
        return '<span class="job-trust-badge ' + (cls || '') + '"><i class="' + icon + '"></i> ' + text + '</span>';
    }

    // ─── Job Card Renderer ───
    function renderJobCard(job) {
        var flag = COUNTRY_FLAGS[job.country] || '🇪🇺';
        var salary = '€' + job.salaryMin.toLocaleString() + ' – €' + job.salaryMax.toLocaleString() + ' / Month';
        if (job.salaryNote) salary += ' ' + job.salaryNote;

        var badges = '';
        badges += badgeHtml('fas fa-passport', job.visaSponsorship, 'badge-visa');
        badges += badgeHtml('fas fa-language', job.language, 'badge-lang');
        if (job.relocationPerks && job.relocationPerks.length > 0) {
            badges += badgeHtml('fas fa-home', job.relocationPerks[0], 'badge-reloc');
        }

        return '<div class="col-lg-6 col-xl-6">' +
            '<div class="job-card">' +
                '<div class="job-card-header">' +
                    '<span class="job-sector-badge">' + job.sector + '</span>' +
                    '<span class="job-exp-badge">' + job.experienceLevel + '</span>' +
                '</div>' +
                '<h4 class="job-card-title">' + job.title + '</h4>' +
                '<div class="job-card-meta">' +
                    '<span class="job-location"><i class="fas fa-map-marker-alt"></i> ' + flag + ' ' + job.city + ', ' + job.country + '</span>' +
                    '<span class="job-salary"><i class="fas fa-euro-sign"></i> ' + salary + '</span>' +
                '</div>' +
                '<div class="job-trust-badges">' + badges + '</div>' +
                '<p class="job-card-desc">' + job.hook.substring(0, 160) + (job.hook.length > 160 ? '...' : '') + '</p>' +
                '<div class="job-card-cta">' +
                    '<a href="job-detail.html?slug=' + job.slug + '" class="btn btn-primary rounded-pill border-secondary px-4 py-2">View Details & Apply</a>' +
                    '<a href="pricing.html" class="btn btn-outline-secondary rounded-pill px-4 py-2">Check Eligibility</a>' +
                '</div>' +
            '</div>' +
        '</div>';
    }

    // ─── Job Listing Page Init ───
    function initJobListing() {
        var grid = document.getElementById('jobs-grid');
        if (!grid) return;

        var currentPage = 1;
        var filters = {};

        // Read URL params
        var urlParams = new URLSearchParams(window.location.search);
        var urlCountry = urlParams.get('country');
        if (urlCountry) filters.countries = [urlCountry];
        var urlSector = urlParams.get('sector');
        if (urlSector) filters.sectors = [urlSector];

        function getFilteredJobs() {
            return filterJobs(getPublishedJobs(), filters);
        }

        function renderGrid() {
            var jobs = getFilteredJobs();
            var totalPages = Math.ceil(jobs.length / JOBS_PER_PAGE);
            var start = (currentPage - 1) * JOBS_PER_PAGE;
            var pageJobs = jobs.slice(start, start + JOBS_PER_PAGE);

            // Results count
            var countEl = document.getElementById('jobs-result-count');
            if (countEl) countEl.textContent = jobs.length + ' position' + (jobs.length !== 1 ? 's' : '') + ' found';

            if (pageJobs.length === 0) {
                grid.innerHTML = '<div class="col-12 text-center py-5">' +
                    '<i class="fas fa-briefcase" style="font-size: 3rem; color: #cbd5e0;"></i>' +
                    '<h4 class="mt-3" style="color: #718096;">No jobs match your filters</h4>' +
                    '<p class="text-muted">Try adjusting your search criteria or <a href="jobs-abroad.html">view all positions</a>.</p>' +
                    '</div>';
            } else {
                grid.innerHTML = pageJobs.map(renderJobCard).join('');
            }

            renderPagination(totalPages);
        }

        function renderPagination(totalPages) {
            var pag = document.getElementById('jobs-pagination');
            if (!pag || totalPages <= 1) {
                if (pag) pag.innerHTML = '';
                return;
            }
            var html = '';
            if (currentPage > 1) html += '<button class="page-btn" data-page="' + (currentPage - 1) + '"><i class="fas fa-chevron-left"></i></button>';
            for (var i = 1; i <= totalPages; i++) {
                html += '<button class="page-btn' + (i === currentPage ? ' active' : '') + '" data-page="' + i + '">' + i + '</button>';
            }
            if (currentPage < totalPages) html += '<button class="page-btn" data-page="' + (currentPage + 1) + '"><i class="fas fa-chevron-right"></i></button>';
            pag.innerHTML = html;
            pag.querySelectorAll('.page-btn').forEach(function (btn) {
                btn.addEventListener('click', function () {
                    currentPage = parseInt(this.dataset.page);
                    renderGrid();
                    window.scrollTo({ top: grid.offsetTop - 120, behavior: 'smooth' });
                });
            });
        }

        // ─── Filter Controls ───
        function collectFilters() {
            filters = {};

            // Keyword
            var kwInput = document.getElementById('job-search-input');
            if (kwInput && kwInput.value.trim()) filters.keyword = kwInput.value.trim();

            // Checkboxes
            filters.countries = getCheckedValues('filter-country');
            filters.sectors = getCheckedValues('filter-sector');
            filters.visaTypes = getCheckedValues('filter-visa');
            filters.languages = getCheckedValues('filter-language');
            filters.experience = getCheckedValues('filter-experience');

            currentPage = 1;
            renderGrid();
        }

        function getCheckedValues(name) {
            var vals = [];
            document.querySelectorAll('input[name="' + name + '"]:checked').forEach(function (cb) {
                vals.push(cb.value);
            });
            return vals;
        }

        // Bind filter events
        document.querySelectorAll('.jobs-filter-sidebar input[type="checkbox"]').forEach(function (cb) {
            cb.addEventListener('change', collectFilters);
        });

        var searchInput = document.getElementById('job-search-input');
        if (searchInput) {
            var searchTimer = null;
            searchInput.addEventListener('input', function () {
                clearTimeout(searchTimer);
                searchTimer = setTimeout(collectFilters, 300);
            });
        }

        // Clear filters button
        var clearBtn = document.getElementById('clear-filters-btn');
        if (clearBtn) {
            clearBtn.addEventListener('click', function () {
                document.querySelectorAll('.jobs-filter-sidebar input[type="checkbox"]').forEach(function (cb) { cb.checked = false; });
                if (searchInput) searchInput.value = '';
                filters = {};
                currentPage = 1;
                renderGrid();
            });
        }

        // Mobile filter toggle
        var filterToggle = document.getElementById('mobile-filter-toggle');
        var filterSidebar = document.querySelector('.jobs-filter-sidebar');
        if (filterToggle && filterSidebar) {
            filterToggle.addEventListener('click', function () {
                filterSidebar.classList.toggle('open');
            });
        }

        // Pre-check URL filters
        if (urlCountry) {
            var cb = document.querySelector('input[name="filter-country"][value="' + urlCountry + '"]');
            if (cb) cb.checked = true;
        }
        if (urlSector) {
            var scb = document.querySelector('input[name="filter-sector"][value="' + urlSector + '"]');
            if (scb) scb.checked = true;
        }

        renderGrid();
    }

    // ─── Single Job Detail Page ───
    function initJobDetail() {
        var container = document.getElementById('job-detail-content');
        if (!container) return;

        var params = new URLSearchParams(window.location.search);
        var slug = params.get('slug');
        var job = slug ? getJobBySlug(slug) : null;

        if (!job) {
            container.innerHTML = '<div class="text-center py-5"><h3>Job not found</h3><p class="text-muted">This listing may have been removed or expired.</p><a href="jobs-abroad.html" class="btn btn-primary rounded-pill mt-3 px-4">Browse All Jobs</a></div>';
            return;
        }

        var flag = COUNTRY_FLAGS[job.country] || '🇪🇺';
        var salary = '€' + job.salaryMin.toLocaleString() + ' – €' + job.salaryMax.toLocaleString() + ' / Month';
        if (job.salaryNote) salary += ' (' + job.salaryNote + ')';

        // Page title
        document.title = job.title + ' in ' + job.city + ', ' + job.country + ' — NVConsult Jobs';

        // Meta description
        var metaDesc = document.querySelector('meta[name="description"]');
        if (metaDesc) metaDesc.setAttribute('content', job.hook.substring(0, 160));

        // Breadcrumb
        var breadcrumbTitle = document.getElementById('breadcrumb-job-title');
        if (breadcrumbTitle) breadcrumbTitle.textContent = job.title;

        // Build relocation perks badges
        var relocationBadges = '';
        if (job.relocationPerks) {
            job.relocationPerks.forEach(function (perk) {
                var icon = 'fas fa-gift';
                if (perk.indexOf('Flight') !== -1) icon = 'fas fa-plane';
                else if (perk.indexOf('Accommodation') !== -1 || perk.indexOf('Housing') !== -1) icon = 'fas fa-home';
                else if (perk.indexOf('Allowance') !== -1) icon = 'fas fa-money-bill-wave';
                else if (perk.indexOf('Pickup') !== -1) icon = 'fas fa-car';
                relocationBadges += badgeHtml(icon, perk, 'badge-reloc');
            });
        }

        // Responsibilities
        var respHtml = job.responsibilities ? job.responsibilities.map(function (r) { return '<li>' + r + '</li>'; }).join('') : '';

        // Must-haves
        var mustHtml = job.mustHaves ? job.mustHaves.map(function (r) { return '<li>' + r + '</li>'; }).join('') : '';

        // Nice-to-haves
        var niceHtml = job.niceToHaves ? job.niceToHaves.map(function (r) { return '<li>' + r + '</li>'; }).join('') : '';

        container.innerHTML =
            // Header
            '<div class="job-detail-header">' +
                '<span class="job-sector-badge">' + job.sector + '</span>' +
                '<h1>' + job.title + '</h1>' +
                '<div class="job-detail-meta">' +
                    '<span><i class="fas fa-map-marker-alt"></i> ' + flag + ' ' + job.city + ', ' + job.country + '</span>' +
                    '<span><i class="fas fa-euro-sign"></i> ' + salary + '</span>' +
                    '<span><i class="fas fa-file-contract"></i> ' + job.contractType + '</span>' +
                    '<span><i class="fas fa-briefcase"></i> ' + job.sector + '</span>' +
                '</div>' +
            '</div>' +

            // Visa & Relocation Package
            '<div class="visa-package-box">' +
                '<h5><i class="fas fa-shield-alt me-2"></i>Visa & Relocation Package</h5>' +
                '<div class="visa-package-grid">' +
                    '<div class="visa-pkg-item">' +
                        '<span class="visa-pkg-label">Visa Sponsorship</span>' +
                        '<span class="visa-pkg-value">' + badgeHtml('fas fa-passport', job.visaSponsorship, 'badge-visa') + '</span>' +
                    '</div>' +
                    '<div class="visa-pkg-item">' +
                        '<span class="visa-pkg-label">Language Requirement</span>' +
                        '<span class="visa-pkg-value">' + badgeHtml('fas fa-language', job.language, 'badge-lang') + '</span>' +
                        (job.languageDetail ? '<small class="visa-pkg-detail">' + job.languageDetail + '</small>' : '') +
                    '</div>' +
                    '<div class="visa-pkg-item">' +
                        '<span class="visa-pkg-label">Relocation Support</span>' +
                        '<div class="visa-pkg-value">' + relocationBadges + '</div>' +
                    '</div>' +
                '</div>' +
            '</div>' +

            // Role Overview
            '<div class="job-detail-section">' +
                '<h3><i class="fas fa-clipboard-list me-2"></i>Role Overview</h3>' +
                '<p class="job-hook-text">' + job.hook + '</p>' +
                (respHtml ? '<h4>Core Responsibilities</h4><ul class="job-list">' + respHtml + '</ul>' : '') +
                (mustHtml ? '<h4>Must-Have Requirements</h4><ul class="job-list job-list-must">' + mustHtml + '</ul>' : '') +
                (niceHtml ? '<h4>Nice-to-Have</h4><ul class="job-list job-list-nice">' + niceHtml + '</ul>' : '') +
            '</div>' +

            // Relocation Timeline
            '<div class="job-detail-section">' +
                '<h3><i class="fas fa-route me-2"></i>The Relocation Process</h3>' +
                '<div class="relocation-timeline">' +
                    '<div class="timeline-step"><div class="timeline-num">1</div><div class="timeline-content"><strong>Initial Screen</strong><p>Apply here with your updated CV</p></div></div>' +
                    '<div class="timeline-step"><div class="timeline-num">2</div><div class="timeline-content"><strong>Employer Interview</strong><p>1× Technical video interview with the hiring manager</p></div></div>' +
                    '<div class="timeline-step"><div class="timeline-num">3</div><div class="timeline-content"><strong>NVConsult Processing</strong><p>Our team initiates your formal visa application and document processing</p></div></div>' +
                    '<div class="timeline-step"><div class="timeline-num">4</div><div class="timeline-content"><strong>Relocation</strong><p>Secure your visa stamp, book your flight, and begin your new career</p></div></div>' +
                '</div>' +
            '</div>' +

            // Dual CTA
            '<div class="dual-cta-box">' +
                '<h4>Ready to take the next step?</h4>' +
                '<p>Choose an option below to proceed. Our legal and recruitment experts review all submissions within 48 business hours.</p>' +
                '<div class="dual-cta-buttons">' +
                    '<a href="#" data-cal-link="euconsult/15min" data-cal-config=\'{"layout":"month_view"}\' class="btn btn-primary rounded-pill border-secondary py-3 px-5 dual-cta-primary"><i class="fas fa-paper-plane me-2"></i>Apply for This Position</a>' +
                    '<a href="pricing.html" class="btn btn-outline-secondary rounded-pill py-3 px-5 dual-cta-secondary"><i class="fas fa-user-check me-2"></i>Don\'t meet all criteria? Book an Eligibility Assessment</a>' +
                '</div>' +
                '<small class="dual-cta-note">Unsure if your profile fits European requirements? Let our senior consultants audit your qualifications and build a personalized roadmap via our €18 / €30 plans.</small>' +
            '</div>';

        // Inject JSON-LD Schema
        injectJobSchema(job);

        // Inject OG tags
        injectOgTag('og:title', job.title + ' — ' + job.city + ', ' + job.country);
        injectOgTag('og:description', job.hook.substring(0, 160));
        injectOgTag('og:type', 'website');
        injectOgTag('og:url', window.location.href);
    }

    // ─── JobPosting JSON-LD Schema Generator ───
    function injectJobSchema(job) {
        var schema = {
            '@context': 'https://schema.org/',
            '@type': 'JobPosting',
            'title': job.title,
            'description': job.hook + ' ' + (job.responsibilities ? job.responsibilities.join('. ') : ''),
            'datePosted': job.datePosted,
            'validThrough': job.validThrough,
            'employmentType': job.contractType.indexOf('Part') !== -1 ? 'PART_TIME' : 'FULL_TIME',
            'hiringOrganization': {
                '@type': 'Organization',
                'name': job.hiringOrganization || 'NVConsult Recruiting Partner',
                'sameAs': 'https://nvconsult.eu'
            },
            'jobLocation': {
                '@type': 'Place',
                'address': {
                    '@type': 'PostalAddress',
                    'addressLocality': job.city,
                    'addressCountry': COUNTRY_CODES[job.country] || job.country
                }
            },
            'baseSalary': {
                '@type': 'MonetaryAmount',
                'currency': job.salaryCurrency || 'EUR',
                'value': {
                    '@type': 'QuantitativeValue',
                    'minValue': job.salaryMin,
                    'maxValue': job.salaryMax,
                    'unitText': job.salaryPeriod || 'MONTH'
                }
            }
        };

        var script = document.createElement('script');
        script.type = 'application/ld+json';
        script.textContent = JSON.stringify(schema);
        document.head.appendChild(script);
    }

    function injectOgTag(property, content) {
        if (!content) return;
        var existing = document.querySelector('meta[property="' + property + '"]');
        if (existing) {
            existing.setAttribute('content', content);
        } else {
            var meta = document.createElement('meta');
            meta.setAttribute('property', property);
            meta.setAttribute('content', content);
            document.head.appendChild(meta);
        }
    }

    // ─── Format Date ───
    function formatDate(dateStr) {
        var d = new Date(dateStr);
        return d.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
    }

    // ─── Init ───
    document.addEventListener('DOMContentLoaded', function () {
        initJobListing();
        initJobDetail();
    });

    // Expose for admin
    window.NVJobs = {
        getJobs: getJobs,
        getPublishedJobs: getPublishedJobs,
        getJobBySlug: getJobBySlug,
        generateSlug: generateSlug,
        SEED_JOBS: SEED_JOBS
    };
})();
