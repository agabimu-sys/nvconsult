// NVConsult Posts System — Renders posts on blog page & handles single post view
(function () {
    'use strict';

    function getSitePosts() {
        return JSON.parse(localStorage.getItem('nv_site_posts') || '[]');
    }

    function getPublishedPosts() {
        return getSitePosts().filter(function (p) { return p.status === 'published'; })
            .sort(function (a, b) { return new Date(b.date) - new Date(a.date); });
    }

    function getPostBySlug(slug) {
        return getSitePosts().find(function (p) { return p.slug === slug; });
    }

    function getPostById(id) {
        return getSitePosts().find(function (p) { return p.id === id; });
    }

    function formatDate(dateStr) {
        var d = new Date(dateStr);
        return d.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
    }

    // ─── Posts Section on Blog Page ───
    function initPostsSection() {
        var container = document.getElementById('site-posts-grid');
        if (!container) return;

        var posts = getPublishedPosts();

        if (posts.length === 0) {
            // Hide the entire posts section if no posts exist
            var section = container.closest('.container-fluid');
            if (section) section.style.display = 'none';
            return;
        }

        // Show up to 6 latest posts
        var displayPosts = posts.slice(0, 6);

        container.innerHTML = displayPosts.map(function (post, i) {
            var postUrl = 'post.html?slug=' + post.slug;
            var imgHtml = '';
            if (post.image) {
                imgHtml = '<div class="site-post-img">' +
                    '<img src="' + post.image + '" alt="' + post.title + '">' +
                    '<div class="site-post-date"><i class="fas fa-calendar-alt me-1"></i> ' + formatDate(post.date) + '</div>' +
                '</div>';
            }
            return '<div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="' + (0.1 + (i * 0.1)) + 's">' +
                '<div class="site-post-card">' +
                    imgHtml +
                    '<div class="site-post-body">' +
                        '<h5><a href="' + postUrl + '">' + post.title + '</a></h5>' +
                        '<p>' + post.excerpt + '</p>' +
                        '<a href="' + postUrl + '" class="site-post-link">Read More <i class="fas fa-arrow-right ms-1"></i></a>' +
                    '</div>' +
                '</div>' +
            '</div>';
        }).join('');

        if (typeof WOW !== 'undefined') new WOW().init();
    }

    // ─── Single Post View (post.html) ───
    function initSinglePostView() {
        var postContent = document.getElementById('single-post-content');
        if (!postContent) return;

        var params = new URLSearchParams(window.location.search);
        var slug = params.get('slug');
        var id = params.get('id');

        var post = null;
        if (slug) post = getPostBySlug(slug);
        else if (id) post = getPostById(id);

        if (!post) {
            postContent.innerHTML = '<div class="text-center py-5"><h3>Post not found</h3><a href="blog.html" class="btn btn-primary mt-3">Back to Blog</a></div>';
            return;
        }

        document.title = post.title + ' — NVConsult';

        postContent.innerHTML =
            '<div class="post-header">' +
                '<h1>' + post.title + '</h1>' +
            '</div>' +
            '<div class="post-meta">' +
                '<span><i class="fas fa-calendar-alt"></i> ' + formatDate(post.date) + '</span>' +
                '<span><i class="fas fa-user"></i> ' + post.author + '</span>' +
            '</div>' +
            (post.image ? '<div class="post-featured-img"><img src="' + post.image + '" alt="' + post.title + '"></div>' : '') +
            '<div class="post-body">' +
                post.content +
            '</div>' +
            '<div class="post-share">' +
                '<strong>Share:</strong>' +
                '<a href="https://facebook.com/sharer/sharer.php?u=' + encodeURIComponent(window.location.href) + '" target="_blank" class="share-btn facebook"><i class="fab fa-facebook-f"></i></a>' +
                '<a href="https://twitter.com/intent/tweet?url=' + encodeURIComponent(window.location.href) + '&text=' + encodeURIComponent(post.title) + '" target="_blank" class="share-btn twitter"><i class="fab fa-twitter"></i></a>' +
                '<a href="https://linkedin.com/shareArticle?mini=true&url=' + encodeURIComponent(window.location.href) + '" target="_blank" class="share-btn linkedin"><i class="fab fa-linkedin-in"></i></a>' +
                '<a href="https://wa.me/?text=' + encodeURIComponent(post.title + ' ' + window.location.href) + '" target="_blank" class="share-btn whatsapp"><i class="fab fa-whatsapp"></i></a>' +
            '</div>';

        // Sidebar: Recent Posts
        var recentEl = document.getElementById('recent-site-posts');
        if (recentEl) {
            var recent = getPublishedPosts().filter(function (p) { return p.id !== post.id; }).slice(0, 4);
            recentEl.innerHTML = recent.map(function (p) {
                var rpImg = p.image ? '<img src="' + p.image + '" alt="' + p.title + '">' : '';
                return '<div class="recent-post">' +
                    rpImg +
                    '<div class="rp-content">' +
                        '<h6><a href="post.html?slug=' + p.slug + '">' + p.title + '</a></h6>' +
                        '<small><i class="fas fa-calendar-alt me-1"></i>' + formatDate(p.date) + '</small>' +
                    '</div>' +
                '</div>';
            }).join('');
        }

        // Dynamic breadcrumb based on post category
        var breadcrumbOl = document.querySelector('.breadcrumb');
        var pageHeader = document.querySelector('.bg-breadcrumb h3');
        var categoryPages = {
            'Work Visas': 'service.html',
            'Study Visas': 'study-visas.html',
            'Jobs Abroad': 'jobs-abroad.html',
            'Blog': 'blog.html'
        };

        // Dynamic country slug generator — works for ANY country name
        function countrySlug(name) {
            return name.toLowerCase().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-');
        }

        // Country code map for flag images
        var COUNTRY_CODE_MAP = {
            'afghanistan': 'af', 'albania': 'al', 'algeria': 'dz', 'argentina': 'ar',
            'austria': 'at', 'belgium': 'be', 'brazil': 'br', 'bulgaria': 'bg',
            'canada': 'ca', 'china': 'cn', 'croatia': 'hr', 'cyprus': 'cy',
            'czech republic': 'cz', 'czechia': 'cz', 'denmark': 'dk',
            'egypt': 'eg', 'estonia': 'ee', 'finland': 'fi', 'france': 'fr',
            'georgia': 'ge', 'germany': 'de', 'greece': 'gr', 'hungary': 'hu',
            'india': 'in', 'indonesia': 'id', 'ireland': 'ie', 'italy': 'it',
            'japan': 'jp', 'netherlands': 'nl', 'norway': 'no', 'pakistan': 'pk',
            'poland': 'pl', 'portugal': 'pt', 'romania': 'ro', 'russia': 'ru',
            'spain': 'es', 'sweden': 'se', 'switzerland': 'ch', 'turkey': 'tr',
            'turkiye': 'tr', 'ukraine': 'ua', 'united kingdom': 'gb', 'uk': 'gb',
            'united states': 'us', 'usa': 'us'
        };

        function getCountryFlagImg(name) {
            var code = COUNTRY_CODE_MAP[name.toLowerCase()];
            if (code) return '<img src="https://flagcdn.com/w20/' + code + '.png" style="width:20px;vertical-align:middle;margin-right:4px;border-radius:2px;">';
            return '';
        }

        var catPage = categoryPages[post.category] || 'blog.html';
        var catLabel = post.category || 'Blog';
        var isVisaCategory = (post.category === 'Work Visas' || post.category === 'Study Visas');

        var crumbs = [
            '<li class="breadcrumb-item"><a href="index.html" class="text-white">Home</a></li>',
            '<li class="breadcrumb-item"><a href="' + catPage + '" class="text-white">' + catLabel + '</a></li>'
        ];

        if (post.country) {
            var cSlug = countrySlug(post.country);
            var flagHtml = getCountryFlagImg(post.country);
            var countryUrl = isVisaCategory
                ? 'country-detail.html?page=' + encodeURIComponent(post.category) + '&country=' + cSlug
                : catPage + '?country=' + cSlug;
            crumbs.push('<li class="breadcrumb-item"><a href="' + countryUrl + '" class="text-white">' + flagHtml + post.country + '</a></li>');

            // Add visa type breadcrumb for Work Visas / Study Visas
            if (isVisaCategory && post.visaType) {
                var typeSlug = countrySlug(post.visaType);
                var visaTypeUrl = 'visa-info.html?page=' + encodeURIComponent(post.category) + '&country=' + cSlug + '&type=' + typeSlug;
                crumbs.push('<li class="breadcrumb-item"><a href="' + visaTypeUrl + '" class="text-white">' + post.visaType + '</a></li>');
            }
        }

        crumbs.push('<li class="breadcrumb-item active text-secondary">' + post.title + '</li>');
        if (breadcrumbOl) breadcrumbOl.innerHTML = crumbs.join('');
        if (pageHeader) pageHeader.textContent = catLabel;
    }

    // ─── Init ───
    document.addEventListener('DOMContentLoaded', function () {
        initPostsSection();
        initSinglePostView();
    });
})();
