// NVConsult Visa Info Page — Renders visa type details from URL params
(function () {
    'use strict';

    var COUNTRIES = {
        'germany': { name: 'Germany', flag: 'https://flagcdn.com/w40/de.png', flagLg: 'https://flagcdn.com/w80/de.png' },
        'czech-republic': { name: 'Czech Republic', flag: 'https://flagcdn.com/w40/cz.png', flagLg: 'https://flagcdn.com/w80/cz.png' },
        'poland': { name: 'Poland', flag: 'https://flagcdn.com/w40/pl.png', flagLg: 'https://flagcdn.com/w80/pl.png' },
        'netherlands': { name: 'Netherlands', flag: 'https://flagcdn.com/w40/nl.png', flagLg: 'https://flagcdn.com/w80/nl.png' },
        'austria': { name: 'Austria', flag: 'https://flagcdn.com/w40/at.png', flagLg: 'https://flagcdn.com/w80/at.png' },
        'portugal': { name: 'Portugal', flag: 'https://flagcdn.com/w40/pt.png', flagLg: 'https://flagcdn.com/w80/pt.png' },
        'sweden': { name: 'Sweden', flag: 'https://flagcdn.com/w40/se.png', flagLg: 'https://flagcdn.com/w80/se.png' }
    };

    var CATEGORY_PAGES = {
        'Work Visas': 'service.html',
        'Study Visas': 'study-visas.html'
    };

    var VISA_TYPES = {
        'Work Visas': {
            'Germany': ['Skilled Worker Visa', 'EU Blue Card', 'Job Seeker Visa'],
            'Czech Republic': ['Employee Card', 'Work Permit'],
            'Poland': ['Work Permit', 'Seasonal Work Visa'],
            'Netherlands': ['Highly Skilled Migrant Visa', 'TWV Work Permit'],
            'Austria': ['Red-White-Red Card', 'EU Blue Card'],
            'Sweden': ['Work Permit']
        },
        'Study Visas': {
            'Germany': ['Student Visa', 'Post-Study Work Visa', 'Language Course Visa'],
            'Poland': ['Student Visa', 'Research Visa'],
            'Czech Republic': ['Student Visa', 'Long-Term Study Visa']
        }
    };

    // Detailed dummy data for each visa type
    var VISA_INFO = {
        // ═══ WORK VISAS ═══
        'skilled-worker-visa': {
            title: 'Skilled Worker Visa',
            subtitle: 'For qualified professionals with recognized qualifications',
            overview: 'The German Skilled Worker Visa (Fachkräftevisum) allows qualified professionals with recognized foreign qualifications to live and work in Germany. It was introduced under the Skilled Immigration Act (Fachkräfteeinwanderungsgesetz) in March 2020 to attract international talent.',
            requirements: [
                'Recognized professional or academic qualification',
                'A concrete job offer from a German employer',
                'Qualification must match the job position',
                'Basic German language skills (A1-B1 depending on profession)',
                'Proof of financial means for the initial stay',
                'Valid passport and health insurance'
            ],
            process: [
                { title: 'Qualification Recognition', desc: 'Get your foreign qualification recognized as equivalent to a German qualification through the relevant authority.' },
                { title: 'Job Search', desc: 'Find a suitable position with a German employer that matches your recognized qualification.' },
                { title: 'Visa Application', desc: 'Apply for the Skilled Worker Visa at the German embassy/consulate in your home country with all required documents.' },
                { title: 'Entry & Registration', desc: 'Enter Germany, register at the local registration office, and apply for your residence permit within 90 days.' }
            ],
            processingTime: '1-3 months',
            validity: 'Up to 4 years (renewable)',
            cost: '€75 visa fee + €100 residence permit fee',
            highlights: [
                'Pathway to permanent residency after 4 years',
                'Family members can join (spouse + children)',
                'Freedom to change employers within your field',
                'Access to German social security system'
            ]
        },
        'eu-blue-card': {
            title: 'EU Blue Card',
            subtitle: 'For highly qualified professionals with university degrees',
            overview: 'The EU Blue Card is a work and residence permit for highly qualified non-EU nationals. It offers streamlined immigration with accelerated paths to permanent residence and is recognized across EU member states.',
            requirements: [
                'University degree (recognized in Germany) or equivalent qualification',
                'Binding job offer or employment contract',
                'Minimum annual gross salary of €45,300 (or €41,042 for shortage occupations)',
                'The employment must correspond to the qualification',
                'Health insurance coverage',
                'Valid travel document'
            ],
            process: [
                { title: 'Degree Verification', desc: 'Verify your university degree is recognized in Germany through the anabin database or credential evaluation.' },
                { title: 'Secure Employment', desc: 'Obtain a binding job offer meeting the minimum salary threshold from a German employer.' },
                { title: 'Apply at Embassy', desc: 'Submit your EU Blue Card application at the German embassy with employment contract, degree certificates, and supporting documents.' },
                { title: 'Residence Registration', desc: 'Register in Germany and collect your EU Blue Card residence permit from the local foreigners authority.' }
            ],
            processingTime: '2-8 weeks',
            validity: '4 years (or duration of employment + 3 months)',
            cost: '€75 visa fee + €100 residence permit fee',
            highlights: [
                'Permanent residency after 27 months (or 21 months with B1 German)',
                'Spouse receives unrestricted work permit',
                'Portability within EU after 18 months',
                'No labor market test required'
            ]
        },
        'job-seeker-visa': {
            title: 'Job Seeker Visa',
            subtitle: 'Search for employment in Germany for up to 6 months',
            overview: 'The Job Seeker Visa allows qualified professionals to enter Germany to look for a suitable job. You have 6 months to find employment matching your qualifications, after which you can switch to a work residence permit.',
            requirements: [
                'University degree recognized in Germany',
                'Proof of financial means (approx. €5,676 in blocked account or formal obligation letter)',
                'Health insurance for the duration of stay',
                'Proof of accommodation in Germany',
                'CV and motivation letter',
                'Basic German or English language proficiency'
            ],
            process: [
                { title: 'Prepare Documents', desc: 'Gather your recognized degree, financial proof, health insurance, and accommodation documents.' },
                { title: 'Embassy Application', desc: 'Apply at the German embassy in your home country. Attend an interview and submit biometrics.' },
                { title: 'Job Search in Germany', desc: 'Enter Germany and actively search for employment through job portals, networking, and career fairs.' },
                { title: 'Switch to Work Visa', desc: 'Once you find a job, apply to convert your Job Seeker Visa into a Skilled Worker Visa or EU Blue Card.' }
            ],
            processingTime: '4-12 weeks',
            validity: '6 months (non-renewable)',
            cost: '€75 visa fee',
            highlights: [
                'No job offer required before entry',
                'Can attend interviews and networking events',
                'Convertible to work visa upon finding employment',
                'Part-time probationary work (up to 10 hrs/week) permitted'
            ]
        },
        'employee-card': {
            title: 'Employee Card',
            subtitle: 'Czech Republic unified work and residence permit',
            overview: 'The Employee Card is a long-term residence permit that combines work and residence authorization in the Czech Republic. It is the most common permit for non-EU workers seeking employment in the country.',
            requirements: [
                'Valid passport (at least 2 blank pages)',
                'Employment contract or job offer in a registered vacancy',
                'Proof of accommodation in the Czech Republic',
                'Clean criminal record certificate',
                'Travel medical insurance for the initial period',
                'Proof of professional qualifications if required by the position'
            ],
            process: [
                { title: 'Find a Vacancy', desc: 'Your employer must register the position in the Central Registry of Vacancies at the Labour Office.' },
                { title: 'Submit Application', desc: 'Apply at the Czech embassy in your home country with the required documents and biometric data.' },
                { title: 'Wait for Processing', desc: 'The Ministry of Interior processes applications within 60-90 days.' },
                { title: 'Collect Permit', desc: 'Collect your Employee Card at the Ministry of Interior office in the Czech Republic.' }
            ],
            processingTime: '60-90 days',
            validity: 'Up to 2 years (renewable)',
            cost: 'CZK 2,500 (approx. €100)',
            highlights: [
                'Dual-purpose permit (work + residence)',
                'Renewable indefinitely',
                'Pathway to permanent residence after 5 years',
                'Family reunification possible after 15 months'
            ]
        },
        'work-permit': {
            title: 'Work Permit',
            subtitle: 'Authorization to work in the host country',
            overview: 'A Work Permit authorizes non-EU nationals to take up employment. The employer typically initiates the process, and the permit is tied to a specific employer and position. Requirements vary by country.',
            requirements: [
                'Valid passport',
                'Confirmed job offer from an employer',
                'Employer must demonstrate no suitable local candidates (labor market test)',
                'Professional qualifications relevant to the position',
                'Clean criminal record',
                'Health insurance and proof of accommodation'
            ],
            process: [
                { title: 'Employer Application', desc: 'Your employer applies for the work permit on your behalf at the local labor office.' },
                { title: 'Labor Market Test', desc: 'The labor office verifies no suitable EU candidates are available for the position.' },
                { title: 'Visa Application', desc: 'Apply for a long-stay visa at the embassy with the approved work permit.' },
                { title: 'Entry & Registration', desc: 'Enter the country and register with local authorities within the required timeframe.' }
            ],
            processingTime: '30-90 days',
            validity: '1-2 years (renewable)',
            cost: 'Varies by country (€50-€200)',
            highlights: [
                'Employer-sponsored process',
                'Renewable upon continued employment',
                'Can lead to permanent residency',
                'Some countries allow employer changes after initial period'
            ]
        },
        'seasonal-work-visa': {
            title: 'Seasonal Work Visa',
            subtitle: 'Short-term work permit for seasonal employment',
            overview: 'The Seasonal Work Visa (or permit) allows non-EU nationals to work in seasonal industries such as agriculture, tourism, and hospitality for a limited period, typically up to 9 months within a 12-month period.',
            requirements: [
                'Valid passport',
                'Seasonal employment contract',
                'Employer registered for seasonal work program',
                'Proof of accommodation (often provided by employer)',
                'Health insurance',
                'No criminal record'
            ],
            process: [
                { title: 'Employer Registration', desc: 'The seasonal employer registers the position and obtains approval from the labor office.' },
                { title: 'Worker Application', desc: 'Apply at the embassy with the seasonal work contract and supporting documents.' },
                { title: 'Entry & Work', desc: 'Enter the country and begin seasonal employment as specified in the contract.' },
                { title: 'Return or Extend', desc: 'Return home at the end of the season or apply for extension if eligible.' }
            ],
            processingTime: '2-6 weeks',
            validity: 'Up to 9 months per year',
            cost: '€50-€100',
            highlights: [
                'Fast processing times',
                'Accommodation often included',
                'Opportunity to earn European wages',
                'Can return for subsequent seasons'
            ]
        },
        'highly-skilled-migrant-visa': {
            title: 'Highly Skilled Migrant Visa',
            subtitle: 'Netherlands permit for knowledge workers and specialists',
            overview: 'The Highly Skilled Migrant (Kennismigrant) permit is for non-EU professionals recruited by a recognized sponsor (employer) in the Netherlands. It offers fast processing and attractive conditions for skilled workers.',
            requirements: [
                'Employment with a recognized sponsor (IND-registered employer)',
                'Minimum salary threshold (€5,008/month for age 30+, or €3,672 for under 30)',
                'Valid passport',
                'Clean criminal record',
                'TB certificate (for certain nationalities)',
                'The position must match the salary level'
            ],
            process: [
                { title: 'Employer Sponsorship', desc: 'Your Dutch employer must be a recognized sponsor (erkend referent) registered with the IND.' },
                { title: 'Application by Sponsor', desc: 'The employer submits the residence permit application to the IND on your behalf.' },
                { title: 'MVV Collection', desc: 'Collect your provisional residence permit (MVV) at the Dutch embassy if required.' },
                { title: 'Registration in NL', desc: 'Register in your municipality, collect your residence permit card, and obtain a BSN number.' }
            ],
            processingTime: '2 weeks (fast-track)',
            validity: 'Up to 5 years',
            cost: '€345 application fee',
            highlights: [
                '30% tax ruling benefit (tax-free allowance)',
                'Spouse gets open work permit',
                'Fast processing (2 weeks)',
                'No labor market test required'
            ]
        },
        'twv-work-permit': {
            title: 'TWV Work Permit',
            subtitle: 'Netherlands combined work and residence permit',
            overview: 'The TWV (Tewerkstellingsvergunning) is a standard work permit for non-EU nationals in the Netherlands. The employer applies for this permit through the UWV (Employee Insurance Agency) before the worker can apply for a residence permit.',
            requirements: [
                'Job offer from a Dutch employer',
                'Labor market test passed (no EU candidates available)',
                'Working conditions meet Dutch standards',
                'Valid passport and health insurance',
                'Employer must demonstrate recruitment efforts',
                'Position must be full-time (minimum 24 hours/week recommended)'
            ],
            process: [
                { title: 'Employer Applies at UWV', desc: 'Your employer submits the TWV application to the UWV, proving no suitable EU candidate exists.' },
                { title: 'Approval & GVVA', desc: 'If approved, a combined GVVA (residence + work permit) application is submitted to IND.' },
                { title: 'Embassy Visit', desc: 'Collect your MVV visa at the Dutch embassy and travel to the Netherlands.' },
                { title: 'Residence Permit', desc: 'Complete registration and collect your combined residence and work permit.' }
            ],
            processingTime: '5-8 weeks',
            validity: '1-3 years',
            cost: '€345 application fee',
            highlights: [
                'Combined work and residence authorization',
                'Employer-driven process',
                'Renewable upon continued employment',
                'Pathway to independent work permit'
            ]
        },
        'red-white-red-card': {
            title: 'Red-White-Red Card',
            subtitle: 'Austria\'s points-based immigration system for skilled workers',
            overview: 'The Red-White-Red Card (Rot-Weiß-Rot Karte) is Austria\'s primary work and residence permit for qualified third-country nationals. It uses a points-based system evaluating qualifications, work experience, language skills, and age.',
            requirements: [
                'Points-based eligibility (minimum 55 out of 90 points)',
                'Relevant university degree or vocational qualification',
                'Binding job offer from an Austrian employer',
                'Minimum salary based on the collective bargaining agreement',
                'German or English language skills (points-based)',
                'Under 55 years of age (age-based points)'
            ],
            process: [
                { title: 'Points Assessment', desc: 'Self-assess your points for qualifications (max 30), work experience (max 20), language (max 15), and age (max 25).' },
                { title: 'Application Submission', desc: 'Apply at the Austrian embassy with your job offer, qualification documents, and language certificates.' },
                { title: 'AMS Verification', desc: 'The Austrian Public Employment Service (AMS) verifies the employer and working conditions.' },
                { title: 'Card Issuance', desc: 'Receive your Red-White-Red Card upon arrival in Austria, valid for 2 years.' }
            ],
            processingTime: '6-8 weeks',
            validity: '2 years (then upgradeable to RWR Card Plus)',
            cost: '€120 application fee',
            highlights: [
                'Points-based transparent system',
                'RWR Card Plus after 2 years (open labor market access)',
                'Family reunification possible',
                'High quality of life in Austria'
            ]
        },
        // ═══ STUDY VISAS ═══
        'student-visa': {
            title: 'Student Visa',
            subtitle: 'Study at a European university with full visa support',
            overview: 'The Student Visa allows non-EU nationals to pursue higher education at accredited European universities. Many countries offer post-study work opportunities, making this an excellent pathway for establishing a career in Europe.',
            requirements: [
                'Admission letter from an accredited university',
                'Proof of financial means (blocked account or scholarship)',
                'Health insurance valid in the host country',
                'Academic transcripts and certificates',
                'Language proficiency (IELTS/TOEFL for English programs, or local language)',
                'Valid passport with at least 12 months validity'
            ],
            process: [
                { title: 'University Admission', desc: 'Apply and receive an acceptance letter from your chosen European university.' },
                { title: 'Financial Proof', desc: 'Open a blocked account or obtain scholarship documentation showing sufficient funds.' },
                { title: 'Visa Application', desc: 'Apply at the embassy with admission letter, financial proof, insurance, and other documents.' },
                { title: 'Enrollment', desc: 'Arrive, register with local authorities, enroll at university, and obtain your student residence permit.' }
            ],
            processingTime: '4-12 weeks',
            validity: '1-2 years (renewable for study duration)',
            cost: '€75-€100 visa fee',
            highlights: [
                'Part-time work permitted (120 full days or 240 half days/year in Germany)',
                'Free or low-cost tuition at many public universities',
                'Post-study job search visa available',
                'Pathway to work visa and permanent residency'
            ]
        },
        'post-study-work-visa': {
            title: 'Post-Study Work Visa',
            subtitle: 'Stay and work after graduation',
            overview: 'The Post-Study Work Visa allows graduates from European universities to remain in the country after completing their degree to seek employment. This is a crucial bridge between academic life and a professional career in Europe.',
            requirements: [
                'Completed degree from a recognized university in the host country',
                'Valid passport',
                'Proof of financial means during the job search period',
                'Health insurance coverage',
                'Degree certificate or confirmation of graduation',
                'Must apply before current residence permit expires'
            ],
            process: [
                { title: 'Graduation', desc: 'Complete your degree program and obtain your graduation certificate.' },
                { title: 'Apply for Extension', desc: 'Apply at the local foreigners authority for a post-study job search residence permit.' },
                { title: 'Job Search', desc: 'Actively search for employment matching your qualifications. Part-time work permitted.' },
                { title: 'Switch to Work Visa', desc: 'Upon finding employment, convert to a Skilled Worker Visa or EU Blue Card.' }
            ],
            processingTime: '2-4 weeks',
            validity: 'Up to 18 months (Germany), varies by country',
            cost: '€100 residence permit fee',
            highlights: [
                'Up to 18 months to find employment in Germany',
                'Unrestricted part-time work during search period',
                'Can take up any employment (not limited to study field)',
                'Seamless transition to work residence permit'
            ]
        },
        'language-course-visa': {
            title: 'Language Course Visa',
            subtitle: 'Learn German or other European languages',
            overview: 'The Language Course Visa allows non-EU nationals to attend intensive language courses in preparation for university studies or professional integration. It is particularly popular for those planning to study or work in Germany.',
            requirements: [
                'Enrollment in an intensive language course (min. 18 hours/week)',
                'Proof of financial means for the course duration',
                'Health insurance',
                'Proof of course fees paid or scholarship',
                'Valid passport',
                'Motivation letter explaining language learning goals'
            ],
            process: [
                { title: 'Course Enrollment', desc: 'Enroll in an accredited intensive language course at a recognized language school.' },
                { title: 'Visa Application', desc: 'Apply at the embassy with enrollment confirmation, financial proof, and supporting documents.' },
                { title: 'Language Study', desc: 'Attend classes, practice the language, and prepare for proficiency exams like TestDaF or Goethe.' },
                { title: 'Next Steps', desc: 'Upon completion, apply for a student visa or return home with enhanced language skills.' }
            ],
            processingTime: '4-8 weeks',
            validity: '3-12 months',
            cost: '€75 visa fee',
            highlights: [
                'Foundation for university admissions',
                'Cultural immersion experience',
                'Can be extended for further language study',
                'Improves chances for subsequent visa applications'
            ]
        },
        'research-visa': {
            title: 'Research Visa',
            subtitle: 'For researchers and PhD candidates',
            overview: 'The Research Visa is designed for scientists, researchers, and PhD candidates who have been accepted by a recognized research institution in Europe. It offers favorable conditions for conducting research and academic work.',
            requirements: [
                'Hosting agreement with a recognized research institution',
                'Master\'s degree or equivalent qualification',
                'Valid passport and health insurance',
                'Proof of financial means',
                'Research plan or project description',
                'Clean criminal record'
            ],
            process: [
                { title: 'Research Position', desc: 'Secure a research position and obtain a hosting agreement from the institution.' },
                { title: 'Visa Application', desc: 'Apply at the embassy with the hosting agreement and academic credentials.' },
                { title: 'Entry & Registration', desc: 'Enter the country and register with local authorities.' },
                { title: 'Research Work', desc: 'Begin your research. You may also teach and lecture at the institution.' }
            ],
            processingTime: '4-8 weeks',
            validity: 'Duration of research project (up to 5 years)',
            cost: '€75-€100 visa fee',
            highlights: [
                'Family members can work without restriction',
                'Intra-EU mobility for short research stays',
                'Path to permanent residence',
                'Access to university facilities and funding'
            ]
        },
        'long-term-study-visa': {
            title: 'Long-Term Study Visa',
            subtitle: 'Extended study residence permit',
            overview: 'The Long-Term Study Visa allows international students to pursue extended degree programs including bachelor\'s, master\'s, and doctoral studies. It provides a stable residence status for the full duration of academic studies.',
            requirements: [
                'Admission to an accredited university program',
                'Proof of sufficient financial resources',
                'Comprehensive health insurance',
                'Academic transcripts and prior qualifications',
                'Language certificate for the program language',
                'Valid passport'
            ],
            process: [
                { title: 'University Admission', desc: 'Receive acceptance from the university for a full degree program.' },
                { title: 'Financial Preparation', desc: 'Arrange funding through savings, scholarships, or sponsor guarantees.' },
                { title: 'Visa Application', desc: 'Apply for the long-term student visa at the embassy.' },
                { title: 'Annual Renewal', desc: 'Renew your residence permit annually with proof of academic progress and financial means.' }
            ],
            processingTime: '6-12 weeks',
            validity: '1 year (renewable for study duration)',
            cost: '€100-€150',
            highlights: [
                'Covers full duration of studies',
                'Part-time work usually permitted',
                'Access to student discounts and benefits',
                'Post-study work options available'
            ]
        }
    };
    // ─── Country code mapping for flags ───
    var COUNTRY_CODE_MAP = {
        'afghanistan': 'af', 'albania': 'al', 'algeria': 'dz', 'argentina': 'ar',
        'armenia': 'am', 'australia': 'au', 'austria': 'at', 'azerbaijan': 'az',
        'bahrain': 'bh', 'bangladesh': 'bd', 'belarus': 'by', 'belgium': 'be',
        'bosnia': 'ba', 'brazil': 'br', 'bulgaria': 'bg', 'cambodia': 'kh',
        'cameroon': 'cm', 'canada': 'ca', 'chile': 'cl', 'china': 'cn',
        'colombia': 'co', 'croatia': 'hr', 'cuba': 'cu', 'cyprus': 'cy',
        'czech republic': 'cz', 'czechia': 'cz', 'denmark': 'dk',
        'egypt': 'eg', 'estonia': 'ee', 'ethiopia': 'et', 'finland': 'fi',
        'france': 'fr', 'georgia': 'ge', 'germany': 'de', 'ghana': 'gh',
        'greece': 'gr', 'hungary': 'hu', 'iceland': 'is', 'india': 'in',
        'indonesia': 'id', 'iran': 'ir', 'iraq': 'iq', 'ireland': 'ie',
        'israel': 'il', 'italy': 'it', 'japan': 'jp', 'jordan': 'jo',
        'kazakhstan': 'kz', 'kenya': 'ke', 'korea': 'kr', 'south korea': 'kr',
        'kuwait': 'kw', 'latvia': 'lv', 'lebanon': 'lb', 'libya': 'ly',
        'lithuania': 'lt', 'luxembourg': 'lu', 'malaysia': 'my', 'malta': 'mt',
        'mexico': 'mx', 'moldova': 'md', 'mongolia': 'mn', 'montenegro': 'me',
        'morocco': 'ma', 'nepal': 'np', 'netherlands': 'nl', 'new zealand': 'nz',
        'nigeria': 'ng', 'north macedonia': 'mk', 'norway': 'no', 'oman': 'om',
        'pakistan': 'pk', 'palestine': 'ps', 'panama': 'pa', 'peru': 'pe',
        'philippines': 'ph', 'poland': 'pl', 'portugal': 'pt', 'qatar': 'qa',
        'romania': 'ro', 'russia': 'ru', 'saudi arabia': 'sa', 'senegal': 'sn',
        'serbia': 'sr', 'singapore': 'sg', 'slovakia': 'sk', 'slovenia': 'si',
        'south africa': 'za', 'spain': 'es', 'sri lanka': 'lk', 'sudan': 'sd',
        'sweden': 'se', 'switzerland': 'ch', 'syria': 'sy', 'taiwan': 'tw',
        'thailand': 'th', 'tunisia': 'tn', 'turkey': 'tr', 'turkiye': 'tr',
        'ukraine': 'ua', 'united arab emirates': 'ae', 'uae': 'ae',
        'united kingdom': 'gb', 'uk': 'gb', 'united states': 'us', 'usa': 'us',
        'uzbekistan': 'uz', 'vietnam': 'vn', 'yemen': 'ye', 'zambia': 'zm',
        'zimbabwe': 'zw'
    };

    function slugify(str) {
        return str.toLowerCase().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-');
    }

    function getFlagUrl(name) {
        var code = COUNTRY_CODE_MAP[name.toLowerCase()];
        return code ? 'https://flagcdn.com/w40/' + code + '.png' : '';
    }

    function getFlagUrlLg(name) {
        var code = COUNTRY_CODE_MAP[name.toLowerCase()];
        return code ? 'https://flagcdn.com/w80/' + code + '.png' : '';
    }

    // ─── Merge countries: hardcoded + custom from localStorage ───
    function getAllCountries() {
        var merged = {};
        for (var key in COUNTRIES) {
            merged[key] = COUNTRIES[key];
        }
        var custom = JSON.parse(localStorage.getItem('nv_custom_countries') || '[]');
        custom.forEach(function (c) {
            var slug = slugify(c.name);
            if (!merged[slug]) {
                var flagUrl = getFlagUrl(c.name);
                merged[slug] = {
                    name: c.name,
                    flag: flagUrl,
                    flagLg: getFlagUrlLg(c.name),
                    coverImage: c.coverImage || ''
                };
            }
        });
        // Also discover from posts
        var posts = JSON.parse(localStorage.getItem('nv_site_posts') || '[]');
        posts.forEach(function (p) {
            if (p.country && p.status === 'published') {
                var slug = slugify(p.country);
                if (!merged[slug]) {
                    merged[slug] = {
                        name: p.country,
                        flag: getFlagUrl(p.country),
                        flagLg: getFlagUrlLg(p.country)
                    };
                }
            }
        });
        return merged;
    }

    // ─── Build dynamic visa types from posts ───
    function getMergedVisaTypes(category) {
        var merged = {};
        var baseTypes = VISA_TYPES[category] || {};
        for (var country in baseTypes) {
            merged[country] = baseTypes[country].slice();
        }
        var posts = JSON.parse(localStorage.getItem('nv_site_posts') || '[]');
        posts.forEach(function (p) {
            if (p.status === 'published' && p.category === category && p.country && p.visaType) {
                if (!merged[p.country]) merged[p.country] = [];
                if (merged[p.country].indexOf(p.visaType) === -1) {
                    merged[p.country].push(p.visaType);
                }
            }
        });
        return merged;
    }

    function getParams() {
        var params = new URLSearchParams(window.location.search);
        return {
            page: params.get('page') || 'Work Visas',
            country: params.get('country') || '',
            type: params.get('type') || ''
        };
    }

    function formatDate(dateStr) {
        var d = new Date(dateStr);
        return d.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
    }

    function getRelatedPosts(category, countrySlug, typeSlug) {
        var posts = JSON.parse(localStorage.getItem('nv_site_posts') || '[]');
        return posts.filter(function (p) {
            return p.status === 'published' &&
                p.category === category &&
                slugify(p.country) === countrySlug &&
                slugify(p.visaType) === typeSlug;
        }).sort(function (a, b) { return new Date(b.date) - new Date(a.date); });
    }

    // Find the original visa type name from posts (preserves original casing)
    function findOriginalVisaTypeName(category, countrySlug, typeSlug) {
        var posts = JSON.parse(localStorage.getItem('nv_site_posts') || '[]');
        for (var i = 0; i < posts.length; i++) {
            var p = posts[i];
            if (p.status === 'published' && p.category === category &&
                slugify(p.country) === countrySlug && slugify(p.visaType) === typeSlug) {
                return p.visaType;
            }
        }
        // Fallback: derive from slug
        return typeSlug.replace(/-/g, ' ').replace(/\b\w/g, function (l) { return l.toUpperCase(); });
    }

    function renderPage() {
        try {
            var params = getParams();
            var allCountries = getAllCountries();
            var country = allCountries[params.country];
            var visaInfo = VISA_INFO[params.type]; // May be null for dynamic visa types
            var catPage = CATEGORY_PAGES[params.page] || 'service.html';

            // ─── Always update page title & breadcrumbs first (even for error states) ───
            var visaTypeName = '';
            if (visaInfo) {
                visaTypeName = visaInfo.title;
            } else if (params.type) {
                visaTypeName = findOriginalVisaTypeName(params.page, params.country, params.type);
            }

            // Helper to update header and breadcrumbs
            function updateHeaderAndBreadcrumbs() {
                // Update document title
                var titleParts = [];
                if (visaTypeName) titleParts.push(visaTypeName);
                if (country) titleParts.push(country.name);
                titleParts.push(params.page);
                document.title = titleParts.join(' — ') + ' | NVConsult';

                // Update page header
                var pageTitle = document.getElementById('visa-page-title');
                if (pageTitle) pageTitle.textContent = visaTypeName || params.page;

                // Update breadcrumbs with full hierarchy
                var breadcrumb = document.getElementById('visa-breadcrumb');
                if (breadcrumb) {
                    var crumbs = '<li class="breadcrumb-item"><a href="index.html" class="text-white">Home</a></li>';
                    crumbs += '<li class="breadcrumb-item"><a href="' + catPage + '" class="text-white">' + params.page + '</a></li>';

                    if (country) {
                        var flagImg = country.flag ? '<img src="' + country.flag + '" style="width:20px;vertical-align:middle;margin-right:4px;border-radius:2px;">' : '';
                        crumbs += '<li class="breadcrumb-item"><a href="country-detail.html?page=' + encodeURIComponent(params.page) + '&country=' + params.country + '" class="text-white">' + flagImg + ' ' + country.name + '</a></li>';
                    }

                    if (visaTypeName) {
                        crumbs += '<li class="breadcrumb-item active text-secondary">' + visaTypeName + '</li>';
                    }

                    breadcrumb.innerHTML = crumbs;
                }
            }

            // Always update header/breadcrumbs before any early returns
            updateHeaderAndBreadcrumbs();

            // If country not found at all, show error
            if (!country) {
                document.getElementById('visa-info-content').innerHTML =
                    '<div class="text-center py-5"><h3 class="text-muted">Country not found</h3>' +
                    '<a href="' + catPage + '" class="btn btn-primary rounded-pill px-5 py-3 mt-3">Browse ' + params.page + '</a></div>';
                return;
            }

            // Get related posts using slug-based matching
            var relatedPosts = getRelatedPosts(params.page, params.country, params.type);

            // If no hardcoded info AND no posts, show not found with proper hierarchy
            if (!visaInfo && relatedPosts.length === 0) {
                document.getElementById('visa-info-content').innerHTML =
                    '<div class="text-center py-5"><h3 class="text-muted">No content available yet for ' + visaTypeName + ' in ' + country.name + '</h3>' +
                    '<p class="text-muted">Check back soon or browse other options.</p>' +
                    '<a href="country-detail.html?page=' + encodeURIComponent(params.page) + '&country=' + params.country + '" class="btn btn-primary rounded-pill px-5 py-3 mt-3">Back to ' + country.name + '</a></div>';
                return;
            }

            // Get other visa types for the sidebar
            var mergedVisaTypes = getMergedVisaTypes(params.page);
            var allTypesForCountry = mergedVisaTypes[country.name] || [];
            if (allTypesForCountry.length === 0) {
                for (var mk in mergedVisaTypes) {
                    if (slugify(mk) === params.country) {
                        allTypesForCountry = mergedVisaTypes[mk];
                        break;
                    }
                }
            }
            var otherTypes = allTypesForCountry.filter(function (t) {
                return slugify(t) !== params.type;
            });

            // ─── Build page content ───
            var html = '';
            var flagLg = country.flagLg || country.flag || '';
            var flagLgImg = flagLg ? '<img src="' + flagLg + '" class="country-flag-lg" alt="' + country.name + '">' : '';

            // Determine what to show: posts take priority over hardcoded info
            var hasUserPosts = relatedPosts.length > 0;
            // Only show hardcoded info when there are NO user posts for this type
            var showHardcodedInfo = visaInfo && !hasUserPosts;

            // Hero section
            html += '<div class="visa-hero rounded-4 mb-5">' +
                '<div class="container">' +
                    '<div class="row align-items-center">' +
                        '<div class="col-lg-8">' +
                            '<span class="visa-badge"><i class="fas fa-passport me-2"></i>' + params.page + '</span>' +
                            '<h1>' + flagLgImg + visaTypeName + '</h1>' +
                            '<p class="text-white-50 fs-5 mb-0">' + ((visaInfo && !hasUserPosts) ? visaInfo.subtitle : visaTypeName + ' in ' + country.name) + '</p>' +
                        '</div>' +
                        '<div class="col-lg-4 text-end d-none d-lg-block">' +
                            '<div style="font-size:5rem;opacity:0.15;"><i class="fas fa-passport"></i></div>' +
                        '</div>' +
                    '</div>' +
                '</div>' +
            '</div>';

            // ─── Main content area ───
            html += '<div class="row g-4"><div class="col-lg-8">';

            // ─── User Posts / Articles (PRIMARY content when they exist) ───
            if (hasUserPosts) {
                html += '<div class="info-card">' +
                    '<h3><i class="fas fa-newspaper"></i>Articles & Guides</h3>';

                relatedPosts.forEach(function (post) {
                    var postUrl = 'blog-post.html?slug=' + post.slug;
                    var imgHtml = post.image ? '<img src="' + post.image + '" alt="' + post.title + '" style="width:100%;max-height:200px;object-fit:cover;border-radius:10px;margin-bottom:16px;">' : '';
                    html += '<div style="margin-bottom:24px;padding-bottom:24px;border-bottom:1px solid #eee;">' +
                        imgHtml +
                        '<h5 style="margin-bottom:8px;"><a href="' + postUrl + '" style="color:#0B3C5D;text-decoration:none;">' + post.title + '</a></h5>' +
                        '<div style="font-size:0.85rem;color:#888;margin-bottom:8px;">' +
                            '<i class="fas fa-calendar-alt me-1"></i>' + formatDate(post.date) +
                            '<span class="ms-3"><i class="fas fa-user me-1"></i>' + post.author + '</span>' +
                        '</div>' +
                        '<p style="color:#555;line-height:1.6;">' + post.excerpt + '</p>' +
                        '<a href="' + postUrl + '" class="btn btn-sm btn-outline-primary rounded-pill px-4">Read Full Article <i class="fas fa-arrow-right ms-1"></i></a>' +
                    '</div>';
                });

                html += '</div>';
            }

            // ─── Hardcoded VISA_INFO (only shown when NO user posts exist as fallback) ───
            if (showHardcodedInfo) {
                html += '<div class="info-card">' +
                    '<h3><i class="fas fa-info-circle"></i>Overview</h3>' +
                    '<p style="color:#555;line-height:1.8;font-size:1.05rem;">' + visaInfo.overview + '</p>' +
                '</div>';

                html += '<div class="info-card">' +
                    '<h3><i class="fas fa-clipboard-check"></i>Requirements</h3>' +
                    '<ul>' + visaInfo.requirements.map(function (r) {
                        return '<li><i class="fas fa-check-circle"></i><span>' + r + '</span></li>';
                    }).join('') + '</ul>' +
                '</div>';

                html += '<div class="info-card">' +
                    '<h3><i class="fas fa-route"></i>Application Process</h3>' +
                    visaInfo.process.map(function (step, i) {
                        return '<div class="step-item">' +
                            '<div class="step-number">' + (i + 1) + '</div>' +
                            '<div class="step-content">' +
                                '<h5>' + step.title + '</h5>' +
                                '<p>' + step.desc + '</p>' +
                            '</div>' +
                        '</div>';
                    }).join('') +
                '</div>';
            }

            html += '</div>'; // close col-lg-8

            // ─── Sidebar ───
            html += '<div class="col-lg-4">';

            // Quick facts (only when showing hardcoded visa info as fallback)
            if (showHardcodedInfo) {
                html += '<div class="info-card" style="background:linear-gradient(135deg,#0B3C5D,#145580);border:none;">' +
                    '<h3 style="color:#F59E0B;"><i class="fas fa-bolt" style="color:#F59E0B;"></i>Quick Facts</h3>' +
                    '<ul style="border:none;">' +
                        '<li style="border-color:rgba(255,255,255,0.1);color:rgba(255,255,255,0.9);"><i class="fas fa-clock" style="color:#F59E0B;"></i><span><strong style="color:#fff;">Processing Time</strong><br>' + visaInfo.processingTime + '</span></li>' +
                        '<li style="border-color:rgba(255,255,255,0.1);color:rgba(255,255,255,0.9);"><i class="fas fa-calendar-alt" style="color:#F59E0B;"></i><span><strong style="color:#fff;">Validity</strong><br>' + visaInfo.validity + '</span></li>' +
                        '<li style="border-color:rgba(255,255,255,0.1);color:rgba(255,255,255,0.9);"><i class="fas fa-euro-sign" style="color:#F59E0B;"></i><span><strong style="color:#fff;">Cost</strong><br>' + visaInfo.cost + '</span></li>' +
                    '</ul>' +
                '</div>';

                html += '<div class="info-card">' +
                    '<h3><i class="fas fa-star"></i>Key Benefits</h3>' +
                    '<ul>' + visaInfo.highlights.map(function (h) {
                        return '<li><i class="fas fa-check-circle" style="color:#28a745;"></i><span>' + h + '</span></li>';
                    }).join('') + '</ul>' +
                '</div>';
            }

            // Other visa types sidebar
            if (otherTypes.length > 0) {
                html += '<div class="info-card">' +
                    '<h3><i class="fas fa-passport"></i>Other ' + country.name + ' Visas</h3>' +
                    '<div class="other-types">' +
                    otherTypes.map(function (t) {
                        var tSlug = slugify(t);
                        return '<a href="visa-info.html?page=' + encodeURIComponent(params.page) + '&country=' + params.country + '&type=' + tSlug + '" class="other-type-link"><i class="fas fa-arrow-right"></i>' + t + '</a>';
                    }).join('') +
                    '</div>' +
                '</div>';
            }

            // CTA
            html += '<div class="cta-visa">' +
                '<h3>Need Help With This Visa?</h3>' +
                '<p>Book a free consultation and our experts will guide you through the entire process.</p>' +
                '<a href="#" class="btn btn-primary border-secondary rounded-pill py-3 px-5">Book Free Consultation</a>' +
            '</div>';

            html += '</div>'; // close col-lg-4
            html += '</div>'; // close row

            document.getElementById('visa-info-content').innerHTML = html;
        } catch (err) {
            console.error('[NVConsult] visa-info renderPage error:', err);
            var contentEl = document.getElementById('visa-info-content');
            if (contentEl) {
                contentEl.innerHTML =
                    '<div class="text-center py-5"><h3 class="text-muted">Something went wrong loading this page</h3>' +
                    '<p class="text-muted">Please try again or browse other options.</p>' +
                    '<a href="service.html" class="btn btn-primary rounded-pill px-5 py-3 mt-3 me-2">Work Visas</a>' +
                    '<a href="study-visas.html" class="btn btn-outline-primary rounded-pill px-5 py-3 mt-3">Study Visas</a></div>';
            }
        }
    }

    document.addEventListener('DOMContentLoaded', renderPage);
})();

