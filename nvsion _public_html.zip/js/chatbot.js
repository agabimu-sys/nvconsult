// NVConsult Chatbot — Groq-Powered AI Assistant (Premium)
(function () {
    'use strict';

    // ─── Configuration ───
    var GROQ_API_KEY = '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';
    var GROQ_MODEL = 'groq/compound-mini';
    var GROQ_ENDPOINT = 'https://api.groq.com/openai/v1/chat/completions';

    // ─── SVG Icons ───
    var ICONS = {
        chat: '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>',
        close: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
        send: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>',
        minimize: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="5" y1="12" x2="19" y2="12"/></svg>',
        bot: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="10" rx="3"/><circle cx="12" cy="5" r="2"/><line x1="12" y1="7" x2="12" y2="11"/><circle cx="8.5" cy="15.5" r="1" fill="currentColor"/><circle cx="15.5" cy="15.5" r="1" fill="currentColor"/><path d="M9 19h6"/></svg>',
        user: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
        visa: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>',
        study: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>',
        briefcase: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>',
        tag: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>',
        sparkle: '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L14.09 8.26L20 9.27L15.55 13.97L16.91 20L12 16.9L7.09 20L8.45 13.97L4 9.27L9.91 8.26L12 2Z"/></svg>'
    };

    // ─── Website Knowledge Base ───
    var WEBSITE_KNOWLEDGE = [
        'NVConsult (nvconsult.eu) is a European immigration and visa consultation company.',
        'NVConsult helps people relocate to Europe for work, study, and career opportunities.',
        'Contact email: info@nvconsult.eu | WhatsApp: +420 608 705 861',
        '--- CONSULTATION PLANS ---',
        'Free Consultation (€0): 15-minute assessment call, general visa overview, eligibility check, no obligation, honest advice guaranteed. Book at the Consultation Plans page.',
        'Premium Support (€100): 2-month program including visa-sponsored job guidance, CV + LinkedIn optimization, application strategy plan, 2-month ongoing support, priority WhatsApp access. Best value plan.',
        '--- WORK VISAS ---',
        'NVConsult helps with work visa applications for European countries including Germany, Czech Republic, Poland, Netherlands, Austria, and Portugal.',
        'Germany offers the EU Blue Card for skilled professionals. The Blue Card 2025 salary thresholds: Standard professions €43,800/year, Shortage occupations (IT, Engineering, Healthcare) €39,682/year.',
        'Germany Blue Card benefits: Permanent residence after 21-33 months, family reunification, Schengen travel freedom, pathway to citizenship.',
        'Czech Republic offers Employee Cards and is a hidden gem of Central Europe with booming tech sector in Prague.',
        'Poland has a simplified work permit process and is one of Europe\'s fastest growing economies.',
        'Netherlands has the Highly Skilled Migrant program that fast-tracks work permits.',
        'Portugal offers D7 and Digital Nomad visas, popular for tech professionals and remote workers.',
        'Austria offers low tuition and work opportunities for skilled professionals.',
        '--- STUDY VISAS ---',
        'NVConsult helps with study visa applications for European universities.',
        'Countries with free or low-cost tuition: Germany (free at public universities), Norway (free), Czech Republic (free for Czech-taught programs), Austria (very low tuition).',
        'Popular study programs: Engineering, Computer Science, Business Administration, Medicine.',
        'Student visa requirements typically include: acceptance letter, proof of financial means, health insurance, language proficiency certificate.',
        'Scholarships available: DAAD (Germany), Erasmus Mundus (EU-wide), Holland Scholarship (Netherlands).',
        '--- JOBS ABROAD ---',
        'NVConsult provides job search support and guidance for finding employment in Europe.',
        'Services include visa-sponsored job guidance, CV optimization for European employers, LinkedIn profile optimization.',
        '--- WEBSITE PAGES ---',
        'Work Visas: service.html | Study Visas: study-visas.html | Jobs Abroad: jobs-abroad.html',
        'Consultation Plans: pricing.html | About Us: about.html | Contact: contact.html | Blog: blog.html'
    ].join('\n');

    var SYSTEM_PROMPT = 'You are the official AI assistant for NVConsult (nvconsult.eu), a European immigration consultancy.\n\n' +
        'RESPONSE STYLE:\n' +
        '- Be warm, professional, and helpful like a real consultant.\n' +
        '- For greetings (hi, hello, hey, etc): Welcome them warmly and ask how you can help with their European immigration journey.\n' +
        '- Keep responses 2-5 sentences. Be informative but concise.\n' +
        '- Use plain text only. No markdown, no bullet points, no asterisks, no numbered lists.\n' +
        '- When relevant, mention specific countries, visa types, or plans from the knowledge base.\n' +
        '- Naturally suggest booking the Free Consultation or Premium Plan when appropriate.\n' +
        '- If asked about something not in the knowledge base, recommend speaking with the NVConsult team via Free Consultation or emailing info@nvconsult.eu.\n' +
        '- When referencing website sections, mention the page name naturally (e.g. "our Work Visas page").\n\n' +
        'KNOWLEDGE BASE:\n' + WEBSITE_KNOWLEDGE;

    var conversationHistory = [];

    // ─── Build Widget ───
    function buildChatWidget() {
        var toggle = document.createElement('button');
        toggle.className = 'nvc-toggle';
        toggle.id = 'nvc-toggle';
        toggle.setAttribute('aria-label', 'Open chat');
        toggle.innerHTML =
            '<span class="nvc-toggle-icon nvc-toggle-chat">' + ICONS.chat + '</span>' +
            '<span class="nvc-toggle-icon nvc-toggle-close">' + ICONS.close + '</span>' +
            '<span class="nvc-badge" id="nvc-badge">1</span>';
        document.body.appendChild(toggle);

        var win = document.createElement('div');
        win.className = 'nvc-window';
        win.id = 'nvc-window';
        win.innerHTML =
            // Header with logo
            '<div class="nvc-header">' +
            '<div class="nvc-header-left">' +
            '<img src="img/logo.jpeg" alt="NVConsult" class="nvc-logo" />' +
            '<div class="nvc-header-text">' +
            '<span class="nvc-header-title">NVConsult Assistant</span>' +
            '<span class="nvc-header-status"><i class="nvc-status-dot"></i>Online now</span>' +
            '</div>' +
            '</div>' +
            '<button class="nvc-header-btn" id="nvc-minimize" aria-label="Minimize">' + ICONS.minimize + '</button>' +
            '</div>' +
            // Welcome banner
            '<div class="nvc-welcome">' +
            '<div class="nvc-welcome-inner">' +
            '<div class="nvc-welcome-icon">' + ICONS.sparkle + '</div>' +
            '<span>Your European immigration guide</span>' +
            '</div>' +
            '</div>' +
            // Messages
            '<div class="nvc-body" id="nvc-body"></div>' +
            // Input
            '<div class="nvc-input-wrap">' +
            '<input type="text" class="nvc-input" id="nvc-input" placeholder="Ask about visas, jobs, plans..." autocomplete="off" />' +
            '<button class="nvc-send" id="nvc-send" aria-label="Send">' + ICONS.send + '</button>' +
            '</div>' +
            '<div class="nvc-powered">Powered by NVConsult AI</div>';
        document.body.appendChild(win);
    }

    // ─── Messages ───
    function addMessage(type, text, withQuickActions) {
        var body = document.getElementById('nvc-body');
        var row = document.createElement('div');
        row.className = 'nvc-row nvc-' + type;

        var avatarHtml = type === 'bot'
            ? '<div class="nvc-msg-avatar nvc-bot-av"><img src="img/logo.jpeg" alt="NV" class="nvc-av-img" /></div>'
            : '<div class="nvc-msg-avatar nvc-user-av">' + ICONS.user + '</div>';

        row.innerHTML = avatarHtml + '<div class="nvc-bubble">' + formatResponse(text) + '</div>';
        body.appendChild(row);

        if (withQuickActions && type === 'bot') {
            var qw = document.createElement('div');
            qw.className = 'nvc-quick-wrap';
            var options = [
                { icon: ICONS.visa, text: 'Work Visas', query: 'Tell me about work visa options in Europe' },
                { icon: ICONS.study, text: 'Study Abroad', query: 'Tell me about study visas in Europe' },
                { icon: ICONS.briefcase, text: 'Find Jobs', query: 'How can I find jobs in Europe?' },
                { icon: ICONS.tag, text: 'View Plans', query: 'What consultation plans do you offer and pricing?' }
            ];
            options.forEach(function (o) {
                var btn = document.createElement('button');
                btn.className = 'nvc-quick';
                btn.innerHTML = '<span class="nvc-quick-icon">' + o.icon + '</span><span>' + o.text + '</span>';
                btn.addEventListener('click', function () { qw.remove(); handleUserMessage(o.query); });
                qw.appendChild(btn);
            });
            body.appendChild(qw);
        }
        body.scrollTop = body.scrollHeight;
    }

    function formatResponse(text) {
        text = text.replace(/\b(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener">$1</a>');
        var pageMap = {
            'Work Visas page': 'service.html', 'Study Visas page': 'study-visas.html',
            'Jobs Abroad page': 'jobs-abroad.html', 'Consultation Plans page': 'pricing.html',
            'About Us page': 'about.html', 'Contact page': 'contact.html',
            'Blog page': 'blog.html', 'CV Maker page': 'cv-maker.html'
        };
        Object.keys(pageMap).forEach(function (label) {
            text = text.replace(new RegExp(label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'),
                '<a href="' + pageMap[label] + '">' + label + '</a>');
        });
        return text.replace(/\n/g, '<br>');
    }

    function showTyping() {
        var body = document.getElementById('nvc-body');
        var row = document.createElement('div');
        row.className = 'nvc-row nvc-bot';
        row.id = 'nvc-typing';
        row.innerHTML =
            '<div class="nvc-msg-avatar nvc-bot-av"><img src="img/logo.jpeg" alt="NV" class="nvc-av-img" /></div>' +
            '<div class="nvc-bubble nvc-typing-bubble"><span class="nvc-dot"></span><span class="nvc-dot"></span><span class="nvc-dot"></span></div>';
        body.appendChild(row);
        body.scrollTop = body.scrollHeight;
    }

    function hideTyping() { var t = document.getElementById('nvc-typing'); if (t) t.remove(); }

    // ─── Groq API ───
    function callGroq(userMessage, cb) {
        conversationHistory.push({ role: 'user', content: userMessage });
        var messages = [{ role: 'system', content: SYSTEM_PROMPT }].concat(conversationHistory.slice(-10));
        var pageContent = getPageContent();
        if (pageContent) messages[0].content += '\n\n--- CURRENT PAGE ---\n' + pageContent;

        var xhr = new XMLHttpRequest();
        xhr.open('POST', GROQ_ENDPOINT, true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.setRequestHeader('Authorization', 'Bearer ' + GROQ_API_KEY);
        xhr.onload = function () {
            if (xhr.status === 200) {
                try {
                    var reply = JSON.parse(xhr.responseText).choices[0].message.content;
                    // Strip any thinking/reasoning tags or blocks
                    reply = reply.replace(/<think>[\s\S]*?<\/think>/gi, '');
                    reply = reply.replace(/<\/think>/gi, '');
                    reply = reply.replace(/^[\s\S]*?(?:Here's|Let me|I'll|Step \d|Thinking|Analysis|Draft)[\s\S]*?\n\n/i, '');
                    reply = reply.replace(/\*\*/g, '').replace(/\*/g, '').replace(/^[\-•]\s/gm, '');
                    reply = reply.trim();
                    if (!reply) reply = 'I appreciate your question! For the most accurate guidance, I would recommend booking our Free Consultation at nvconsult.eu or contacting us at info@nvconsult.eu.';
                    conversationHistory.push({ role: 'assistant', content: reply });
                    cb(null, reply);
                } catch (e) { cb('Sorry, I had trouble processing that. Please try again.'); }
            } else if (xhr.status === 401) {
                cb('The assistant is being configured. Contact us at info@nvconsult.eu or WhatsApp.');
            } else { cb('Temporary issue — please try again or contact info@nvconsult.eu.'); }
        };
        xhr.onerror = function () { cb('Connection issue. Check your internet or contact info@nvconsult.eu.'); };
        xhr.send(JSON.stringify({ model: GROQ_MODEL, messages: messages, temperature: 0.6, max_tokens: 600, top_p: 0.9 }));
    }

    function getPageContent() {
        try {
            var el = document.querySelector('main') || document.querySelector('.container-fluid');
            if (!el) return '';
            var clone = el.cloneNode(true);
            clone.querySelectorAll('script,style,nav,.footer,.copyright,.nvc-window,.nvc-toggle').forEach(function (n) { n.remove(); });
            return clone.textContent.replace(/\s+/g, ' ').trim().substring(0, 2000);
        } catch (e) { return ''; }
    }

    function handleUserMessage(msg) {
        if (!msg || !msg.trim()) return;
        addMessage('user', msg.trim());
        var input = document.getElementById('nvc-input');
        var send = document.getElementById('nvc-send');
        input.value = '';
        send.disabled = true;
        showTyping();
        callGroq(msg.trim(), function (err, reply) {
            hideTyping();
            send.disabled = false;
            addMessage('bot', err || reply);
            input.focus();
        });
    }

    function toggleChat() {
        var win = document.getElementById('nvc-window');
        var tog = document.getElementById('nvc-toggle');
        var open = win.classList.contains('nvc-open');
        if (open) {
            win.classList.remove('nvc-open');
            tog.classList.remove('nvc-active');
        } else {
            win.classList.add('nvc-open');
            tog.classList.add('nvc-active');
            var badge = document.getElementById('nvc-badge');
            if (badge) badge.remove();
            setTimeout(function () { document.getElementById('nvc-input').focus(); }, 350);
        }
    }

    function init() {
        if (window.location.pathname.indexOf('admin') !== -1) return;
        buildChatWidget();

        document.getElementById('nvc-toggle').addEventListener('click', toggleChat);
        document.getElementById('nvc-minimize').addEventListener('click', toggleChat);
        document.getElementById('nvc-send').addEventListener('click', function () {
            handleUserMessage(document.getElementById('nvc-input').value);
        });
        document.getElementById('nvc-input').addEventListener('keypress', function (e) {
            if (e.key === 'Enter') handleUserMessage(this.value);
        });

        var seen = sessionStorage.getItem('nvc_greeted');
        if (!seen) {
            sessionStorage.setItem('nvc_greeted', '1');
            setTimeout(function () {
                document.getElementById('nvc-window').classList.add('nvc-open');
                document.getElementById('nvc-toggle').classList.add('nvc-active');
                var badge = document.getElementById('nvc-badge');
                if (badge) badge.remove();
                addMessage('bot', 'Hi there! I\'m your NVConsult assistant. How can I help you with your European immigration journey today?', true);
            }, 1500);
        } else {
            var badge = document.getElementById('nvc-badge');
            if (badge) badge.remove();
        }
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();
