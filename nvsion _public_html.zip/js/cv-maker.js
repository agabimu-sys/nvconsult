// CV Studio — NVConsult
(function(){
'use strict';
var TPLS=[
{id:'executive',name:'Executive Slate',cat:'Corporate',cls:'tpl-preview-executive'},
{id:'aurora',name:'Aurora Ivory',cat:'Finance',cls:'tpl-preview-aurora'},
{id:'maxwell',name:'Maxwell Dark',cat:'Consultant',cls:'tpl-preview-maxwell'},
{id:'luna',name:'Luna Editorial',cat:'Marketing',cls:'tpl-preview-luna'},
{id:'vertex',name:'Vertex Tech',cat:'Data · IT',cls:'tpl-preview-vertex'},
{id:'herald',name:'Herald Classic',cat:'Law · Gov',cls:'tpl-preview-herald'},
{id:'nordic',name:'Nordic Clean',cat:'Minimal',cls:'tpl-preview-nordic'},
{id:'metro',name:'Metro Bold',cat:'Design',cls:'tpl-preview-metro'},
{id:'cascade',name:'Cascade Pro',cat:'Engineering',cls:'tpl-preview-cascade'},
{id:'zenith',name:'Zenith Modern',cat:'Startup',cls:'tpl-preview-zenith'},
{id:'ivory',name:'Ivory Elegant',cat:'Academic',cls:'tpl-preview-ivory'},
{id:'cobalt',name:'Cobalt Edge',cat:'Sales',cls:'tpl-preview-cobalt'}
];
var COLORS=['#0B3C5D','#F59E0B','#059669','#7C3AED','#DC2626','#2563EB','#0891B2','#334155','#be185d','#65a30d','#0d9488','#6366f1','#ea580c','#4f46e5','#0369a1','#b91c1c','#15803d','#7e22ce','#a16207','#525252'];
var S={tpl:'executive',color:'#0B3C5D',name:'',title:'',email:'',phone:'',location:'',linkedin:'',summary:'',exp:[],edu:[],skills:[],langs:[],custom:[]};
window.S=S;

document.addEventListener('DOMContentLoaded',function(){renderTplGrid();renderSwatches();renderResumes();render();});

function renderTplGrid(){
    var el=document.getElementById('tplGrid');if(!el)return;
    el.innerHTML=TPLS.map(function(t){
        return '<div class="cvs-tpl-thumb'+(S.tpl===t.id?' active':'')+'" onclick="selectTpl(\''+t.id+'\')"><div class="tpl-preview '+t.cls+'"></div><div class="tpl-name">'+t.name+'</div><div class="tpl-cat">'+t.cat+'</div></div>';
    }).join('');
}
window.selectTpl=function(id){S.tpl=id;renderTplGrid();render();};

function renderSwatches(){
    var el=document.getElementById('swatches');if(!el)return;
    el.innerHTML=COLORS.map(function(c){return '<div class="cvs-swatch'+(S.color===c?' active':'')+'" style="background:'+c+'" onclick="pickColor(\''+c+'\')"></div>';}).join('');
}
window.pickColor=function(c){
    if(!c||c.charAt(0)!=='#')return;
    S.color=c;renderSwatches();
    var hp=document.getElementById('hexPicker'),hi=document.getElementById('hexInput');
    if(hp)hp.value=c;if(hi)hi.value=c;
    render();
};

window.switchView=function(v){
    document.querySelectorAll('.cvs-view-btn').forEach(function(b){b.classList.toggle('active',b.dataset.view===v);});
    document.querySelectorAll('.cvs-view').forEach(function(el){el.classList.remove('active');});
    document.getElementById(v==='edit'?'editView':'previewView').classList.add('active');
    if(v==='preview')render();
};

window.toggleCard=function(){};

// Custom Sections
window.addCustomSection=function(){
    S.custom.push({title:'Custom Section',content:''});
    renderCustomSections();
};
function renderCustomSections(){
    var el=document.getElementById('customSections');if(!el)return;
    el.innerHTML=S.custom.map(function(cs,i){
        return '<div class="cvs-section-card"><div class="cvs-custom-sec-head"><input value="'+esc(cs.title)+'" oninput="S.custom['+i+'].title=this.value;render()"><button class="cvs-entry-del" onclick="delCustom('+i+')"><i class="fas fa-trash-alt"></i></button></div><div class="cvs-field"><label>Content</label><textarea rows="3" oninput="S.custom['+i+'].content=this.value;render()">'+esc(cs.content)+'</textarea></div></div>';
    }).join('');
}
window.delCustom=function(i){S.custom.splice(i,1);renderCustomSections();render();};

function readForm(){
    S.name=val('f-name');S.title=val('f-title');S.email=val('f-email');
    S.phone=val('f-phone');S.location=val('f-location');S.linkedin=val('f-linkedin');S.summary=val('f-summary');
}
function val(id){var e=document.getElementById(id);return e?e.value:'';}
function esc(s){return(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}

window.addExp=function(){S.exp.push({role:'',company:'',from:'',to:'',desc:''});renderExp();};
function renderExp(){
    var el=document.getElementById('expList');if(!el)return;
    el.innerHTML=S.exp.map(function(e,i){
        return '<div class="cvs-entry"><div class="cvs-entry-head"><span class="cvs-entry-num">'+(i+1)+'</span><button class="cvs-entry-del" onclick="delExp('+i+')"><i class="fas fa-trash-alt"></i></button></div><div class="cvs-form-grid"><div class="cvs-field"><label>Job Title</label><input value="'+esc(e.role)+'" oninput="S.exp['+i+'].role=this.value;render()"></div><div class="cvs-field"><label>Company</label><input value="'+esc(e.company)+'" oninput="S.exp['+i+'].company=this.value;render()"></div><div class="cvs-field"><label>From</label><input value="'+esc(e.from)+'" oninput="S.exp['+i+'].from=this.value;render()"></div><div class="cvs-field"><label>To</label><input value="'+esc(e.to)+'" oninput="S.exp['+i+'].to=this.value;render()"></div><div class="cvs-field" style="grid-column:1/-1"><label>Description</label><textarea rows="2" oninput="S.exp['+i+'].desc=this.value;render()">'+esc(e.desc)+'</textarea></div></div></div>';
    }).join('');
}
window.delExp=function(i){S.exp.splice(i,1);renderExp();render();};

window.addEdu=function(){S.edu.push({degree:'',school:'',from:'',to:''});renderEdu();};
function renderEdu(){
    var el=document.getElementById('eduList');if(!el)return;
    el.innerHTML=S.edu.map(function(e,i){
        return '<div class="cvs-entry"><div class="cvs-entry-head"><span class="cvs-entry-num">'+(i+1)+'</span><button class="cvs-entry-del" onclick="delEdu('+i+')"><i class="fas fa-trash-alt"></i></button></div><div class="cvs-form-grid"><div class="cvs-field"><label>Degree</label><input value="'+esc(e.degree)+'" oninput="S.edu['+i+'].degree=this.value;render()"></div><div class="cvs-field"><label>School</label><input value="'+esc(e.school)+'" oninput="S.edu['+i+'].school=this.value;render()"></div><div class="cvs-field"><label>From</label><input value="'+esc(e.from)+'" oninput="S.edu['+i+'].from=this.value;render()"></div><div class="cvs-field"><label>To</label><input value="'+esc(e.to)+'" oninput="S.edu['+i+'].to=this.value;render()"></div></div></div>';
    }).join('');
}
window.delEdu=function(i){S.edu.splice(i,1);renderEdu();render();};

window.addSkill=function(){var inp=document.getElementById('skillInput');if(!inp||!inp.value.trim())return;S.skills.push(inp.value.trim());inp.value='';renderSkills();render();};
function renderSkills(){
    var el=document.getElementById('skillTags');if(!el)return;
    el.innerHTML=S.skills.map(function(s,i){return '<span class="cvs-tag">'+esc(s)+'<button onclick="delSkill('+i+')">&times;</button></span>';}).join('');
}
window.delSkill=function(i){S.skills.splice(i,1);renderSkills();render();};

window.addLang=function(){S.langs.push({name:'',level:'Intermediate'});renderLangs();};
function renderLangs(){
    var el=document.getElementById('langList');if(!el)return;
    var lvs=['Beginner','Elementary','Intermediate','Upper-Intermediate','Advanced','Native'];
    el.innerHTML=S.langs.map(function(l,i){
        return '<div class="cvs-entry" style="padding:8px 12px"><div class="cvs-form-grid" style="align-items:end"><div class="cvs-field"><label>Language</label><input value="'+esc(l.name)+'" oninput="S.langs['+i+'].name=this.value;render()"></div><div class="cvs-field"><label>Level</label><select onchange="S.langs['+i+'].level=this.value;render()">'+lvs.map(function(v){return '<option'+(l.level===v?' selected':'')+'>'+v+'</option>';}).join('')+'</select></div></div><button class="cvs-entry-del" style="position:absolute;top:8px;right:8px" onclick="delLang('+i+')"><i class="fas fa-times"></i></button></div>';
    }).join('');
}
window.delLang=function(i){S.langs.splice(i,1);renderLangs();render();};

// RENDER
window.render=function(){
    readForm();
    var c=S.color,font=(document.getElementById('fontSelect')||{}).value||'Inter',sz=(document.getElementById('sizeSelect')||{}).value||'14px';
    var html=buildCV(S.tpl,c,font,sz);
    var prev=document.getElementById('cvPreview'),live=document.getElementById('cvLive');
    if(prev)prev.innerHTML=html;
    if(live){live.innerHTML=html;var w=live.parentElement.clientWidth-40;var sc=w/793;live.style.transform='scale('+sc+')';live.style.width='793px';live.style.height='1122px';}
};

function buildCV(tpl,c,font,sz){
    var n=esc(S.name||'Your Name'),t=esc(S.title||'Professional Title');
    var cp=[];
    if(S.phone)cp.push('<span><i class="fas fa-phone-alt"></i> '+esc(S.phone)+'</span>');
    if(S.email)cp.push('<span><i class="fas fa-envelope"></i> '+esc(S.email)+'</span>');
    if(S.location)cp.push('<span><i class="fas fa-map-marker-alt"></i> '+esc(S.location)+'</span>');
    if(S.linkedin)cp.push('<span><i class="fas fa-link"></i> '+esc(S.linkedin)+'</span>');
    var contact=cp.join(' ');
    var expH=S.exp.map(function(e){return '<div class="cv-item"><div class="cv-item-head"><strong>'+esc(e.role)+'</strong><span class="cv-date">'+esc(e.from)+(e.to?' — '+esc(e.to):'')+'</span></div><div class="cv-item-sub" style="color:'+c+'">'+esc(e.company)+'</div>'+(e.desc?'<p>'+esc(e.desc).replace(/\n/g,'<br>')+'</p>':'')+'</div>';}).join('');
    var eduH=S.edu.map(function(e){return '<div class="cv-item"><div class="cv-item-head"><strong>'+esc(e.degree)+'</strong><span class="cv-date">'+esc(e.from)+(e.to?' — '+esc(e.to):'')+'</span></div><div class="cv-item-sub">'+esc(e.school)+'</div></div>';}).join('');
    var skillsH=S.skills.map(function(s){return '<span class="cv-skill-chip" style="border-color:'+c+';color:'+c+'">'+esc(s)+'</span>';}).join('');
    var langsH=S.langs.map(function(l){return '<div class="cv-lang-item"><span>'+esc(l.name)+'</span><span style="color:#64748b">'+esc(l.level)+'</span></div>';}).join('');
    var sumSec=S.summary?sec(c,'PROFESSIONAL SUMMARY','<p style="font-size:.85em;color:#475569">'+esc(S.summary).replace(/\n/g,'<br>')+'</p>'):'';
    var expSec=S.exp.length?sec(c,'PROFESSIONAL EXPERIENCE',expH):'';
    var eduSec=S.edu.length?sec(c,'EDUCATION',eduH):'';
    var skillSec=S.skills.length?sec(c,'SKILLS','<div class="cv-skills">'+skillsH+'</div>'):'';
    var langSec=S.langs.length?sec(c,'LANGUAGES',langsH):'';
    var customSecs=S.custom.map(function(cs){return cs.title&&cs.content?sec(c,esc(cs.title).toUpperCase(),'<p style="font-size:.85em;color:#475569">'+esc(cs.content).replace(/\n/g,'<br>')+'</p>'):'';}).join('');
    var wrap='font-family:\''+font+'\',sans-serif;font-size:'+sz;

    // Templates with distinct layouts
    if(tpl==='executive'||tpl==='herald'||tpl==='cascade'){
        return '<div class="cv-executive" style="'+wrap+'"><div class="cv-header" style="background:'+c+'"><h1>'+n+'</h1><h2>'+t+'</h2><div class="cv-contact">'+contact+'</div></div><div class="cv-body">'+sumSec+expSec+eduSec+skillSec+langSec+customSecs+'</div></div>';
    }
    if(tpl==='aurora'||tpl==='maxwell'||tpl==='vertex'||tpl==='cobalt'){
        var sc2='<div class="cv-contact">';
        if(S.email)sc2+='<div><i class="fas fa-envelope"></i> '+esc(S.email)+'</div>';
        if(S.phone)sc2+='<div><i class="fas fa-phone-alt"></i> '+esc(S.phone)+'</div>';
        if(S.location)sc2+='<div><i class="fas fa-map-marker-alt"></i> '+esc(S.location)+'</div>';
        if(S.linkedin)sc2+='<div><i class="fas fa-link"></i> '+esc(S.linkedin)+'</div>';
        sc2+='</div>';
        var sideSkills=S.skills.length?'<div class="cv-section"><div class="cv-section-title" style="border-bottom-color:rgba(255,255,255,.2)">SKILLS</div><div>'+S.skills.map(function(s){return '<span class="cv-skill-chip">'+esc(s)+'</span>';}).join('')+'</div></div>':'';
        var sideLangs=S.langs.length?'<div class="cv-section"><div class="cv-section-title" style="border-bottom-color:rgba(255,255,255,.2)">LANGUAGES</div>'+S.langs.map(function(l){return '<div class="cv-lang-item"><span>'+esc(l.name)+'</span><span style="opacity:.7">'+esc(l.level)+'</span></div>';}).join('')+'</div>':'';
        return '<div class="cv-modern" style="'+wrap+'"><div class="cv-sidebar" style="background:'+c+'"><h1>'+n+'</h1><h2>'+t+'</h2>'+sc2+sideSkills+sideLangs+'</div><div class="cv-main">'+sumSec+expSec+eduSec+customSecs+'</div></div>';
    }
    if(tpl==='metro'||tpl==='zenith'){
        return '<div class="cv-executive" style="'+wrap+'"><div class="cv-header" style="background:linear-gradient(135deg,'+c+' 0%,'+lighten(c,.3)+' 100%)"><h1>'+n+'</h1><h2>'+t+'</h2><div class="cv-contact">'+contact+'</div></div><div class="cv-body" style="display:flex;gap:28px"><div style="flex:2">'+sumSec+expSec+eduSec+'</div><div style="flex:1;border-left:2px solid #e2e8f0;padding-left:20px">'+skillSec+langSec+customSecs+'</div></div></div>';
    }
    if(tpl==='nordic'||tpl==='ivory'){
        return '<div class="cv-minimal" style="'+wrap+'"><div class="cv-header" style="border-bottom-color:'+c+'"><h1 style="color:'+c+'">'+n+'</h1><h2>'+t+'</h2><div class="cv-contact">'+contact+'</div></div>'+sumSec+expSec+eduSec+'<div class="cv-two-col"><div>'+skillSec+'</div><div>'+langSec+'</div></div></div>';
    }
    // luna fallback
    return '<div class="cv-minimal" style="'+wrap+'"><div class="cv-header" style="border-bottom-color:'+c+';text-align:left;padding-left:0"><div style="display:flex;align-items:center;gap:20px;flex-wrap:wrap"><div><h1 style="color:'+c+';font-size:2em">'+n+'</h1><h2>'+t+'</h2></div></div><div class="cv-contact" style="justify-content:flex-start;margin-top:10px">'+contact+'</div></div>'+sumSec+expSec+eduSec+skillSec+langSec+customSecs+'</div>';
}

function sec(c,title,body){return '<div class="cv-section"><div class="cv-section-title" style="color:'+c+';border-bottom-color:'+c+'">'+title+'</div>'+body+'</div>';}
function lighten(hex,pct){var r=parseInt(hex.slice(1,3),16),g=parseInt(hex.slice(3,5),16),b=parseInt(hex.slice(5,7),16);r=Math.min(255,Math.round(r+(255-r)*pct));g=Math.min(255,Math.round(g+(255-g)*pct));b=Math.min(255,Math.round(b+(255-b)*pct));return '#'+((1<<24)+(r<<16)+(g<<8)+b).toString(16).slice(1);}

// SAVE/LOAD
function getStore(){return JSON.parse(localStorage.getItem('cvs_resumes')||'[]');}
function setStore(arr){localStorage.setItem('cvs_resumes',JSON.stringify(arr));}
function renderResumes(){
    var list=getStore(),el=document.getElementById('resumeList');if(!el)return;
    if(!list.length){el.innerHTML='<div style="font-size:.75rem;color:#94a3b8;padding:8px 0">No saved resumes</div>';return;}
    el.innerHTML=list.map(function(r,i){return '<div class="cvs-resume-item" onclick="loadResume('+i+')"><div class="ri-dot"></div><div class="ri-info"><div class="ri-name">'+esc(r.name||'Untitled')+'</div><div class="ri-sub">'+esc(r.title||'')+'</div></div><button class="ri-del" onclick="event.stopPropagation();delResume('+i+')">&times;</button></div>';}).join('');
}
window.saveProfile=function(){
    readForm();var store=getStore();
    store.push({name:S.name,title:S.title,email:S.email,phone:S.phone,location:S.location,linkedin:S.linkedin,summary:S.summary,exp:JSON.parse(JSON.stringify(S.exp)),edu:JSON.parse(JSON.stringify(S.edu)),skills:S.skills.slice(),langs:JSON.parse(JSON.stringify(S.langs)),tpl:S.tpl,color:S.color,savedAt:new Date().toISOString()});
    setStore(store);renderResumes();closeProfileModal();showToast('Profile saved!');
};
window.loadResume=function(i){
    var r=getStore()[i];if(!r)return;
    S.name=r.name||'';S.title=r.title||'';S.email=r.email||'';S.phone=r.phone||'';S.location=r.location||'';S.linkedin=r.linkedin||'';S.summary=r.summary||'';
    S.exp=r.exp||[];S.edu=r.edu||[];S.skills=r.skills||[];S.langs=r.langs||[];
    if(r.tpl)S.tpl=r.tpl;if(r.color)S.color=r.color;
    fillForm();renderExp();renderEdu();renderSkills();renderLangs();renderTplGrid();renderSwatches();render();showToast('Resume loaded!');
};
window.delResume=function(i){var store=getStore();store.splice(i,1);setStore(store);renderResumes();};
window.newResume=function(){S.name='';S.title='';S.email='';S.phone='';S.location='';S.linkedin='';S.summary='';S.exp=[];S.edu=[];S.skills=[];S.langs=[];fillForm();renderExp();renderEdu();renderSkills();renderLangs();render();showToast('New resume started');};
window.loadSample=function(){
    S.name='Mia Ward';S.title='Senior Account Director';S.email='mia.ward@email.com';S.phone='+44 20 7123 4567';S.location='London, United Kingdom';S.linkedin='linkedin.com/in/miaward';
    S.summary='A results-oriented Senior Account Director with 12+ years\' experience delivering strategic growth for FTSE 100 clients across the telecommunications, utilities and financial services sectors.';
    S.exp=[{role:'Senior Account Director',company:'Vodafone UK',from:'2019',to:'Present',desc:'Expanded the utilities client portfolio by 25% year-on-year through a structured business development programme, generating £4.2M in new revenue.'},{role:'Account Manager',company:'BT Group',from:'2015',to:'2019',desc:'Managed a portfolio of 30+ enterprise accounts with combined annual revenue of £8.5M.'}];
    S.edu=[{degree:'MBA, Business Administration',school:'London Business School',from:'2013',to:'2015'},{degree:'BSc, Marketing',school:'University of Manchester',from:'2009',to:'2012'}];
    S.skills=['Strategic Planning','Business Development','Client Relationship','P&L Management','Team Leadership','CRM Systems','Market Analysis','Negotiation'];
    S.langs=[{name:'English',level:'Native'},{name:'French',level:'Advanced'},{name:'German',level:'Intermediate'}];
    fillForm();renderExp();renderEdu();renderSkills();renderLangs();render();showToast('Sample data loaded!');
};
function fillForm(){var ids={name:'f-name',title:'f-title',email:'f-email',phone:'f-phone',location:'f-location',linkedin:'f-linkedin',summary:'f-summary'};for(var k in ids){var el=document.getElementById(ids[k]);if(el)el.value=S[k]||'';}}
window.openProfileModal=function(){document.getElementById('profileModal').classList.add('open');};
window.closeProfileModal=function(){document.getElementById('profileModal').classList.remove('open');};
function showToast(msg){var t=document.createElement('div');t.style.cssText='position:fixed;top:70px;right:20px;background:#0B3C5D;color:#fff;padding:10px 20px;border-radius:8px;font-size:.85rem;z-index:9999;box-shadow:0 4px 15px rgba(0,0,0,.15);';t.textContent=msg;document.body.appendChild(t);setTimeout(function(){t.style.opacity='0';t.style.transition='opacity .3s';setTimeout(function(){t.remove();},300);},2000);}

window.downloadPDF=function(){readForm();render();switchView('preview');setTimeout(function(){var el=document.getElementById('cvPreview');html2pdf().set({margin:0,filename:(S.name||'CV').replace(/\s+/g,'_')+'_CV.pdf',image:{type:'jpeg',quality:0.98},html2canvas:{scale:2,useCORS:true},jsPDF:{unit:'mm',format:'a4',orientation:'portrait'}}).from(el).save();},500);};
window.downloadWord=function(){readForm();render();var el=document.getElementById('cvPreview')||document.getElementById('cvLive');if(!el)return;var html='<html><head><meta charset="utf-8"></head><body>'+el.innerHTML+'</body></html>';var blob=new Blob([html],{type:'application/msword'});var url=URL.createObjectURL(blob);var a=document.createElement('a');a.href=url;a.download=(S.name||'CV').replace(/\s+/g,'_')+'_CV.doc';document.body.appendChild(a);a.click();document.body.removeChild(a);URL.revokeObjectURL(url);};
})();
