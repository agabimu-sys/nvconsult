// NVConsult Country Detail — Renders country eligibility & requirements
(function () {
    'use strict';

    var COUNTRIES = {
        'germany': { name: 'Germany', flag: 'https://flagcdn.com/w40/de.png', flagLg: 'https://flagcdn.com/w80/de.png' },
        'czech-republic': { name: 'Czech Republic', flag: 'https://flagcdn.com/w40/cz.png', flagLg: 'https://flagcdn.com/w80/cz.png' },
        'poland': { name: 'Poland', flag: 'https://flagcdn.com/w40/pl.png', flagLg: 'https://flagcdn.com/w80/pl.png' },
        'netherlands': { name: 'Netherlands', flag: 'https://flagcdn.com/w40/nl.png', flagLg: 'https://flagcdn.com/w80/nl.png' },
        'austria': { name: 'Austria', flag: 'https://flagcdn.com/w40/at.png', flagLg: 'https://flagcdn.com/w80/at.png' },
        'portugal': { name: 'Portugal', flag: 'https://flagcdn.com/w40/pt.png', flagLg: 'https://flagcdn.com/w80/pt.png' },
        'sweden': { name: 'Sweden', flag: 'https://flagcdn.com/w40/se.png', flagLg: 'https://flagcdn.com/w80/se.png' }
    };

    var CATEGORY_PAGES = { 'Work Visas': 'service.html', 'Study Visas': 'study-visas.html' };

    var VISA_TYPES = {
        'Work Visas': {
            'Germany': ['Skilled Worker Visa', 'EU Blue Card', 'Job Seeker Visa'],
            'Czech Republic': ['Employee Card', 'Work Permit'],
            'Poland': ['Work Permit', 'Seasonal Work Visa'],
            'Netherlands': ['Highly Skilled Migrant Visa', 'TWV Work Permit'],
            'Austria': ['Red-White-Red Card', 'EU Blue Card'],
            'Sweden': ['Work Permit']
        },
        'Study Visas': {
            'Germany': ['Student Visa', 'Post-Study Work Visa', 'Language Course Visa'],
            'Poland': ['Student Visa', 'Research Visa'],
            'Czech Republic': ['Student Visa', 'Long-Term Study Visa']
        }
    };

    // Country-specific data for Work Visas
    var COUNTRY_DATA_WORK = {
        'Germany': {
            overview: 'Germany is Europe\'s largest economy and a top destination for skilled professionals worldwide. With its Skilled Immigration Act (Fachkräfteeinwanderungsgesetz), Germany has streamlined the process for qualified workers. The country faces a shortage of over 400,000 skilled workers annually, creating excellent opportunities across IT, engineering, healthcare, and trades.',
            stats: { avgSalary: '€54,000/yr', minWage: '€12.41/hr', unemployment: '5.7%', demand: 'Very High' },
            eligibility: [
                'University degree or recognized vocational qualification',
                'Job offer from a German employer (or Job Seeker Visa for search)',
                'Qualification must be recognized as equivalent to German standards',
                'Basic German language skills (A1-B2 depending on visa type)',
                'Clean criminal record and valid passport',
                'Health insurance coverage',
                'Proof of financial stability for initial period',
                'Age under 45 for EU Blue Card (with exceptions)'
            ],
            documents: [
                'Completed visa application form',
                'Valid passport (minimum 6 months validity)',
                'Biometric passport photographs',
                'Employment contract or binding job offer',
                'Degree certificates with apostille',
                'Credential recognition letter (anabin/ZAB)',
                'German language certificate (Goethe, telc, etc.)',
                'Proof of health insurance',
                'Proof of accommodation in Germany',
                'CV/Resume in German or English'
            ],
            industries: ['Information Technology', 'Engineering & Manufacturing', 'Healthcare & Nursing', 'Skilled Trades (Electricians, Plumbers)', 'Finance & Accounting', 'Research & Development'],
            tips: [
                'Start the qualification recognition process early — it can take 3-4 months',
                'Learning German significantly improves your job prospects and speeds up visa processing',
                'Consider the EU Blue Card if you have a university degree — it offers the fastest path to permanent residency',
                'Germany has bilateral social security agreements with many countries — check if yours is included'
            ]
        },
        'Czech Republic': {
            overview: 'The Czech Republic has become an attractive destination for international workers, particularly in IT, manufacturing, and engineering. Prague consistently ranks among Europe\'s most livable cities with a significantly lower cost of living compared to Western Europe while offering competitive salaries.',
            stats: { avgSalary: '€22,000/yr', minWage: '€4.85/hr', unemployment: '3.5%', demand: 'High' },
            eligibility: [
                'Valid passport with minimum 2 blank pages',
                'Employment contract registered in the Central Registry of Vacancies',
                'Professional qualifications relevant to the position',
                'Clean criminal record certificate (apostilled)',
                'Proof of accommodation in Czech Republic',
                'Travel medical insurance for initial period',
                'Completed application forms',
                'No outstanding immigration violations'
            ],
            documents: [
                'Completed application form for Employee Card',
                'Valid passport with biometric data',
                'Two recent passport photographs',
                'Employment contract or job offer letter',
                'Proof of accommodation (rental contract)',
                'Criminal record certificate (not older than 6 months)',
                'Educational certificates with apostille',
                'Travel medical insurance certificate',
                'Proof of financial means'
            ],
            industries: ['IT & Software Development', 'Automotive Manufacturing', 'Engineering', 'Shared Service Centers', 'Tourism & Hospitality', 'Logistics'],
            tips: [
                'The Employee Card is a dual-purpose permit — it combines work and residence authorization',
                'Applications can take 60-90 days, so plan accordingly',
                'Prague has a thriving expat community with many English-speaking opportunities',
                'Learning basic Czech phrases will help with daily life and bureaucracy'
            ]
        },
        'Poland': {
            overview: 'Poland is one of Europe\'s fastest-growing economies with a booming IT sector and strong manufacturing base. The country offers relatively straightforward work permit processes and has become a popular destination for workers from neighboring regions, with increasing opportunities for skilled professionals worldwide.',
            stats: { avgSalary: '€18,000/yr', minWage: '€5.10/hr', unemployment: '5.1%', demand: 'High' },
            eligibility: [
                'Valid passport',
                'Confirmed job offer from a Polish employer',
                'Employer obtains work permit approval from Voivodeship office',
                'Professional qualifications for the position',
                'Clean criminal record',
                'Health insurance coverage',
                'Proof of accommodation',
                'Labor market test passed (no suitable Polish/EU candidates)'
            ],
            documents: [
                'Visa application form',
                'Valid passport and copies',
                'Biometric photographs',
                'Work permit issued to the employer',
                'Employment contract',
                'Proof of accommodation',
                'Health insurance certificate',
                'Criminal record certificate',
                'Financial means documentation'
            ],
            industries: ['IT & Tech', 'Manufacturing & Automotive', 'BPO & Shared Services', 'Agriculture (seasonal)', 'Construction', 'Logistics & Warehousing'],
            tips: [
                'Seasonal work permits have a faster processing time and are ideal for short-term employment',
                'Poland has a simplified procedure for citizens of certain countries including Ukraine, Belarus, etc.',
                'The IT sector in Warsaw, Kraków, and Wrocław offers competitive international salaries',
                'Consider the Temporary Residence Permit for stays longer than 3 months'
            ]
        },
        'Netherlands': {
            overview: 'The Netherlands is a global business hub known for its innovation, excellent work-life balance, and highly international workforce. The country offers attractive tax incentives through the 30% ruling and has streamlined processes for highly skilled migrants, making it one of Europe\'s most welcoming destinations for international professionals.',
            stats: { avgSalary: '€48,000/yr', minWage: '€12.40/hr', unemployment: '3.6%', demand: 'Very High' },
            eligibility: [
                'Employment with an IND-recognized sponsor (employer)',
                'Meet minimum salary threshold (€5,008/month for 30+, €3,672 for under 30)',
                'Position matches educational/professional background',
                'Valid passport and clean criminal record',
                'TB certificate for certain nationalities',
                'Not pose a public safety risk',
                'Employer must be registered as recognized sponsor',
                'Health insurance (obtained upon arrival)'
            ],
            documents: [
                'Application submitted by employer (recognized sponsor)',
                'Valid passport',
                'Employment contract meeting salary thresholds',
                'Antecedents certificate',
                'TB test results (if applicable)',
                'Proof of qualifications',
                'MVV application at Dutch embassy (if required)',
                'BSN registration upon arrival'
            ],
            industries: ['Technology & Startups', 'Finance & Banking', 'Life Sciences & Pharma', 'Logistics & Supply Chain', 'Agriculture Technology', 'Creative Industries'],
            tips: [
                'The 30% ruling means 30% of your salary is tax-free — a significant financial benefit',
                'Highly Skilled Migrant applications are processed in just 2 weeks',
                'Your spouse/partner gets an open work permit with no restrictions',
                'The Netherlands has one of the highest English proficiency rates in non-English-speaking countries'
            ]
        },
        'Austria': {
            overview: 'Austria combines an exceptional quality of life with strong economic performance. The country\'s Red-White-Red Card system uses a transparent points-based approach to attract skilled workers. Vienna consistently ranks as the world\'s most livable city, and Austria offers competitive salaries across many sectors.',
            stats: { avgSalary: '€45,000/yr', minWage: 'Sector-based', unemployment: '5.0%', demand: 'High' },
            eligibility: [
                'Score minimum 55 out of 90 points in the assessment',
                'Points categories: Qualifications (max 30), Work Experience (max 20), Language (max 15), Age (max 25)',
                'Binding job offer from an Austrian employer',
                'Salary meets minimum collective bargaining agreement',
                'Recognized educational qualification',
                'German or English language skills (certificated)',
                'Under 55 years of age for maximum points',
                'Valid passport and clean criminal record'
            ],
            documents: [
                'Completed RWR Card application form',
                'Valid passport with sufficient validity',
                'Biometric photographs',
                'Employment contract or job offer',
                'Degree certificates with apostille/superlegalization',
                'Language certificates (ÖSD, Goethe, IELTS, etc.)',
                'Previous employment references',
                'Criminal record certificate',
                'Birth certificate with apostille',
                'Proof of accommodation in Austria'
            ],
            industries: ['Tourism & Hospitality', 'Engineering & Technology', 'Healthcare', 'Finance & Insurance', 'Manufacturing', 'Research & Academia'],
            tips: [
                'Self-assess your points before applying — you need at least 55 out of 90',
                'After 2 years, you can upgrade to the RWR Card Plus with unrestricted labor market access',
                'German language skills earn more points than English — consider taking a course',
                'Austria has excellent public healthcare and education systems included with residence'
            ]
        },
        'Sweden': {
            overview: 'Sweden is renowned for its innovative tech ecosystem, strong labor rights, and excellent quality of life. The Swedish work permit system requires employer sponsorship and competitive working conditions. The country is home to many global companies and startups, particularly in Stockholm\'s thriving tech scene.',
            stats: { avgSalary: '€42,000/yr', minWage: 'Sector-based', unemployment: '7.5%', demand: 'Moderate-High' },
            eligibility: [
                'Job offer from a Swedish employer with union-approved conditions',
                'Monthly salary of at least SEK 27,360 (before tax)',
                'Working conditions meet Swedish collective agreements',
                'Employer offers health insurance, occupational pension, and life insurance',
                'Valid passport',
                'The offer is for a position that has been advertised in the EU for 10 days',
                'Employment contract for at least 12 months',
                'Sufficient means to support yourself'
            ],
            documents: [
                'Online application through Migrationsverket',
                'Valid passport',
                'Employment offer/contract',
                'Employer\'s statement of conditions',
                'Union consultation confirmation',
                'Proof of insurance coverage',
                'Passport photographs',
                'Previous work references'
            ],
            industries: ['Technology & Gaming', 'Cleantech & Sustainability', 'Life Sciences', 'Manufacturing', 'Finance & Fintech', 'Design & Creative'],
            tips: [
                'Sweden\'s tech industry (especially in Stockholm) actively recruits international talent',
                'Swedish employers must consult unions before offering work permit positions',
                'Learning Swedish opens many more opportunities and is free through SFI programs',
                'Sweden offers generous parental leave and work-life balance policies'
            ]
        }
    };

    // Country-specific data for Study Visas
    var COUNTRY_DATA_STUDY = {
        'Germany': {
            overview: 'Germany is one of the most popular study destinations worldwide, offering free or very low-cost tuition at public universities. With over 400,000 international students, Germany provides world-class education in engineering, sciences, and humanities. The post-study work visa (18 months) makes it an excellent pathway to a career in Europe.',
            stats: { tuition: 'Free-€1,500/yr', livingCost: '€934/mo', programs: '20,000+', intlStudents: '400,000+' },
            eligibility: [
                'Admission letter from a German university (Zulassungsbescheid)',
                'Proof of financial resources (€11,208/year in blocked account)',
                'Health insurance valid in Germany',
                'University entrance qualification (HZB) recognized in Germany',
                'Language proficiency: German (TestDaF/DSH) or English (IELTS/TOEFL)',
                'Valid passport with sufficient validity',
                'Motivation letter and CV',
                'No previous visa rejections (or explanation if any)'
            ],
            documents: [
                'University admission letter',
                'Proof of blocked account (Sperrkonto) with €11,208',
                'Health insurance certificate',
                'School/university transcripts with apostille',
                'Language proficiency certificates',
                'Passport and biometric photographs',
                'Visa application form',
                'APS certificate (for certain countries like China, India, Vietnam)',
                'Motivation letter',
                'CV/Resume'
            ],
            industries: ['Engineering & Technical Sciences', 'Computer Science & IT', 'Business & Economics', 'Natural Sciences', 'Medicine & Healthcare', 'Arts & Humanities'],
            tips: [
                'Public universities in Germany charge no tuition fees (except Baden-Württemberg: €1,500/semester)',
                'Open a blocked account (Sperrkonto) with companies like Expatrio or Fintiba',
                'The 18-month post-study work visa allows you to find a job related to your studies',
                'Students can work 120 full days or 240 half-days per year alongside studies'
            ]
        },
        'Poland': {
            overview: 'Poland offers high-quality, affordable education with numerous English-taught programs. Major university cities like Warsaw, Kraków, and Wrocław provide a vibrant student life with low living costs. Poland is particularly popular for medical, engineering, and business studies among international students.',
            stats: { tuition: '€2,000-€6,000/yr', livingCost: '€500-€700/mo', programs: '800+', intlStudents: '85,000+' },
            eligibility: [
                'Admission to a recognized Polish university',
                'Proof of financial means (approx. PLN 3,500/month or full-year funds)',
                'Health insurance (European Health Insurance Card or private)',
                'Valid passport with 12+ months validity',
                'Secondary school leaving certificate (apostilled)',
                'Language proficiency for the chosen program',
                'No criminal record',
                'Motivation letter'
            ],
            documents: [
                'University acceptance letter',
                'Proof of paid tuition fees',
                'Proof of financial means (bank statement or sponsor letter)',
                'Health insurance certificate',
                'High school diploma with apostille',
                'Passport and photographs',
                'Visa application form',
                'Criminal record certificate',
                'Proof of accommodation'
            ],
            industries: ['Medicine & Dentistry', 'Engineering', 'Business & Management', 'Computer Science', 'Architecture', 'International Relations'],
            tips: [
                'Poland offers some of Europe\'s best medical programs in English at affordable costs',
                'Living costs in Poland are 40-50% lower than in Western Europe',
                'Many scholarships are available through NAWA (Polish National Agency for Academic Exchange)',
                'Students can work up to 20 hours/week during term time'
            ]
        },
        'Czech Republic': {
            overview: 'The Czech Republic offers free tuition at public universities if you study in Czech language, and affordable English-taught programs. Prague, Brno, and Olomouc are popular university cities with rich cultural heritage. The country is centrally located in Europe, making it easy to travel and network across the continent.',
            stats: { tuition: 'Free-€5,000/yr', livingCost: '€500-€800/mo', programs: '1,000+', intlStudents: '50,000+' },
            eligibility: [
                'Admission to a Czech university or accredited institution',
                'Proof of financial means for the study duration',
                'Health insurance covering the Czech Republic',
                'Recognized secondary education certificate (nostrification)',
                'Language proficiency for the chosen program',
                'Valid passport',
                'Proof of accommodation',
                'Clean criminal record'
            ],
            documents: [
                'University acceptance letter',
                'Nostrification of previous education',
                'Proof of financial means (bank statement)',
                'Comprehensive health insurance',
                'Passport and biometric photos',
                'Criminal record certificate (apostilled)',
                'Proof of accommodation',
                'Visa/long-term residence application form',
                'Language certificates'
            ],
            industries: ['Medicine & Health Sciences', 'Engineering & Technology', 'Arts & Design', 'Economics & Business', 'Natural Sciences', 'Social Sciences'],
            tips: [
                'Studying in Czech language at public universities is completely free for all nationalities',
                'Nostrification of your diploma is required — start this process early as it takes 2-3 months',
                'Prague is one of the most affordable capital cities in Europe for students',
                'Czech universities have strong connections with EU research networks and Erasmus programs'
            ]
        }
    };

    // ─── Country code map for flags ───
    var COUNTRY_CODE_MAP = {
        'afghanistan': 'af', 'albania': 'al', 'algeria': 'dz', 'argentina': 'ar',
        'armenia': 'am', 'australia': 'au', 'austria': 'at', 'azerbaijan': 'az',
        'bahrain': 'bh', 'bangladesh': 'bd', 'belarus': 'by', 'belgium': 'be',
        'bosnia': 'ba', 'brazil': 'br', 'bulgaria': 'bg', 'cambodia': 'kh',
        'cameroon': 'cm', 'canada': 'ca', 'chile': 'cl', 'china': 'cn',
        'colombia': 'co', 'croatia': 'hr', 'cuba': 'cu', 'cyprus': 'cy',
        'czech republic': 'cz', 'czechia': 'cz', 'denmark': 'dk',
        'egypt': 'eg', 'estonia': 'ee', 'ethiopia': 'et', 'finland': 'fi',
        'france': 'fr', 'georgia': 'ge', 'germany': 'de', 'ghana': 'gh',
        'greece': 'gr', 'hungary': 'hu', 'iceland': 'is', 'india': 'in',
        'indonesia': 'id', 'iran': 'ir', 'iraq': 'iq', 'ireland': 'ie',
        'israel': 'il', 'italy': 'it', 'japan': 'jp', 'jordan': 'jo',
        'kazakhstan': 'kz', 'kenya': 'ke', 'korea': 'kr', 'south korea': 'kr',
        'kuwait': 'kw', 'latvia': 'lv', 'lebanon': 'lb', 'libya': 'ly',
        'lithuania': 'lt', 'luxembourg': 'lu', 'malaysia': 'my', 'malta': 'mt',
        'mexico': 'mx', 'moldova': 'md', 'mongolia': 'mn', 'montenegro': 'me',
        'morocco': 'ma', 'nepal': 'np', 'netherlands': 'nl', 'new zealand': 'nz',
        'nigeria': 'ng', 'north macedonia': 'mk', 'norway': 'no', 'oman': 'om',
        'pakistan': 'pk', 'palestine': 'ps', 'panama': 'pa', 'peru': 'pe',
        'philippines': 'ph', 'poland': 'pl', 'portugal': 'pt', 'qatar': 'qa',
        'romania': 'ro', 'russia': 'ru', 'saudi arabia': 'sa', 'senegal': 'sn',
        'serbia': 'sr', 'singapore': 'sg', 'slovakia': 'sk', 'slovenia': 'si',
        'south africa': 'za', 'spain': 'es', 'sri lanka': 'lk', 'sudan': 'sd',
        'sweden': 'se', 'switzerland': 'ch', 'syria': 'sy', 'taiwan': 'tw',
        'thailand': 'th', 'tunisia': 'tn', 'turkey': 'tr', 'turkiye': 'tr',
        'ukraine': 'ua', 'united arab emirates': 'ae', 'uae': 'ae',
        'united kingdom': 'gb', 'uk': 'gb', 'united states': 'us', 'usa': 'us',
        'uzbekistan': 'uz', 'vietnam': 'vn', 'yemen': 'ye', 'zambia': 'zm',
        'zimbabwe': 'zw'
    };

    function slugify(str) {
        return str.toLowerCase().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-');
    }

    function getFlagUrl(name) {
        var code = COUNTRY_CODE_MAP[name.toLowerCase()];
        return code ? 'https://flagcdn.com/w40/' + code + '.png' : '';
    }
    function getFlagUrlLg(name) {
        var code = COUNTRY_CODE_MAP[name.toLowerCase()];
        return code ? 'https://flagcdn.com/w80/' + code + '.png' : '';
    }

    function getAllCountries() {
        var merged = {};
        for (var key in COUNTRIES) merged[key] = COUNTRIES[key];
        var custom = JSON.parse(localStorage.getItem('nv_custom_countries') || '[]');
        custom.forEach(function (c) {
            var slug = slugify(c.name);
            if (!merged[slug]) {
                merged[slug] = { name: c.name, flag: getFlagUrl(c.name), flagLg: getFlagUrlLg(c.name) };
            }
        });
        var posts = JSON.parse(localStorage.getItem('nv_site_posts') || '[]');
        posts.forEach(function (p) {
            if (p.country && p.status === 'published') {
                var slug = slugify(p.country);
                if (!merged[slug]) {
                    merged[slug] = { name: p.country, flag: getFlagUrl(p.country), flagLg: getFlagUrlLg(p.country) };
                }
            }
        });
        return merged;
    }

    function getMergedVisaTypes(category) {
        var merged = {};
        var baseTypes = VISA_TYPES[category] || {};
        for (var c in baseTypes) merged[c] = baseTypes[c].slice();
        var posts = JSON.parse(localStorage.getItem('nv_site_posts') || '[]');
        posts.forEach(function (p) {
            if (p.status === 'published' && p.category === category && p.country && p.visaType) {
                // Use both original name and slug as keys so lookups work either way
                var countryKey = p.country;
                if (!merged[countryKey]) merged[countryKey] = [];
                if (merged[countryKey].indexOf(p.visaType) === -1) merged[countryKey].push(p.visaType);
            }
        });
        return merged;
    }

    function formatDate(dateStr) {
        var d = new Date(dateStr);
        return d.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
    }

    function getParams() {
        var p = new URLSearchParams(window.location.search);
        return { page: p.get('page') || 'Work Visas', country: p.get('country') || '' };
    }

    function renderPage() {
        var params = getParams();
        var allCountries = getAllCountries();
        var country = allCountries[params.country];
        var catPage = CATEGORY_PAGES[params.page] || 'service.html';
        var isStudy = params.page === 'Study Visas';
        var dataSource = isStudy ? COUNTRY_DATA_STUDY : COUNTRY_DATA_WORK;
        var data = country ? dataSource[country.name] : null;

        // If country not found at all, show error
        if (!country) {
            document.getElementById('country-detail-content').innerHTML =
                '<div class="text-center py-5"><h3 class="text-muted">Country not found</h3>' +
                '<a href="' + catPage + '" class="btn btn-primary rounded-pill px-5 py-3 mt-3">Browse ' + params.page + '</a></div>';
            return;
        }

        // Get merged visa types (hardcoded + from posts)
        var mergedVisaTypes = getMergedVisaTypes(params.page);
        // Look up visa types by country name (try exact name, then all keys matching slug)
        var visaTypes = mergedVisaTypes[country.name] || [];
        if (visaTypes.length === 0) {
            // Try finding by slug match
            for (var mk in mergedVisaTypes) {
                if (slugify(mk) === params.country) {
                    visaTypes = mergedVisaTypes[mk];
                    break;
                }
            }
        }

        // Get related posts for this country (slug-based match)
        var posts = JSON.parse(localStorage.getItem('nv_site_posts') || '[]');
        var countryPosts = posts.filter(function (p) {
            return p.status === 'published' && p.category === params.page && slugify(p.country) === params.country;
        }).sort(function (a, b) { return new Date(b.date) - new Date(a.date); });

        // ─── Always update page title & breadcrumbs first (even for error/empty states) ───
        document.title = country.name + ' — ' + params.page + ' | NVConsult';
        var pageTitle = document.getElementById('detail-page-title');
        if (pageTitle) pageTitle.textContent = country.name + ' — ' + params.page;

        var breadcrumb = document.getElementById('detail-breadcrumb');
        if (breadcrumb) {
            var flagImg = country.flag ? '<img src="' + country.flag + '" style="width:20px;vertical-align:middle;margin-right:4px;border-radius:2px;">' : '';
            breadcrumb.innerHTML =
                '<li class="breadcrumb-item"><a href="index.html" class="text-white">Home</a></li>' +
                '<li class="breadcrumb-item"><a href="' + catPage + '" class="text-white">' + params.page + '</a></li>' +
                '<li class="breadcrumb-item active text-secondary">' + flagImg + ' ' + country.name + '</li>';
        }

        // If no hardcoded data AND no posts AND no visa types, show not found
        if (!data && countryPosts.length === 0 && visaTypes.length === 0) {
            document.getElementById('country-detail-content').innerHTML =
                '<div class="text-center py-5"><h3 class="text-muted">No information available yet for ' + country.name + '</h3>' +
                '<p class="text-muted">Check back soon or browse other countries.</p>' +
                '<a href="' + catPage + '" class="btn btn-primary rounded-pill px-5 py-3 mt-3">Browse ' + params.page + '</a></div>';
            return;
        }

        var html = '';
        var flagLg = country.flagLg || country.flag || '';
        var flagLgImg = flagLg ? '<img src="' + flagLg + '" class="flag-lg" alt="' + country.name + '">' : '';

        // ─── HARDCODED DATA EXISTS ───
        if (data) {
            // Hero
            html += '<div class="country-hero">' +
                '<div class="row align-items-center">' +
                    '<div class="col-lg-8">' +
                        '<span class="cat-badge"><i class="fas fa-globe-europe me-2"></i>' + params.page + '</span>' +
                        '<h1>' + flagLgImg + country.name + '</h1>' +
                        '<p>' + data.overview.substring(0, 160) + '...</p>' +
                    '</div>' +
                    '<div class="col-lg-4 text-end d-none d-lg-block">' +
                        '<div style="font-size:6rem;opacity:0.12;"><i class="fas fa-globe-europe"></i></div>' +
                    '</div>' +
                '</div>' +
            '</div>';

            // Stats row
            var statKeys = Object.keys(data.stats);
            var statLabels = isStudy
                ? ['Tuition', 'Living Cost', 'Programs', 'Intl Students']
                : ['Avg Salary', 'Min Wage', 'Unemployment', 'Demand'];
            html += '<div class="row g-3 mb-5">';
            statKeys.forEach(function (key, i) {
                html += '<div class="col-6 col-md-3">' +
                    '<div class="stat-card eligibility-card">' +
                        '<span class="stat-value">' + data.stats[key] + '</span>' +
                        '<span class="stat-label">' + statLabels[i] + '</span>' +
                    '</div>' +
                '</div>';
            });
            html += '</div>';

            // Main content
            html += '<div class="row g-4"><div class="col-lg-8">';

            html += '<div class="eligibility-card">' +
                '<div class="card-icon"><i class="fas fa-info-circle"></i></div>' +
                '<h3>About ' + (isStudy ? 'Studying' : 'Working') + ' in ' + country.name + '</h3>' +
                '<p style="color:#555;line-height:1.8;font-size:1.05rem;">' + data.overview + '</p>' +
            '</div>';

            html += '<div class="eligibility-card">' +
                '<div class="card-icon"><i class="fas fa-clipboard-check"></i></div>' +
                '<h3>Eligibility Requirements</h3>' +
                '<ul>' + data.eligibility.map(function (r) {
                    return '<li><i class="fas fa-check-circle"></i><span>' + r + '</span></li>';
                }).join('') + '</ul>' +
            '</div>';

            html += '<div class="eligibility-card">' +
                '<div class="card-icon"><i class="fas fa-file-alt"></i></div>' +
                '<h3>Required Documents</h3>' +
                '<ul>' + data.documents.map(function (d) {
                    return '<li><i class="fas fa-folder-open"></i><span>' + d + '</span></li>';
                }).join('') + '</ul>' +
            '</div>';

            // Related posts
            if (countryPosts.length > 0) {
                html += '<div class="eligibility-card">' +
                    '<div class="card-icon"><i class="fas fa-newspaper"></i></div>' +
                    '<h3>Related Articles</h3>';
                countryPosts.slice(0, 5).forEach(function (post) {
                    var postUrl = 'blog-post.html?slug=' + post.slug;
                    html += '<div style="margin-bottom:16px;padding-bottom:16px;border-bottom:1px solid #eee;">' +
                        '<h5 style="margin-bottom:4px;"><a href="' + postUrl + '" style="color:#0B3C5D;text-decoration:none;">' + post.title + '</a></h5>' +
                        '<small style="color:#888;"><i class="fas fa-calendar-alt me-1"></i>' + formatDate(post.date) + '</small>' +
                        '<p style="color:#555;margin-top:6px;margin-bottom:0;">' + post.excerpt + '</p>' +
                    '</div>';
                });
                html += '</div>';
            }

            html += '</div>'; // col-lg-8

            // Sidebar
            html += '<div class="col-lg-4">';

            html += '<div class="eligibility-card">' +
                '<div class="card-icon"><i class="fas fa-briefcase"></i></div>' +
                '<h3>' + (isStudy ? 'Popular Fields of Study' : 'In-Demand Industries') + '</h3>' +
                '<ul>' + data.industries.map(function (ind) {
                    return '<li><i class="fas fa-arrow-circle-right"></i><span>' + ind + '</span></li>';
                }).join('') + '</ul>' +
            '</div>';

            html += '<div class="eligibility-card" style="background:linear-gradient(135deg,#fffbeb,#fef3cd);border-color:#fde68a;">' +
                '<div class="card-icon" style="background:linear-gradient(135deg,#0B3C5D,#145580);"><i class="fas fa-lightbulb"></i></div>' +
                '<h3 style="color:#92400e;">Expert Tips</h3>' +
                '<ul>' + data.tips.map(function (tip) {
                    return '<li style="border-color:#fde68a;"><i class="fas fa-star" style="color:#d97706;"></i><span style="color:#78350f;">' + tip + '</span></li>';
                }).join('') + '</ul>' +
            '</div>';

            html += '</div>'; // col-lg-4
            html += '</div>'; // row

        } else {
            // ─── DYNAMIC COUNTRY (no hardcoded data) — Show posts-based page ───
            html += '<div class="country-hero">' +
                '<div class="row align-items-center">' +
                    '<div class="col-lg-8">' +
                        '<span class="cat-badge"><i class="fas fa-globe-europe me-2"></i>' + params.page + '</span>' +
                        '<h1>' + flagLgImg + country.name + '</h1>' +
                        '<p>' + (isStudy ? 'Study visa information and guides for ' : 'Work visa information and guides for ') + country.name + '</p>' +
                    '</div>' +
                    '<div class="col-lg-4 text-end d-none d-lg-block">' +
                        '<div style="font-size:6rem;opacity:0.12;"><i class="fas fa-globe-europe"></i></div>' +
                    '</div>' +
                '</div>' +
            '</div>';

            // Show posts if available
            if (countryPosts.length > 0) {
                html += '<div class="row g-4 mb-5">';
                countryPosts.forEach(function (post, i) {
                    var postUrl = 'blog-post.html?slug=' + post.slug;
                    var imgHtml = post.image
                        ? '<img src="' + post.image + '" alt="' + post.title + '" style="width:100%;height:180px;object-fit:cover;border-radius:10px;margin-bottom:14px;">'
                        : '';
                    html += '<div class="col-lg-6">' +
                        '<div class="eligibility-card">' +
                            imgHtml +
                            (post.visaType ? '<span style="display:inline-block;background:#e0f2fe;color:#0B3C5D;padding:4px 12px;border-radius:20px;font-size:0.8rem;font-weight:600;margin-bottom:10px;">' + post.visaType + '</span>' : '') +
                            '<h4 style="margin-bottom:8px;"><a href="' + postUrl + '" style="color:#0B3C5D;text-decoration:none;">' + post.title + '</a></h4>' +
                            '<div style="font-size:0.85rem;color:#888;margin-bottom:8px;">' +
                                '<i class="fas fa-calendar-alt me-1"></i>' + formatDate(post.date) +
                                '<span class="ms-3"><i class="fas fa-user me-1"></i>' + post.author + '</span>' +
                            '</div>' +
                            '<p style="color:#555;">' + post.excerpt + '</p>' +
                            '<a href="' + postUrl + '" class="btn btn-sm btn-outline-primary rounded-pill px-4">Read More <i class="fas fa-arrow-right ms-1"></i></a>' +
                        '</div>' +
                    '</div>';
                });
                html += '</div>';
            }
        }

        // Visa pathway cards (for both hardcoded and dynamic countries)
        if (visaTypes.length > 0) {
            html += '<h2 class="text-center mt-5 mb-4" style="font-family:Poppins,sans-serif;font-weight:700;color:#0B3C5D;">Available Visa Pathways</h2>' +
                '<div class="row g-4 mb-5">';
            var icons = ['fas fa-id-badge', 'fas fa-passport', 'fas fa-search-location', 'fas fa-user-graduate', 'fas fa-book-reader', 'fas fa-flask'];
            visaTypes.forEach(function (type, i) {
                var typeSlug = slugify(type);
                var url = 'visa-info.html?page=' + encodeURIComponent(params.page) + '&country=' + params.country + '&type=' + typeSlug;
                html += '<div class="col-md-6 col-lg-4">' +
                    '<div class="visa-pathway-card">' +
                        '<div class="pathway-icon"><i class="' + (icons[i % icons.length]) + '"></i></div>' +
                        '<h5>' + type + '</h5>' +
                        '<p>View detailed requirements, process steps, and eligibility criteria.</p>' +
                        '<a href="' + url + '" class="btn btn-primary rounded-pill px-4 py-2">View Details</a>' +
                    '</div>' +
                '</div>';
            });
            html += '</div>';
        }

        // CTA
        html += '<div class="cta-detail">' +
            '<h2>Ready to Start Your Journey to ' + country.name + '?</h2>' +
            '<p>Our immigration experts will evaluate your profile and guide you through the entire ' + (isStudy ? 'admission' : 'visa') + ' process.</p>' +
            '<a href="#" class="btn btn-primary border-secondary rounded-pill py-3 px-5" style="font-size:1.05rem;">Book a Free Consultation</a>' +
        '</div>';

        document.getElementById('country-detail-content').innerHTML = html;
    }

    document.addEventListener('DOMContentLoaded', renderPage);
})();

