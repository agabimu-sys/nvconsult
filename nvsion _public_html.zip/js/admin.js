// NVConsult Admin Panel — Unified Posts Management with Categories
(function () {
    'use strict';

    var ADMIN_PASSWORD = 'nvonsult2024';
    var DEFAULT_CATEGORIES = ['Blog', 'Work Visas', 'Study Visas', 'Jobs Abroad'];
    var COUNTRY_CATEGORIES = ['Work Visas', 'Study Visas'];
    var DEFAULT_COUNTRIES = [
        { name: 'Germany', flag: '🇩🇪' },
        { name: 'Czech Republic', flag: '🇨🇿' },
        { name: 'Poland', flag: '🇵🇱' },
        { name: 'Netherlands', flag: '🇳🇱' },
        { name: 'Austria', flag: '🇦🇹' },
        { name: 'Portugal', flag: '🇵🇹' }
    ];

    // ─── Countries (Dynamic) ───
    function getCountries() {
        var custom = JSON.parse(localStorage.getItem('nv_custom_countries') || '[]');
        var countries = DEFAULT_COUNTRIES.slice();
        custom.forEach(function (c) {
            var exists = countries.some(function (dc) { return dc.name === c.name; });
            if (!exists) countries.push(c);
        });
        return countries;
    }

    function addCountry(name, flag, coverImage) {
        name = name.trim();
        if (!name) return false;
        flag = (flag || '').trim() || '🏳️';
        var custom = JSON.parse(localStorage.getItem('nv_custom_countries') || '[]');
        var allNames = DEFAULT_COUNTRIES.concat(custom).map(function (c) { return c.name; });
        if (allNames.indexOf(name) !== -1) return false;
        var entry = { name: name, flag: flag };
        if (coverImage) entry.coverImage = coverImage;
        custom.push(entry);
        localStorage.setItem('nv_custom_countries', JSON.stringify(custom));
        return true;
    }

    // ─── Slug Generator ───
    function generateSlug(title) {
        return title.toLowerCase()
            .replace(/[^a-z0-9\s-]/g, '')
            .replace(/\s+/g, '-')
            .replace(/-+/g, '-')
            .replace(/^-|-$/g, '');
    }

    // ─── Categories ───
    function getCategories() {
        var custom = JSON.parse(localStorage.getItem('nv_blog_categories') || '[]');
        var cats = DEFAULT_CATEGORIES.slice();
        custom.forEach(function (c) {
            if (cats.indexOf(c) === -1) cats.push(c);
        });
        return cats;
    }

    function addCategory(name) {
        name = name.trim();
        if (!name) return false;
        var custom = JSON.parse(localStorage.getItem('nv_blog_categories') || '[]');
        var all = DEFAULT_CATEGORIES.concat(custom);
        if (all.indexOf(name) !== -1) return false;
        custom.push(name);
        localStorage.setItem('nv_blog_categories', JSON.stringify(custom));
        return true;
    }

    // ─── Auth ───
    function isLoggedIn() { return sessionStorage.getItem('nv_admin_auth') === 'true'; }
    function login(password) {
        if (password === ADMIN_PASSWORD) { sessionStorage.setItem('nv_admin_auth', 'true'); return true; }
        return false;
    }
    function logout() { sessionStorage.removeItem('nv_admin_auth'); window.location.reload(); }

    // ─── Data ───
    function getPosts() { return JSON.parse(localStorage.getItem('nv_site_posts') || '[]'); }
    function savePosts(data) { localStorage.setItem('nv_site_posts', JSON.stringify(data)); }
    function getSubscribers() { return JSON.parse(localStorage.getItem('nv_newsletter_subs') || '[]'); }
    function generateId(prefix) { return (prefix || 'post') + '-' + Date.now() + '-' + Math.random().toString(36).substr(2, 5); }

    // ─── Data Migration: Merge old blog posts into unified posts ───
    function migrateData() {
        var oldBlogs = JSON.parse(localStorage.getItem('nv_blog_posts') || '[]');
        if (oldBlogs.length === 0) return;

        var posts = getPosts();
        var existingIds = {};
        posts.forEach(function (p) { existingIds[p.id] = true; });

        var migrated = 0;
        oldBlogs.forEach(function (blog) {
            if (!existingIds[blog.id]) {
                // Ensure category is set — map old categories to new system
                if (!blog.category || DEFAULT_CATEGORIES.indexOf(blog.category) === -1) {
                    // Check if it matches a known category, otherwise default to Blog
                    var cat = blog.category || 'Blog';
                    if (cat === 'Career Tips' || cat === 'Relocation' || cat === 'News') {
                        cat = 'Blog'; // Map old general categories to Blog
                    }
                    blog.category = cat;
                }
                posts.push(blog);
                migrated++;
            }
        });

        if (migrated > 0) {
            savePosts(posts);
            console.log('[NVConsult] Migrated ' + migrated + ' blog posts into unified posts system.');
        }

        // Clear old blog storage
        localStorage.removeItem('nv_blog_posts');
    }

    // ─── Image Upload Helper ───
    function handleFileUpload(fileInput, previewImg, callback) {
        fileInput.addEventListener('change', function () {
            var file = this.files[0];
            if (!file) return;
            if (file.size > 2 * 1024 * 1024) { alert('Image must be under 2MB.'); return; }
            if (!file.type.startsWith('image/')) { alert('Please upload an image file.'); return; }

            var reader = new FileReader();
            reader.onload = function (e) {
                var dataUrl = e.target.result;
                previewImg.src = dataUrl;
                previewImg.style.display = 'block';
                if (callback) callback(dataUrl);
            };
            reader.readAsDataURL(file);
        });
    }

    // ─── Init ───
    function init() {
        var loginSection = document.getElementById('admin-login');
        var dashboardSection = document.getElementById('admin-dashboard');
        if (!loginSection || !dashboardSection) return;

        // Run migration on init
        migrateData();

        if (isLoggedIn()) {
            loginSection.style.display = 'none';
            dashboardSection.style.display = 'block';
            renderDashboard();
        } else {
            loginSection.style.display = 'flex';
            dashboardSection.style.display = 'none';
            initLogin();
        }
    }

    function initLogin() {
        var form = document.getElementById('admin-login-form');
        var errorEl = document.getElementById('login-error');
        if (!form) return;
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            var pw = document.getElementById('admin-password').value;
            if (login(pw)) {
                document.getElementById('admin-login').style.display = 'none';
                document.getElementById('admin-dashboard').style.display = 'block';
                renderDashboard();
            } else {
                errorEl.style.display = 'block';
                errorEl.textContent = 'Incorrect password. Please try again.';
                document.getElementById('admin-password').value = '';
            }
        });
    }

    // ─── Dashboard ───
    var currentFilterCategory = 'all';

    function renderDashboard() {
        renderStats();
        renderPostsTable();
        renderJobsTable();
        renderSubscribers();
        renderFilterDropdown();
        setupTabs();
        setupLogout();
        setupNewButton();
        setupViewSite();
        setupCancelButtons();
    }

    function renderStats() {
        var posts = getPosts();
        var subs = getSubscribers();
        var published = posts.filter(function (p) { return p.status === 'published'; }).length;
        var cats = getCategories();

        document.getElementById('stat-posts').textContent = posts.length;
        document.getElementById('stat-published').textContent = published;
        document.getElementById('stat-categories').textContent = cats.length;
        document.getElementById('stat-subscribers').textContent = subs.length;
    }

    // ─── Filter Dropdown ───
    function renderFilterDropdown() {
        var filterSelect = document.getElementById('filter-category');
        if (!filterSelect) return;

        var cats = getCategories();
        filterSelect.innerHTML = '<option value="all">All Categories</option>' +
            cats.map(function (cat) {
                return '<option value="' + cat + '"' + (cat === currentFilterCategory ? ' selected' : '') + '>' + cat + '</option>';
            }).join('');

        // Remove old listeners
        var newFilter = filterSelect.cloneNode(true);
        filterSelect.parentNode.replaceChild(newFilter, filterSelect);
        newFilter.addEventListener('change', function () {
            currentFilterCategory = this.value;
            renderPostsTable();
        });
    }

    // ─── Tabs ───
    function setupTabs() {
        document.querySelectorAll('.admin-tab').forEach(function (tab) {
            tab.addEventListener('click', function () {
                document.querySelectorAll('.admin-tab').forEach(function (t) { t.classList.remove('active'); });
                document.querySelectorAll('.admin-tab-content').forEach(function (c) { c.classList.remove('active'); });
                this.classList.add('active');
                document.getElementById('tab-' + this.dataset.tab).classList.add('active');
            });
        });
    }

    // ─── Posts Table ───
    function renderPostsTable() {
        var tbody = document.getElementById('posts-tbody');
        if (!tbody) return;
        var posts = getPosts().sort(function (a, b) { return new Date(b.date) - new Date(a.date); });

        // Apply category filter
        if (currentFilterCategory !== 'all') {
            posts = posts.filter(function (p) { return p.category === currentFilterCategory; });
        }

        if (posts.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center py-4 text-muted">No posts yet. Click "New Post" to create your first post!</td></tr>';
            return;
        }

        tbody.innerHTML = posts.map(function (post) {
            var catClass = (post.category || 'Blog').toLowerCase().replace(/\s+/g, '-');
            var imgHtml = post.image
                ? '<img src="' + post.image + '" alt="">'
                : '<div style="width:40px;height:40px;background:#f1f5f9;border-radius:6px;display:flex;align-items:center;justify-content:center;"><i class="fas fa-image" style="color:#94a3b8;font-size:14px;"></i></div>';
            return '<tr>' +
                '<td><div class="post-title-cell">' + imgHtml + '<span>' + post.title + '</span></div></td>' +
                '<td><span class="category-badge cat-' + catClass + '">' + (post.category || 'Blog') + '</span></td>' +
                '<td><span class="status-badge ' + post.status + '">' + post.status + '</span></td>' +
                '<td>' + formatDate(post.date) + '</td>' +
                '<td><div class="action-btns">' +
                '<button class="btn btn-sm btn-outline-primary edit-post-btn" data-id="' + post.id + '"><i class="fas fa-edit"></i></button>' +
                '<button class="btn btn-sm btn-outline-danger delete-post-btn" data-id="' + post.id + '"><i class="fas fa-trash"></i></button>' +
                '</div></td></tr>';
        }).join('');

        tbody.querySelectorAll('.edit-post-btn').forEach(function (btn) {
            btn.addEventListener('click', function () { openPostEditor(this.dataset.id); });
        });
        tbody.querySelectorAll('.delete-post-btn').forEach(function (btn) {
            btn.addEventListener('click', function () {
                if (confirm('Delete this post?')) { deletePost(this.dataset.id); }
            });
        });
    }

    function renderSubscribers() {
        var tbody = document.getElementById('subscribers-tbody');
        if (!tbody) return;
        var subs = getSubscribers();
        if (subs.length === 0) {
            tbody.innerHTML = '<tr><td colspan="3" class="text-center py-4 text-muted">No subscribers yet.</td></tr>';
            return;
        }
        tbody.innerHTML = subs.map(function (sub, i) {
            return '<tr><td>' + (i + 1) + '</td><td>' + sub.email + '</td><td>' + formatDate(sub.date) + '</td></tr>';
        }).join('');
    }

    // ─── Image Tab Toggle ───
    function setupImageTabs(container) {
        container.querySelectorAll('.img-tab').forEach(function (tab) {
            tab.addEventListener('click', function () {
                var parent = this.closest('.form-group');
                parent.querySelectorAll('.img-tab').forEach(function (t) { t.classList.remove('active'); });
                parent.querySelectorAll('.img-tab-content').forEach(function (c) { c.classList.remove('active'); });
                this.classList.add('active');
                var target = this.dataset.target;
                if (target === 'url') {
                    parent.querySelector('.img-tab-content:first-of-type').classList.add('active');
                } else {
                    parent.querySelector('.img-tab-content:last-of-type').classList.add('active');
                }
            });
        });
    }

    // ─── Post Editor ───
    var currentPostImageData = '';

    // ─── Country Select ───
    function renderCountrySelect(selectedCountry) {
        var sel = document.getElementById('post-country');
        if (!sel) return;
        var countries = getCountries();
        sel.innerHTML = '<option value="">— Select Country —</option>' +
            countries.map(function (c) {
                return '<option value="' + c.name + '"' + (c.name === selectedCountry ? ' selected' : '') + '>' + c.flag + ' ' + c.name + '</option>';
            }).join('') + '<option value="__add_new_country__">+ Add New Country...</option>';

        var newSel = sel.cloneNode(true);
        sel.parentNode.replaceChild(newSel, sel);
        newSel.addEventListener('change', function () {
            if (this.value === '__add_new_country__') {
                showAddCountryModal(function (result) {
                    if (result) {
                        if (addCountry(result.name, result.flag, result.coverImage)) {
                            renderCountrySelect(result.name);
                        } else {
                            alert('This country already exists.');
                            renderCountrySelect(selectedCountry);
                        }
                    } else {
                        renderCountrySelect(selectedCountry);
                    }
                });
            }
        });
    }

    // ─── Add Country Modal ───
    function showAddCountryModal(callback) {
        // Remove existing modal if any
        var existing = document.getElementById('add-country-modal');
        if (existing) existing.remove();

        var modal = document.createElement('div');
        modal.id = 'add-country-modal';
        modal.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);z-index:99999;display:flex;align-items:center;justify-content:center;';
        modal.innerHTML =
            '<div style="background:#fff;border-radius:16px;padding:32px;max-width:480px;width:90%;box-shadow:0 20px 60px rgba(0,0,0,0.3);">' +
                '<h3 style="margin:0 0 24px;color:#0B3C5D;">Add New Country</h3>' +
                '<div style="margin-bottom:16px;">' +
                    '<label style="display:block;font-weight:600;margin-bottom:6px;color:#333;">Country Name *</label>' +
                    '<input type="text" id="acm-name" placeholder="e.g. Italy" style="width:100%;padding:10px 14px;border:1.5px solid #ddd;border-radius:8px;font-size:14px;outline:none;" />' +
                '</div>' +
                '<div style="margin-bottom:16px;">' +
                    '<label style="display:block;font-weight:600;margin-bottom:6px;color:#333;">Flag Emoji</label>' +
                    '<input type="text" id="acm-flag" placeholder="e.g. 🇮🇹 (optional)" style="width:100%;padding:10px 14px;border:1.5px solid #ddd;border-radius:8px;font-size:14px;outline:none;" />' +
                '</div>' +
                '<div style="margin-bottom:20px;">' +
                    '<label style="display:block;font-weight:600;margin-bottom:6px;color:#333;">Cover Image (for card on visa pages)</label>' +
                    '<div id="acm-preview" style="display:none;margin-bottom:10px;"><img id="acm-preview-img" style="width:100%;max-height:160px;object-fit:cover;border-radius:8px;" /></div>' +
                    '<input type="file" id="acm-image" accept="image/*" style="width:100%;padding:8px;border:1.5px dashed #ddd;border-radius:8px;font-size:13px;cursor:pointer;" />' +
                '</div>' +
                '<div style="display:flex;gap:12px;justify-content:flex-end;">' +
                    '<button id="acm-cancel" style="padding:10px 24px;border:1.5px solid #ddd;border-radius:8px;background:#fff;cursor:pointer;font-size:14px;">Cancel</button>' +
                    '<button id="acm-save" style="padding:10px 24px;border:none;border-radius:8px;background:#0B3C5D;color:#fff;cursor:pointer;font-size:14px;font-weight:600;">Add Country</button>' +
                '</div>' +
            '</div>';
        document.body.appendChild(modal);

        var coverImageData = '';

        document.getElementById('acm-image').addEventListener('change', function (e) {
            var file = e.target.files[0];
            if (!file) return;
            var reader = new FileReader();
            reader.onload = function (ev) {
                coverImageData = ev.target.result;
                document.getElementById('acm-preview-img').src = coverImageData;
                document.getElementById('acm-preview').style.display = 'block';
            };
            reader.readAsDataURL(file);
        });

        document.getElementById('acm-cancel').addEventListener('click', function () {
            modal.remove();
            callback(null);
        });

        document.getElementById('acm-save').addEventListener('click', function () {
            var name = document.getElementById('acm-name').value.trim();
            if (!name) {
                alert('Please enter a country name.');
                return;
            }
            var flag = document.getElementById('acm-flag').value.trim() || '🏳️';
            modal.remove();
            callback({ name: name, flag: flag, coverImage: coverImageData || '' });
        });

        // Focus name input
        setTimeout(function () { document.getElementById('acm-name').focus(); }, 100);
    }

    function renderJobCountrySelect(selectedCountry) {
        var sel = document.getElementById('job-country');
        if (!sel) return;
        var countries = getCountries();
        sel.innerHTML = '<option value="">Select Country</option>' +
            countries.map(function (c) {
                return '<option value="' + c.name + '"' + (c.name === selectedCountry ? ' selected' : '') + '>' + c.flag + ' ' + c.name + '</option>';
            }).join('') + '<option value="__add_new_country__">+ Add New Country...</option>';

        var newSel = sel.cloneNode(true);
        sel.parentNode.replaceChild(newSel, sel);
        newSel.addEventListener('change', function () {
            if (this.value === '__add_new_country__') {
                showAddCountryModal(function (result) {
                    if (result) {
                        if (addCountry(result.name, result.flag, result.coverImage)) {
                            renderJobCountrySelect(result.name);
                        } else {
                            alert('This country already exists.');
                            renderJobCountrySelect(selectedCountry);
                        }
                    } else {
                        renderJobCountrySelect(selectedCountry);
                    }
                });
            }
        });
    }

    function toggleCountryFields(category) {
        var show = COUNTRY_CATEGORIES.indexOf(category) !== -1;
        var countryGroup = document.getElementById('country-field-group');
        var visaGroup = document.getElementById('visa-type-field-group');
        if (countryGroup) countryGroup.style.display = show ? '' : 'none';
        if (visaGroup) visaGroup.style.display = show ? '' : 'none';
    }

    function openPostEditor(postId) {
        showEditor('admin-post-editor');
        var isEdit = !!postId;
        var post = isEdit ? getPosts().find(function (p) { return p.id === postId; }) : null;

        document.getElementById('post-editor-title').textContent = isEdit ? 'Edit Post' : 'New Post';
        renderCategorySelect('post-category', post ? post.category : null);
        renderCountrySelect(post ? post.country : '');
        document.getElementById('post-visa-type').value = post ? (post.visaType || '') : '';
        toggleCountryFields(post ? post.category : 'Blog');

        document.getElementById('post-title').value = post ? post.title : '';
        document.getElementById('post-excerpt').value = post ? post.excerpt : '';
        document.getElementById('post-image-url').value = (post && post.image && !post.image.startsWith('data:')) ? post.image : '';
        document.getElementById('post-author').value = post ? post.author : 'NVConsult Team';
        document.getElementById('post-status').value = post ? post.status : 'published';
        document.getElementById('post-editor-content').innerHTML = post ? post.content : '<p>Start writing your post here...</p>';

        currentPostImageData = '';
        var preview = document.getElementById('post-image-preview');
        if (post && post.image) {
            preview.src = post.image;
            preview.style.display = 'block';
            if (post.image.startsWith('data:')) currentPostImageData = post.image;
        } else {
            preview.style.display = 'none';
        }

        // URL input preview
        var urlInput = document.getElementById('post-image-url');
        urlInput.oninput = function () {
            if (urlInput.value) { preview.src = urlInput.value; preview.style.display = 'block'; currentPostImageData = ''; }
            else { preview.style.display = 'none'; }
        };

        // File upload
        var fileInput = document.getElementById('post-image-file');
        var newFileInput = fileInput.cloneNode(true);
        fileInput.parentNode.replaceChild(newFileInput, fileInput);
        handleFileUpload(newFileInput, preview, function (dataUrl) { currentPostImageData = dataUrl; });

        setupImageTabs(document.getElementById('admin-post-editor'));
        setupEditorToolbar(document.getElementById('post-toolbar'));

        // SEO Fields
        setupSeoFields(post);
        setupSeoPanelToggles();

        // Save
        var saveBtn = document.getElementById('save-post-btn');
        var newSaveBtn = saveBtn.cloneNode(true);
        saveBtn.parentNode.replaceChild(newSaveBtn, saveBtn);
        newSaveBtn.addEventListener('click', function () { savePost(isEdit ? postId : null); });
    }

    function savePost(editId) {
        var title = document.getElementById('post-title').value.trim();
        var excerpt = document.getElementById('post-excerpt').value.trim();
        var category = document.getElementById('post-category').value;
        var imageUrl = document.getElementById('post-image-url').value.trim();
        var author = document.getElementById('post-author').value.trim() || 'NVConsult Team';
        var status = document.getElementById('post-status').value;
        var content = document.getElementById('post-editor-content').innerHTML;

        // Country & visa type (only for Work Visas / Study Visas)
        var country = '';
        var visaType = '';
        if (COUNTRY_CATEGORIES.indexOf(category) !== -1) {
            country = document.getElementById('post-country').value;
            visaType = document.getElementById('post-visa-type').value.trim();
        }

        if (!title) { alert('Please enter a post title.'); return; }
        if (!excerpt) { alert('Please enter an excerpt.'); return; }
        if (COUNTRY_CATEGORIES.indexOf(category) !== -1 && !country) {
            alert('Please select a country for this category.'); return;
        }

        var image = currentPostImageData || imageUrl || '';
        var posts = getPosts();
        var slugInput = document.getElementById('seo-slug');
        var slug = (slugInput && slugInput.value.trim()) ? slugInput.value.trim() : generateSlug(title);
        var urlTypeRadio = document.querySelector('input[name="url-type"]:checked');
        var urlType = urlTypeRadio ? urlTypeRadio.value : 'page';
        var seoData = collectSeoData();

        if (editId) {
            var idx = -1;
            posts.forEach(function (p, i) { if (p.id === editId) idx = i; });
            if (idx !== -1) {
                posts[idx].title = title;
                posts[idx].slug = slug;
                posts[idx].urlType = urlType;
                posts[idx].excerpt = excerpt;
                posts[idx].category = category;
                posts[idx].country = country;
                posts[idx].visaType = visaType;
                posts[idx].image = image;
                posts[idx].author = author;
                posts[idx].status = status;
                posts[idx].content = content;
                posts[idx].seo = seoData;
            }
        } else {
            var newPost = {
                id: generateId('post'),
                slug: slug,
                urlType: urlType,
                title: title,
                excerpt: excerpt,
                content: content,
                category: category,
                country: country,
                visaType: visaType,
                author: author,
                date: new Date().toISOString().split('T')[0],
                image: image,
                status: status,
                seo: seoData
            };
            posts.unshift(newPost);
            if (status === 'published') triggerNotification(newPost);
        }

        savePosts(posts);
        closeAllEditors();
        renderDashboard();
    }

    function deletePost(id) {
        var posts = getPosts().filter(function (p) { return p.id !== id; });
        savePosts(posts);
        renderDashboard();
    }

    // ─── Category Select ───
    function renderCategorySelect(selectId, selectedCategory) {
        var catSelect = document.getElementById(selectId);
        var cats = getCategories();
        catSelect.innerHTML = cats.map(function (cat) {
            return '<option value="' + cat + '"' + (cat === selectedCategory ? ' selected' : '') + '>' + cat + '</option>';
        }).join('') + '<option value="__add_new__">+ Add New Category...</option>';

        var newCatSelect = catSelect.cloneNode(true);
        catSelect.parentNode.replaceChild(newCatSelect, catSelect);
        newCatSelect.addEventListener('change', function () {
            toggleCountryFields(this.value);
            if (this.value === '__add_new__') {
                var newCat = prompt('Enter new category name:');
                if (newCat && newCat.trim()) {
                    if (addCategory(newCat.trim())) {
                        renderCategorySelect(selectId, newCat.trim());
                        toggleCountryFields(newCat.trim());
                    } else {
                        alert('This category already exists.');
                        renderCategorySelect(selectId, selectedCategory);
                    }
                } else {
                    renderCategorySelect(selectId, selectedCategory);
                }
            }
        });
    }

    // ─── Editor Helpers ───
    function showEditor(editorId) {
        document.getElementById('admin-list-view').style.display = 'none';
        document.getElementById('admin-post-editor').style.display = 'none';
        var jobEditor = document.getElementById('admin-job-editor');
        if (jobEditor) jobEditor.style.display = 'none';
        document.getElementById(editorId).style.display = 'block';
    }

    function closeAllEditors() {
        document.getElementById('admin-list-view').style.display = 'block';
        document.getElementById('admin-post-editor').style.display = 'none';
        var jobEditor = document.getElementById('admin-job-editor');
        if (jobEditor) jobEditor.style.display = 'none';
    }

    function setupEditorToolbar(toolbar) {
        toolbar.querySelectorAll('.toolbar-btn').forEach(function (btn) {
            var newBtn = btn.cloneNode(true);
            btn.parentNode.replaceChild(newBtn, btn);
            newBtn.addEventListener('click', function (e) {
                e.preventDefault();
                var cmd = this.dataset.command;
                var val = this.dataset.value || null;

                if (cmd === 'createLink') {
                    var url = prompt('Enter URL:');
                    if (url) document.execCommand(cmd, false, url);
                } else if (cmd === 'insertImageLocal') {
                    var fileInput = this.parentNode.querySelector('.toolbar-inline-file');
                    if (fileInput) fileInput.click();
                } else {
                    document.execCommand(cmd, false, val);
                }
            });
        });

        toolbar.querySelectorAll('.toolbar-select').forEach(function (sel) {
            var newSel = sel.cloneNode(true);
            sel.parentNode.replaceChild(newSel, sel);
            newSel.addEventListener('change', function () {
                var cmd = this.dataset.command;
                var val = this.value;
                if (!val) return;
                if (cmd === 'formatBlock') {
                    document.execCommand(cmd, false, '<' + val + '>');
                } else {
                    document.execCommand(cmd, false, val);
                }
                this.selectedIndex = 0;
            });
        });

        toolbar.querySelectorAll('.toolbar-color').forEach(function (colorInput) {
            var newColor = colorInput.cloneNode(true);
            colorInput.parentNode.replaceChild(newColor, colorInput);
            newColor.addEventListener('input', function () {
                document.execCommand(this.dataset.command, false, this.value);
            });
        });

        toolbar.querySelectorAll('.toolbar-inline-file').forEach(function (fileInput) {
            var newFileInput = fileInput.cloneNode(true);
            fileInput.parentNode.replaceChild(newFileInput, fileInput);
            newFileInput.addEventListener('change', function () {
                var file = this.files[0];
                if (!file) return;
                if (file.size > 5 * 1024 * 1024) { alert('Image must be under 5MB.'); return; }
                if (!file.type.startsWith('image/')) { alert('Please select an image file.'); return; }

                var reader = new FileReader();
                reader.onload = function (e) {
                    var img = document.createElement('img');
                    img.src = e.target.result;
                    img.style.maxWidth = '100%';
                    img.style.height = 'auto';
                    img.style.borderRadius = '8px';
                    img.style.margin = '12px 0';

                    var selection = window.getSelection();
                    if (selection.rangeCount > 0) {
                        var range = selection.getRangeAt(0);
                        range.deleteContents();
                        range.insertNode(img);
                        range.setStartAfter(img);
                        range.collapse(true);
                        selection.removeAllRanges();
                        selection.addRange(range);
                    }
                };
                reader.readAsDataURL(file);
                this.value = '';
            });
        });
    }

    // ─── Push Notifications ───
    function triggerNotification(item) {
        var postUrl = item.slug ? 'blog-post.html?slug=' + item.slug : 'blog-post.html?id=' + item.id;

        // Store new post data for other tabs/visitors to pick up
        localStorage.setItem('nv_new_post', JSON.stringify({
            id: item.id,
            slug: item.slug,
            title: item.title,
            excerpt: item.excerpt,
            timestamp: Date.now()
        }));

        // 1) First: request permission if not yet decided
        if ('Notification' in window && Notification.permission === 'default') {
            Notification.requestPermission().then(function (perm) {
                if (perm === 'granted') {
                    sendDeviceNotification(item.title, postUrl);
                }
            });
            return;
        }

        // 2) Fire native device notification immediately
        if ('Notification' in window && Notification.permission === 'granted') {
            sendDeviceNotification(item.title, postUrl);
        }

        // 3) Also try SW for background/other tab notifications (bonus)
        try {
            if ('serviceWorker' in navigator) {
                navigator.serviceWorker.getRegistration().then(function (reg) {
                    if (reg) {
                        reg.showNotification('📝 New Post — NVConsult', {
                            body: item.title,
                            icon: 'img/about-2.png',
                            tag: 'nv-sw-' + item.id,
                            data: { url: postUrl }
                        }).catch(function () { });
                    }
                }).catch(function () { });
            }
        } catch (e) { }
    }

    function sendDeviceNotification(title, url) {
        try {
            var n = new Notification('📝 New Post Published — NVConsult', {
                body: title,
                icon: window.location.href.replace(/[^/]*$/, '') + 'img/about-2.png',
                tag: 'nv-device-' + Date.now(),
                requireInteraction: true
            });
            n.onclick = function () {
                window.focus();
                window.open(url, '_blank');
                n.close();
            };
        } catch (e) {
            console.warn('Device notification failed:', e);
        }
    }

    // ─── Button Setup ───
    function setupNewButton() {
        var postBtn = document.getElementById('new-post-btn');
        var np = postBtn.cloneNode(true);
        postBtn.parentNode.replaceChild(np, postBtn);
        np.addEventListener('click', function () { openPostEditor(null); });

        var jobBtn = document.getElementById('new-job-btn');
        if (jobBtn) {
            var nj = jobBtn.cloneNode(true);
            jobBtn.parentNode.replaceChild(nj, jobBtn);
            nj.addEventListener('click', function () { openJobEditor(null); });
        }
    }

    function setupCancelButtons() {
        document.querySelectorAll('.cancel-editor-btn').forEach(function (btn) {
            btn.addEventListener('click', function () { closeAllEditors(); });
        });
        document.querySelectorAll('.cancel-job-editor-btn').forEach(function (btn) {
            btn.addEventListener('click', function () { closeAllEditors(); });
        });
    }

    function setupLogout() {
        var btn = document.getElementById('admin-logout-btn');
        if (btn) btn.addEventListener('click', function (e) { e.preventDefault(); logout(); });
    }

    function setupViewSite() {
        var btn = document.getElementById('view-site-btn');
        if (btn) btn.addEventListener('click', function (e) { e.preventDefault(); window.open('index.html', '_blank'); });
    }

    function formatDate(dateStr) {
        var d = new Date(dateStr);
        return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
    }

    // ─── SEO Panel Toggles ───
    function setupSeoPanelToggles() {
        document.querySelectorAll('.seo-panel-header').forEach(function (header) {
            var newHeader = header.cloneNode(true);
            header.parentNode.replaceChild(newHeader, header);
            newHeader.addEventListener('click', function () {
                var targetId = this.dataset.toggle;
                var body = document.getElementById(targetId);
                if (body) {
                    var isVisible = body.style.display !== 'none';
                    body.style.display = isVisible ? 'none' : '';
                    this.classList.toggle('open', !isVisible);
                }
            });
        });

        setupSchemaToggle('schema-faq-toggle', 'schema-faq-fields');
        setupSchemaToggle('schema-review-toggle', 'schema-review-fields');
        setupSchemaToggle('schema-article-toggle', 'schema-article-fields');

        var addFaqBtn = document.getElementById('add-faq-btn');
        if (addFaqBtn) {
            var newBtn = addFaqBtn.cloneNode(true);
            addFaqBtn.parentNode.replaceChild(newBtn, addFaqBtn);
            newBtn.addEventListener('click', function () { addFaqItem('', ''); });
        }
    }

    function setupSchemaToggle(checkboxId, fieldsId) {
        var checkbox = document.getElementById(checkboxId);
        var fields = document.getElementById(fieldsId);
        if (!checkbox || !fields) return;
        var newCb = checkbox.cloneNode(true);
        checkbox.parentNode.replaceChild(newCb, checkbox);
        newCb.addEventListener('change', function () {
            fields.style.display = this.checked ? '' : 'none';
        });
    }

    // ─── SEO Fields Setup ───
    function setupSeoFields(post) {
        var seo = (post && post.seo) || {};

        document.getElementById('seo-title').value = seo.seoTitle || '';
        document.getElementById('seo-meta-desc').value = seo.metaDescription || '';

        var slugInput = document.getElementById('seo-slug');
        slugInput.value = post ? post.slug : '';
        slugInput.dataset.manuallyEdited = post ? 'true' : 'false';

        // URL Type (page path vs subdomain)
        var urlType = (post && post.urlType) || 'page';
        var urlTypeRadios = document.querySelectorAll('input[name="url-type"]');
        urlTypeRadios.forEach(function (r) {
            r.checked = (r.value === urlType);
        });
        updateSlugPrefixDisplay(urlType);

        document.getElementById('seo-alt-text').value = seo.altText || '';
        document.getElementById('og-title').value = seo.ogTitle || '';
        document.getElementById('og-description').value = seo.ogDescription || '';
        document.getElementById('og-image').value = seo.ogImage || '';
        document.getElementById('seo-toc-toggle').checked = !!seo.enableToc;
        document.getElementById('focus-keyword').value = seo.focusKeyword || '';

        var schemas = seo.schemas || {};
        document.getElementById('schema-faq-toggle').checked = !!schemas.enableFaq;
        document.getElementById('schema-review-toggle').checked = !!schemas.enableReview;
        document.getElementById('schema-article-toggle').checked = schemas.enableArticle !== false;
        document.getElementById('schema-faq-fields').style.display = schemas.enableFaq ? '' : 'none';
        document.getElementById('schema-review-fields').style.display = schemas.enableReview ? '' : 'none';
        document.getElementById('schema-article-fields').style.display = schemas.enableArticle !== false ? '' : 'none';

        var faqContainer = document.getElementById('faq-items-container');
        faqContainer.innerHTML = '';
        if (schemas.faqItems && schemas.faqItems.length) {
            schemas.faqItems.forEach(function (item) {
                addFaqItem(item.question, item.answer);
            });
        }

        document.getElementById('review-rating').value = schemas.reviewRating || '';
        document.getElementById('review-name').value = schemas.reviewName || '';
        document.getElementById('review-pros').value = schemas.reviewPros || '';
        document.getElementById('review-cons').value = schemas.reviewCons || '';
        document.getElementById('article-publisher-logo').value = schemas.publisherLogo || 'img/logo.jpeg';

        setupUrlTypeToggle();
        setupSeoLiveEvents();
        updateCharCounter('seo-title', 'seo-title-count', 'seo-title-status', 50, 60);
        updateCharCounter('seo-meta-desc', 'seo-meta-count', 'seo-meta-status', 150, 160);
        updateSeoPreview();
        updateSeoChecklist();
        analyzeReadability();
    }

    // ─── SEO Live Events ───
    function setupSeoLiveEvents() {
        var titleInput = document.getElementById('post-title');
        var slugInput = document.getElementById('seo-slug');

        var onTitleInput = function () {
            if (slugInput.dataset.manuallyEdited !== 'true') {
                slugInput.value = generateSlug(titleInput.value);
            }
            updateSeoPreview();
            updateSeoChecklist();
        };
        titleInput.removeEventListener('input', onTitleInput);
        titleInput.addEventListener('input', onTitleInput);

        slugInput.addEventListener('input', function () {
            this.dataset.manuallyEdited = 'true';
            updateSeoPreview();
            updateSeoChecklist();
        });

        document.getElementById('seo-title').addEventListener('input', function () {
            updateCharCounter('seo-title', 'seo-title-count', 'seo-title-status', 50, 60);
            updateSeoPreview();
        });

        document.getElementById('seo-meta-desc').addEventListener('input', function () {
            updateCharCounter('seo-meta-desc', 'seo-meta-count', 'seo-meta-status', 150, 160);
            updateSeoPreview();
            updateSeoChecklist();
        });

        document.getElementById('focus-keyword').addEventListener('input', function () {
            updateSeoChecklist();
        });

        var editorContent = document.getElementById('post-editor-content');
        var readabilityTimer = null;
        editorContent.addEventListener('input', function () {
            clearTimeout(readabilityTimer);
            readabilityTimer = setTimeout(function () {
                analyzeReadability();
                updateSeoChecklist();
            }, 500);
        });
    }

    // ─── Character Counter ───
    function updateCharCounter(inputId, countId, statusId, idealMin, idealMax) {
        var input = document.getElementById(inputId);
        var countEl = document.getElementById(countId);
        var statusEl = document.getElementById(statusId);
        if (!input || !countEl) return;

        var len = input.value.length;
        countEl.textContent = len;

        if (statusEl) {
            if (len === 0) {
                statusEl.textContent = '';
                statusEl.className = '';
            } else if (len >= idealMin && len <= idealMax) {
                statusEl.textContent = '✓ Ideal';
                statusEl.className = 'char-good';
            } else if (len > idealMax) {
                statusEl.textContent = '⚠ Too long';
                statusEl.className = 'char-over';
            } else {
                statusEl.textContent = '↑ Too short';
                statusEl.className = 'char-warn';
            }
        }
    }

    // ─── Live Google Preview ───
    function updateSlugPrefixDisplay(urlType) {
        var prefixEl = document.getElementById('slug-prefix-display');
        var gpUrl = document.getElementById('gp-url-preview');
        var slug = document.getElementById('seo-slug').value || 'your-post-slug';
        var gpSlugSpan = document.getElementById('gp-slug-preview');

        if (urlType === 'subdomain') {
            if (prefixEl) prefixEl.textContent = '';
            if (prefixEl) prefixEl.innerHTML = '<span style="color:#999">__</span>.nvconsult.eu';
            if (gpUrl && gpSlugSpan) {
                gpUrl.innerHTML = '<span id="gp-slug-preview">' + slug + '</span>.nvconsult.eu';
            }
        } else {
            if (prefixEl) prefixEl.textContent = 'nvconsult.eu/';
            if (gpUrl && gpSlugSpan) {
                gpUrl.innerHTML = 'nvconsult.eu \u203a <span id="gp-slug-preview">' + slug + '</span>';
            }
        }
    }

    function setupUrlTypeToggle() {
        document.querySelectorAll('input[name="url-type"]').forEach(function (radio) {
            var newRadio = radio.cloneNode(true);
            radio.parentNode.replaceChild(newRadio, radio);
            newRadio.addEventListener('change', function () {
                updateSlugPrefixDisplay(this.value);
                updateSeoPreview();
            });
        });
    }

    function updateSeoPreview() {
        var seoTitle = document.getElementById('seo-title').value || document.getElementById('post-title').value || 'Your SEO Title Will Appear Here';
        var metaDesc = document.getElementById('seo-meta-desc').value || document.getElementById('post-excerpt').value || 'Your meta description will appear here.';
        var slug = document.getElementById('seo-slug').value || 'your-post-slug';

        var tp = document.getElementById('gp-title-preview');
        var dp = document.getElementById('gp-desc-preview');
        var sp = document.getElementById('gp-slug-preview');

        // Update based on URL type
        var urlTypeRadio = document.querySelector('input[name="url-type"]:checked');
        var urlType = urlTypeRadio ? urlTypeRadio.value : 'page';
        var gpUrl = document.getElementById('gp-url-preview');

        if (urlType === 'subdomain') {
            if (gpUrl) gpUrl.innerHTML = '<span id="gp-slug-preview">' + slug + '</span>.nvconsult.eu';
        } else {
            if (gpUrl) gpUrl.innerHTML = 'nvconsult.eu \u203a <span id="gp-slug-preview">' + slug + '</span>';
        }

        if (tp) tp.textContent = seoTitle;
        if (dp) dp.textContent = metaDesc;
    }

    // ─── SEO Keyword Checklist ───
    function updateSeoChecklist() {
        var keyword = (document.getElementById('focus-keyword').value || '').trim().toLowerCase();
        if (!keyword) {
            ['check-first-para', 'check-slug', 'check-meta', 'check-heading'].forEach(function (id) {
                var el = document.getElementById(id);
                if (el) el.className = 'seo-check-item';
            });
            return;
        }

        var content = document.getElementById('post-editor-content').innerHTML || '';
        var slug = (document.getElementById('seo-slug').value || '').toLowerCase();
        var metaDesc = (document.getElementById('seo-meta-desc').value || '').toLowerCase();

        var tempDiv = document.createElement('div');
        tempDiv.innerHTML = content;

        // First paragraph
        var firstPara = '';
        var firstP = tempDiv.querySelector('p');
        if (firstP) firstPara = firstP.textContent.toLowerCase();
        else firstPara = (tempDiv.textContent || '').substring(0, 300).toLowerCase();
        setCheckStatus('check-first-para', firstPara.indexOf(keyword) !== -1);

        // Slug
        var kwSlug = keyword.replace(/\s+/g, '-');
        setCheckStatus('check-slug', slug.indexOf(kwSlug) !== -1 || slug.indexOf(keyword.replace(/\s+/g, '')) !== -1);

        // Meta description
        setCheckStatus('check-meta', metaDesc.indexOf(keyword) !== -1);

        // H2 headings
        var h2s = tempDiv.querySelectorAll('h2');
        var foundInH2 = false;
        h2s.forEach(function (h2) {
            if (h2.textContent.toLowerCase().indexOf(keyword) !== -1) foundInH2 = true;
        });
        setCheckStatus('check-heading', foundInH2);
    }

    function setCheckStatus(elementId, pass) {
        var el = document.getElementById(elementId);
        if (!el) return;
        el.className = 'seo-check-item ' + (pass ? 'pass' : 'fail');
    }

    // ─── Readability Analyzer ───
    function analyzeReadability() {
        var content = document.getElementById('post-editor-content');
        if (!content) return;

        var text = content.textContent || '';
        var bar = document.getElementById('readability-bar');
        var label = document.getElementById('readability-label');
        var details = document.getElementById('readability-details');

        if (text.trim().length < 50) {
            bar.style.width = '0%';
            bar.className = 'readability-bar';
            label.textContent = 'Enter more content to analyze';
            details.innerHTML = '';
            return;
        }

        var sentences = text.split(/[.!?]+/).filter(function (s) { return s.trim().length > 0; });
        var totalSentences = sentences.length;

        var tempDiv = document.createElement('div');
        tempDiv.innerHTML = content.innerHTML;
        var paragraphs = tempDiv.querySelectorAll('p, div');
        var longParas = 0;
        var paraCount = 0;
        var issues = [];

        paragraphs.forEach(function (p) {
            var pText = p.textContent.trim();
            if (pText.length < 10) return;
            paraCount++;
            var pSentences = pText.split(/[.!?]+/).filter(function (s) { return s.trim().length > 0; });
            if (pSentences.length > 4) longParas++;
        });

        var longSentences = 0;
        sentences.forEach(function (s) {
            var words = s.trim().split(/\s+/);
            if (words.length > 25) longSentences++;
        });

        var score = 100;
        if (longParas > 0) {
            score -= longParas * 15;
            issues.push('<div class="rd-issue"><i class="fas fa-exclamation-circle"></i><span>' + longParas + ' paragraph(s) with more than 4 sentences</span></div>');
        }
        if (longSentences > 0) {
            score -= longSentences * 10;
            issues.push('<div class="rd-issue"><i class="fas fa-exclamation-circle"></i><span>' + longSentences + ' sentence(s) over 25 words</span></div>');
        }
        if (paraCount > 0 && longParas === 0) {
            issues.push('<div class="rd-ok"><i class="fas fa-check-circle"></i><span>All paragraphs are well-structured</span></div>');
        }
        if (totalSentences > 0 && longSentences === 0) {
            issues.push('<div class="rd-ok"><i class="fas fa-check-circle"></i><span>Sentence lengths are readable</span></div>');
        }

        score = Math.max(0, Math.min(100, score));
        bar.style.width = score + '%';
        bar.className = 'readability-bar ' + (score >= 70 ? 'good' : score >= 40 ? 'okay' : 'poor');
        label.textContent = score >= 70 ? 'Good readability — easy to scan' : score >= 40 ? 'Okay — some paragraphs could be shorter' : 'Needs improvement — simplify long sections';
        details.innerHTML = issues.join('');
    }

    // ─── FAQ Item Management ───
    function addFaqItem(question, answer) {
        var container = document.getElementById('faq-items-container');
        if (!container) return;
        var count = container.querySelectorAll('.faq-item').length + 1;
        var div = document.createElement('div');
        div.className = 'faq-item';
        div.innerHTML = '<div class="faq-item-header"><span class="faq-item-num">FAQ #' + count + '</span><button type="button" class="faq-remove-btn" title="Remove"><i class="fas fa-times"></i></button></div>' +
            '<input type="text" class="form-control faq-question" placeholder="Question..." value="' + (question || '').replace(/"/g, '&quot;') + '">' +
            '<textarea class="form-control faq-answer" rows="2" placeholder="Answer...">' + (answer || '') + '</textarea>';
        div.querySelector('.faq-remove-btn').addEventListener('click', function () {
            div.remove();
            renumberFaqItems();
        });
        container.appendChild(div);
    }

    function renumberFaqItems() {
        document.querySelectorAll('#faq-items-container .faq-item').forEach(function (item, i) {
            item.querySelector('.faq-item-num').textContent = 'FAQ #' + (i + 1);
        });
    }

    // ─── Collect SEO Data ───
    function collectSeoData() {
        var faqItems = [];
        document.querySelectorAll('#faq-items-container .faq-item').forEach(function (item) {
            var q = item.querySelector('.faq-question').value.trim();
            var a = item.querySelector('.faq-answer').value.trim();
            if (q && a) faqItems.push({ question: q, answer: a });
        });

        return {
            seoTitle: document.getElementById('seo-title').value.trim(),
            metaDescription: document.getElementById('seo-meta-desc').value.trim(),
            altText: document.getElementById('seo-alt-text').value.trim(),
            ogTitle: document.getElementById('og-title').value.trim(),
            ogDescription: document.getElementById('og-description').value.trim(),
            ogImage: document.getElementById('og-image').value.trim(),
            enableToc: document.getElementById('seo-toc-toggle').checked,
            focusKeyword: document.getElementById('focus-keyword').value.trim(),
            schemas: {
                enableFaq: document.getElementById('schema-faq-toggle').checked,
                enableReview: document.getElementById('schema-review-toggle').checked,
                enableArticle: document.getElementById('schema-article-toggle').checked,
                faqItems: faqItems,
                reviewRating: document.getElementById('review-rating').value,
                reviewName: document.getElementById('review-name').value.trim(),
                reviewPros: document.getElementById('review-pros').value.trim(),
                reviewCons: document.getElementById('review-cons').value.trim(),
                publisherLogo: document.getElementById('article-publisher-logo').value.trim()
            }
        };
    }

    // ═══════════════════════════════════════
    // ─── JOBS MANAGEMENT ───
    // ═══════════════════════════════════════
    var JOBS_KEY = 'nv_site_jobs';

    function getJobsData() { return JSON.parse(localStorage.getItem(JOBS_KEY) || '[]'); }
    function saveJobsData(data) { localStorage.setItem(JOBS_KEY, JSON.stringify(data)); }

    function renderJobsTable() {
        var tbody = document.getElementById('jobs-tbody');
        if (!tbody) return;
        var jobs = getJobsData().sort(function (a, b) { return new Date(b.datePosted) - new Date(a.datePosted); });

        if (jobs.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center py-4 text-muted">No job listings yet. Click "New Job" to create one!</td></tr>';
            return;
        }

        tbody.innerHTML = jobs.map(function (job) {
            return '<tr>' +
                '<td><strong>' + job.title + '</strong></td>' +
                '<td>' + (job.city || '') + ', ' + (job.country || '') + '</td>' +
                '<td><span class="category-badge">' + (job.sector || '') + '</span></td>' +
                '<td><span class="status-badge ' + job.status + '">' + job.status + '</span></td>' +
                '<td><div class="action-btns">' +
                '<button class="btn btn-sm btn-outline-primary edit-job-btn" data-id="' + job.id + '"><i class="fas fa-edit"></i></button>' +
                '<button class="btn btn-sm btn-outline-danger delete-job-btn" data-id="' + job.id + '"><i class="fas fa-trash"></i></button>' +
                '</div></td></tr>';
        }).join('');

        tbody.querySelectorAll('.edit-job-btn').forEach(function (btn) {
            btn.addEventListener('click', function () { openJobEditor(this.dataset.id); });
        });
        tbody.querySelectorAll('.delete-job-btn').forEach(function (btn) {
            btn.addEventListener('click', function () {
                if (confirm('Delete this job listing?')) { deleteJob(this.dataset.id); }
            });
        });
    }

    function openJobEditor(jobId) {
        showEditor('admin-job-editor');
        var isEdit = !!jobId;
        var job = isEdit ? getJobsData().find(function (j) { return j.id === jobId; }) : null;

        document.getElementById('job-editor-title').textContent = isEdit ? 'Edit Job Listing' : 'New Job Listing';
        document.getElementById('job-edit-id').value = isEdit ? jobId : '';
        document.getElementById('job-title').value = job ? job.title : '';
        document.getElementById('job-sector').value = job ? job.sector : '';
        document.getElementById('job-experience').value = job ? (job.experienceLevel || 'Entry-Level') : 'Entry-Level';
        document.getElementById('job-city').value = job ? job.city : '';
        renderJobCountrySelect(job ? job.country : '');
        document.getElementById('job-salary-min').value = job ? job.salaryMin : '';
        document.getElementById('job-salary-max').value = job ? job.salaryMax : '';
        document.getElementById('job-salary-note').value = job ? (job.salaryNote || 'Gross') : 'Gross';
        document.getElementById('job-contract').value = job ? (job.contractType || 'Full-Time') : 'Full-Time';
        document.getElementById('job-visa').value = job ? (job.visaSponsorship || 'Full Visa Sponsorship') : 'Full Visa Sponsorship';
        document.getElementById('job-language').value = job ? (job.language || 'English Only') : 'English Only';
        document.getElementById('job-language-detail').value = job ? (job.languageDetail || '') : '';
        document.getElementById('job-hook').value = job ? job.hook : '';
        document.getElementById('job-responsibilities').value = job ? (job.responsibilities || []).join('\n') : '';
        document.getElementById('job-must-haves').value = job ? (job.mustHaves || []).join('\n') : '';
        document.getElementById('job-nice-to-haves').value = job ? (job.niceToHaves || []).join('\n') : '';
        document.getElementById('job-status').value = job ? job.status : 'published';
        document.getElementById('job-date-posted').value = job ? job.datePosted : new Date().toISOString().split('T')[0];
        document.getElementById('job-hiring-org').value = job ? (job.hiringOrganization || 'NVConsult Recruiting Partner') : 'NVConsult Recruiting Partner';

        // Valid through — default 3 months from now
        var defaultExpiry = new Date();
        defaultExpiry.setMonth(defaultExpiry.getMonth() + 3);
        document.getElementById('job-valid-through').value = job ? (job.validThrough || defaultExpiry.toISOString().split('T')[0]) : defaultExpiry.toISOString().split('T')[0];

        // Relocation perks checkboxes
        var perks = job ? (job.relocationPerks || []) : [];
        document.querySelectorAll('input[name="job-perk"]').forEach(function (cb) {
            cb.checked = perks.indexOf(cb.value) !== -1;
        });

        // Save button
        var saveBtn = document.getElementById('save-job-btn');
        var newSave = saveBtn.cloneNode(true);
        saveBtn.parentNode.replaceChild(newSave, saveBtn);
        newSave.addEventListener('click', saveJob);
    }

    function saveJob() {
        var title = document.getElementById('job-title').value.trim();
        var sector = document.getElementById('job-sector').value;
        var city = document.getElementById('job-city').value.trim();
        var country = document.getElementById('job-country').value;
        var salaryMin = parseInt(document.getElementById('job-salary-min').value);
        var salaryMax = parseInt(document.getElementById('job-salary-max').value);
        var hook = document.getElementById('job-hook').value.trim();

        if (!title || !sector || !city || !country || !salaryMin || !salaryMax || !hook) {
            alert('Please fill in all required fields (marked with *).');
            return;
        }

        var editId = document.getElementById('job-edit-id').value;
        var perks = [];
        document.querySelectorAll('input[name="job-perk"]:checked').forEach(function (cb) { perks.push(cb.value); });

        function textToArray(id) {
            var val = document.getElementById(id).value.trim();
            if (!val) return [];
            return val.split('\n').map(function (l) { return l.trim(); }).filter(function (l) { return l; });
        }

        var jobData = {
            title: title,
            slug: generateSlug(title + ' ' + city),
            sector: sector,
            experienceLevel: document.getElementById('job-experience').value,
            city: city,
            country: country,
            salaryMin: salaryMin,
            salaryMax: salaryMax,
            salaryCurrency: 'EUR',
            salaryPeriod: 'MONTH',
            salaryNote: document.getElementById('job-salary-note').value,
            contractType: document.getElementById('job-contract').value,
            visaSponsorship: document.getElementById('job-visa').value,
            language: document.getElementById('job-language').value,
            languageDetail: document.getElementById('job-language-detail').value.trim(),
            relocationPerks: perks,
            hook: hook,
            responsibilities: textToArray('job-responsibilities'),
            mustHaves: textToArray('job-must-haves'),
            niceToHaves: textToArray('job-nice-to-haves'),
            hiringOrganization: document.getElementById('job-hiring-org').value.trim() || 'NVConsult Recruiting Partner',
            datePosted: document.getElementById('job-date-posted').value,
            validThrough: document.getElementById('job-valid-through').value,
            status: document.getElementById('job-status').value
        };

        var jobs = getJobsData();

        if (editId) {
            var idx = -1;
            jobs.forEach(function (j, i) { if (j.id === editId) idx = i; });
            if (idx !== -1) {
                jobData.id = editId;
                jobs[idx] = jobData;
            }
        } else {
            jobData.id = generateId('job');
            jobs.unshift(jobData);
        }

        saveJobsData(jobs);
        closeAllEditors();
        renderDashboard();
    }

    function deleteJob(id) {
        var jobs = getJobsData().filter(function (j) { return j.id !== id; });
        saveJobsData(jobs);
        renderDashboard();
    }

    document.addEventListener('DOMContentLoaded', init);
})();
