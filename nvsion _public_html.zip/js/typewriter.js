// NVConsult Hero Typewriter Effect — Types and erases the hero heading in a loop
(function () {
    'use strict';

    // The single hero heading text to type and erase
    var HERO_TEXT = 'Move abroad with a real plan — not expensive guesswork.';

    var TYPING_SPEED = 55;      // ms per character when typing
    var ERASING_SPEED = 30;     // ms per character when erasing
    var PAUSE_AFTER_TYPE = 2500; // ms to wait after fully typed
    var PAUSE_AFTER_ERASE = 800; // ms to wait after fully erased

    var textEl = document.getElementById('typewriter-text');
    if (!textEl) return;

    var charIndex = 0;
    var isErasing = false;

    function tick() {
        if (!isErasing) {
            // Typing
            if (charIndex <= HERO_TEXT.length) {
                // Build HTML with highlight span for "real plan"
                var currentText = HERO_TEXT.substring(0, charIndex);
                textEl.innerHTML = applyHighlight(currentText);
                charIndex++;
                setTimeout(tick, TYPING_SPEED);
            } else {
                // Finished typing — pause then start erasing
                setTimeout(function () {
                    isErasing = true;
                    tick();
                }, PAUSE_AFTER_TYPE);
            }
        } else {
            // Erasing
            if (charIndex > 0) {
                charIndex--;
                var currentText = HERO_TEXT.substring(0, charIndex);
                textEl.innerHTML = applyHighlight(currentText);
                setTimeout(tick, ERASING_SPEED);
            } else {
                // Finished erasing — pause then start typing again
                isErasing = false;
                setTimeout(tick, PAUSE_AFTER_ERASE);
            }
        }
    }

    // Apply the highlight span around "real plan" if it's fully visible in current text
    function applyHighlight(text) {
        var highlightPhrase = 'real plan';
        var idx = text.indexOf(highlightPhrase);
        if (idx !== -1) {
            return escapeHtml(text.substring(0, idx)) +
                '<span class="hero-highlight">' + escapeHtml(highlightPhrase) + '</span>' +
                escapeHtml(text.substring(idx + highlightPhrase.length));
        }
        return escapeHtml(text);
    }

    function escapeHtml(str) {
        return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    // Start the typewriter after a short delay
    setTimeout(tick, 600);
})();
