// NVConsult Visa Detail — Handles country/type URL params, dynamic breadcrumbs, dynamic cards, and post rendering
(function () {
    'use strict';

    // ─── Base Countries (hardcoded in HTML) ───
    var BASE_COUNTRIES = {
        'germany': { name: 'Germany', flag: 'https://flagcdn.com/w40/de.png' },
        'czech-republic': { name: 'Czech Republic', flag: 'https://flagcdn.com/w40/cz.png' },
        'poland': { name: 'Poland', flag: 'https://flagcdn.com/w40/pl.png' },
        'netherlands': { name: 'Netherlands', flag: 'https://flagcdn.com/w40/nl.png' },
        'austria': { name: 'Austria', flag: 'https://flagcdn.com/w40/at.png' },
        'portugal': { name: 'Portugal', flag: 'https://flagcdn.com/w40/pt.png' },
        'sweden': { name: 'Sweden', flag: 'https://flagcdn.com/w40/se.png' }
    };

    // Base visa types (for countries that already have hardcoded HTML cards)
    var BASE_VISA_TYPES = {
        'Work Visas': {
            'Germany': ['Skilled Worker Visa', 'EU Blue Card', 'Job Seeker Visa'],
            'Czech Republic': ['Employee Card', 'Work Permit'],
            'Poland': ['Work Permit', 'Seasonal Work Visa'],
            'Netherlands': ['Highly Skilled Migrant Visa', 'TWV Work Permit'],
            'Austria': ['Red-White-Red Card', 'EU Blue Card'],
            'Sweden': ['Work Permit']
        },
        'Study Visas': {
            'Germany': ['Student Visa', 'Post-Study Work Visa', 'Language Course Visa'],
            'Poland': ['Student Visa', 'Research Visa'],
            'Czech Republic': ['Student Visa', 'Long-Term Study Visa']
        }
    };

    // ─── Merged COUNTRIES map (base + admin-added) ───
    var COUNTRIES = {};

    function slugify(str) {
        return str.toLowerCase().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-');
    }

    // ─── Build dynamic countries from localStorage ───
    function buildDynamicCountries() {
        // Start with base countries
        var merged = {};
        for (var key in BASE_COUNTRIES) {
            merged[key] = BASE_COUNTRIES[key];
        }

        // Add custom countries from admin panel
        var custom = JSON.parse(localStorage.getItem('nv_custom_countries') || '[]');
        custom.forEach(function (c) {
            var slug = slugify(c.name);
            if (!merged[slug]) {
                merged[slug] = {
                    name: c.name,
                    flag: getFlagUrl(c.name, c.flag),
                    isCustom: true
                };
            }
        });

        // Also discover countries from posts that might not be in either list
        var posts = getPosts();
        posts.forEach(function (p) {
            if (p.country && p.status === 'published') {
                var slug = slugify(p.country);
                if (!merged[slug]) {
                    merged[slug] = {
                        name: p.country,
                        flag: getFlagUrl(p.country, ''),
                        isCustom: true
                    };
                }
            }
        });

        COUNTRIES = merged;
    }

    // ─── Try to get a flag URL from country name or emoji ───
    function getFlagUrl(countryName, flagEmoji) {
        // Common country name to ISO 3166-1 alpha-2 mapping
        var countryCodeMap = {
            'afghanistan': 'af', 'albania': 'al', 'algeria': 'dz', 'argentina': 'ar',
            'armenia': 'am', 'australia': 'au', 'austria': 'at', 'azerbaijan': 'az',
            'bahrain': 'bh', 'bangladesh': 'bd', 'belarus': 'by', 'belgium': 'be',
            'bosnia': 'ba', 'brazil': 'br', 'bulgaria': 'bg', 'cambodia': 'kh',
            'cameroon': 'cm', 'canada': 'ca', 'chile': 'cl', 'china': 'cn',
            'colombia': 'co', 'croatia': 'hr', 'cuba': 'cu', 'cyprus': 'cy',
            'czech republic': 'cz', 'czechia': 'cz', 'denmark': 'dk',
            'egypt': 'eg', 'estonia': 'ee', 'ethiopia': 'et', 'finland': 'fi',
            'france': 'fr', 'georgia': 'ge', 'germany': 'de', 'ghana': 'gh',
            'greece': 'gr', 'hungary': 'hu', 'iceland': 'is', 'india': 'in',
            'indonesia': 'id', 'iran': 'ir', 'iraq': 'iq', 'ireland': 'ie',
            'israel': 'il', 'italy': 'it', 'japan': 'jp', 'jordan': 'jo',
            'kazakhstan': 'kz', 'kenya': 'ke', 'korea': 'kr', 'south korea': 'kr',
            'kuwait': 'kw', 'latvia': 'lv', 'lebanon': 'lb', 'libya': 'ly',
            'lithuania': 'lt', 'luxembourg': 'lu', 'malaysia': 'my', 'malta': 'mt',
            'mexico': 'mx', 'moldova': 'md', 'mongolia': 'mn', 'montenegro': 'me',
            'morocco': 'ma', 'nepal': 'np', 'netherlands': 'nl', 'new zealand': 'nz',
            'nigeria': 'ng', 'north macedonia': 'mk', 'norway': 'no', 'oman': 'om',
            'pakistan': 'pk', 'palestine': 'ps', 'panama': 'pa', 'peru': 'pe',
            'philippines': 'ph', 'poland': 'pl', 'portugal': 'pt', 'qatar': 'qa',
            'romania': 'ro', 'russia': 'ru', 'saudi arabia': 'sa', 'senegal': 'sn',
            'serbia': 'sr', 'singapore': 'sg', 'slovakia': 'sk', 'slovenia': 'si',
            'south africa': 'za', 'spain': 'es', 'sri lanka': 'lk', 'sudan': 'sd',
            'sweden': 'se', 'switzerland': 'ch', 'syria': 'sy', 'taiwan': 'tw',
            'thailand': 'th', 'tunisia': 'tn', 'turkey': 'tr', 'turkiye': 'tr',
            'ukraine': 'ua', 'united arab emirates': 'ae', 'uae': 'ae',
            'united kingdom': 'gb', 'uk': 'gb', 'united states': 'us', 'usa': 'us',
            'uzbekistan': 'uz', 'vietnam': 'vn', 'yemen': 'ye', 'zambia': 'zm',
            'zimbabwe': 'zw'
        };

        var code = countryCodeMap[countryName.toLowerCase()];
        if (code) {
            return 'https://flagcdn.com/w40/' + code + '.png';
        }

        // If we have an emoji flag, try to extract country code from it
        if (flagEmoji && flagEmoji.length >= 2) {
            try {
                var codePoints = [];
                for (var i = 0; i < flagEmoji.length; i++) {
                    var cp = flagEmoji.codePointAt(i);
                    if (cp > 0xFFFF) i++; // Skip surrogate pair
                    if (cp >= 0x1F1E6 && cp <= 0x1F1FF) {
                        codePoints.push(String.fromCharCode(cp - 0x1F1E6 + 65));
                    }
                }
                if (codePoints.length === 2) {
                    return 'https://flagcdn.com/w40/' + codePoints.join('').toLowerCase() + '.png';
                }
            } catch (e) { /* ignore */ }
        }

        // Fallback: return empty (no flag)
        return '';
    }

    // ─── Build merged visa types from base + post data ───
    function buildMergedVisaTypes(category) {
        var merged = {};
        var baseTypes = BASE_VISA_TYPES[category] || {};

        // Start with base types
        for (var country in baseTypes) {
            merged[country] = baseTypes[country].slice();
        }

        // Add visa types discovered from posts
        var posts = getPosts().filter(function (p) {
            return p.status === 'published' && p.category === category && p.country && p.visaType;
        });

        posts.forEach(function (p) {
            if (!merged[p.country]) {
                merged[p.country] = [];
            }
            if (merged[p.country].indexOf(p.visaType) === -1) {
                merged[p.country].push(p.visaType);
            }
        });

        return merged;
    }

    function getParams() {
        var params = new URLSearchParams(window.location.search);
        return {
            country: params.get('country') || '',
            type: params.get('type') || ''
        };
    }

    function getPageCategory() {
        var path = window.location.pathname.toLowerCase();
        if (path.indexOf('service') !== -1) return { category: 'Work Visas', page: 'service.html', label: 'Work Visas' };
        if (path.indexOf('study-visa') !== -1) return { category: 'Study Visas', page: 'study-visas.html', label: 'Study Visas' };
        return null;
    }

    function getPosts() {
        return JSON.parse(localStorage.getItem('nv_site_posts') || '[]');
    }

    function getPublished(category) {
        return getPosts().filter(function (p) {
            return p.status === 'published' && p.category === category;
        }).sort(function (a, b) { return new Date(b.date) - new Date(a.date); });
    }

    function formatDate(dateStr) {
        var d = new Date(dateStr);
        return d.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
    }

    function findCountryBySlug(slug) {
        return COUNTRIES[slug] || null;
    }

    function findCountryByName(name) {
        for (var key in COUNTRIES) {
            if (COUNTRIES[key].name === name) return { slug: key, data: COUNTRIES[key] };
        }
        return null;
    }

    // ─── Update Breadcrumbs ───
    function updateBreadcrumbs(pageInfo, params) {
        var breadcrumbOl = document.querySelector('.breadcrumb');
        if (!breadcrumbOl) return;

        var crumbs = [
            { label: 'Home', link: 'index.html' },
            { label: pageInfo.label, link: pageInfo.page }
        ];

        if (params.country) {
            var countryData = findCountryBySlug(params.country);
            if (countryData) {
                var flagHtml = countryData.flag ? '<img src="' + countryData.flag + '" class="country-flag" alt="">' : '';
                crumbs.push({
                    label: flagHtml + ' ' + countryData.name,
                    link: pageInfo.page + '?country=' + params.country
                });
            }
        }

        if (params.type) {
            var typeLabel = params.type.replace(/-/g, ' ').replace(/\b\w/g, function (l) { return l.toUpperCase(); });
            crumbs.push({ label: typeLabel, link: '' });
        }

        // Mark last as active
        breadcrumbOl.innerHTML = crumbs.map(function (crumb, i) {
            if (i === crumbs.length - 1) {
                return '<li class="breadcrumb-item active text-secondary">' + crumb.label + '</li>';
            }
            return '<li class="breadcrumb-item"><a href="' + crumb.link + '" class="text-white">' + crumb.label + '</a></li>';
        }).join('');
    }

    // ─── Update Page Header ───
    function updatePageHeader(pageInfo, params) {
        var header = document.querySelector('.bg-breadcrumb h3, .bg-breadcrumb h1');
        if (!header) return;

        if (params.type) {
            var typeLabel = params.type.replace(/-/g, ' ').replace(/\b\w/g, function (l) { return l.toUpperCase(); });
            var countryData = findCountryBySlug(params.country);
            header.textContent = typeLabel + (countryData ? ' — ' + countryData.name : '');
        } else if (params.country) {
            var countryData2 = findCountryBySlug(params.country);
            if (countryData2) {
                header.textContent = pageInfo.label + ' — ' + countryData2.name;
            }
        }
    }

    // ─── Inject Dynamic Country Cards for Admin-Added Countries ───
    function injectDynamicCountryCards(pageInfo) {
        var cardContainer = document.querySelector('.service .row.g-4');
        if (!cardContainer) return;

        var mergedVisaTypes = buildMergedVisaTypes(pageInfo.category);

        // Find which countries already have hardcoded HTML cards
        var existingCountries = {};
        cardContainer.querySelectorAll('.service-content h4, .bg-primary a').forEach(function (el) {
            var text = el.textContent.toLowerCase();
            for (var key in BASE_COUNTRIES) {
                if (text.indexOf(BASE_COUNTRIES[key].name.toLowerCase()) !== -1) {
                    existingCountries[BASE_COUNTRIES[key].name] = true;
                }
            }
        });

        // Find countries that have posts but no hardcoded card
        var newCountries = [];
        for (var countryName in mergedVisaTypes) {
            if (!existingCountries[countryName] && mergedVisaTypes[countryName].length > 0) {
                var countryInfo = findCountryByName(countryName);
                if (countryInfo) {
                    newCountries.push({
                        name: countryName,
                        slug: countryInfo.slug,
                        flag: countryInfo.data.flag,
                        visaTypes: mergedVisaTypes[countryName]
                    });
                }
            }
        }

        // Also add custom countries that might not have posts yet but were added by admin
        var custom = JSON.parse(localStorage.getItem('nv_custom_countries') || '[]');
        custom.forEach(function (c) {
            var slug = slugify(c.name);
            if (!existingCountries[c.name] && !newCountries.some(function (nc) { return nc.name === c.name; })) {
                // Check if this country has any published posts in this category
                var hasPosts = getPosts().some(function (p) {
                    return p.status === 'published' && p.category === pageInfo.category && p.country === c.name;
                });
                if (hasPosts) {
                    var types = mergedVisaTypes[c.name] || [];
                    newCountries.push({
                        name: c.name,
                        slug: slug,
                        flag: getFlagUrl(c.name, c.flag),
                        visaTypes: types
                    });
                }
            }
        });

        if (newCountries.length === 0) return;

        // Find a representative image from posts for each new country
        var posts = getPosts();

        newCountries.forEach(function (country, idx) {
            // Check for cover image from custom country data first
            var customCountries = JSON.parse(localStorage.getItem('nv_custom_countries') || '[]');
            var customEntry = customCountries.filter(function (c) { return c.name === country.name; })[0];
            var cardImage = (customEntry && customEntry.coverImage) ? customEntry.coverImage : '';

            // Fallback: find the first post image for this country
            if (!cardImage) {
                var countryPosts = posts.filter(function (p) {
                    return p.status === 'published' && p.category === pageInfo.category && p.country === country.name && p.image;
                });
                cardImage = countryPosts.length > 0 ? countryPosts[0].image : '';
            }

            var detailUrl = 'country-detail.html?page=' + encodeURIComponent(pageInfo.category) + '&country=' + country.slug;
            var flagImg = country.flag ? '<img src="' + country.flag + '" alt="" class="country-flag">' : '';
            var visaLabel = pageInfo.category === 'Work Visas' ? 'Work Visa' : 'Study Visa';
            var btnLabel = pageInfo.category === 'Work Visas' ? 'Check Eligibility' : 'Learn More';

            // Build description from visa types
            var description = country.visaTypes.join(', ');
            if (!description) {
                description = 'Explore ' + visaLabel.toLowerCase() + ' options for ' + country.name + '.';
            } else {
                description += ' — explore visa pathways for ' + country.name + '.';
            }

            // Build visa type links
            var visaLinksHtml = '';
            if (country.visaTypes.length > 0) {
                visaLinksHtml = '<div class="visa-type-links mt-3 px-4 pb-2">';
                country.visaTypes.forEach(function (type) {
                    var typeSlug = slugify(type);
                    var url = 'visa-info.html?page=' + encodeURIComponent(pageInfo.category) + '&country=' + country.slug + '&type=' + typeSlug;
                    visaLinksHtml += '<a href="' + url + '" class="visa-type-link"><i class="fas fa-arrow-right me-1"></i>' + type + '</a>';
                });
                visaLinksHtml += '</div>';
            }

            // Build image HTML — only show if image exists
            var imageHtml = cardImage
                ? '<img src="' + cardImage + '" class="img-fluid w-100 rounded" alt="' + country.name + ' ' + visaLabel + '">'
                : '<div class="d-flex align-items-center justify-content-center bg-light rounded" style="height:200px;"><i class="fas fa-globe fa-3x text-muted"></i></div>';

            var cardHtml =
                '<div class="col-lg-6 col-xl-4 wow fadeInUp" data-wow-delay="' + (0.1 + (idx * 0.2)) + 's">' +
                    '<div class="service-item">' +
                        '<div class="service-inner">' +
                            '<div class="service-img">' +
                                imageHtml +
                            '</div>' +
                            '<div class="service-title">' +
                                '<div class="service-title-name">' +
                                    '<div class="bg-primary text-center rounded p-3 mx-5 mb-4">' +
                                        '<a href="' + detailUrl + '" class="h4 text-white mb-0">' + country.name + ' ' + flagImg + '</a>' +
                                    '</div>' +
                                    '<a class="btn bg-light text-secondary rounded-pill py-3 px-5 mb-4" href="' + detailUrl + '">' + btnLabel + '</a>' +
                                '</div>' +
                                '<div class="service-content pb-4">' +
                                    '<a href="' + detailUrl + '"><h4 class="text-white mb-4 py-3">' + country.name + ' ' + visaLabel + '</h4></a>' +
                                    '<div class="px-4">' +
                                        '<p class="mb-4">' + description + '</p>' +
                                        '<a class="btn btn-primary border-secondary rounded-pill text-white py-3 px-5" href="' + detailUrl + '">' + btnLabel + '</a>' +
                                        visaLinksHtml +
                                    '</div>' +
                                '</div>' +
                            '</div>' +
                        '</div>' +
                    '</div>' +
                '</div>';

            cardContainer.insertAdjacentHTML('beforeend', cardHtml);
        });

        // Re-init WOW animations for new cards
        if (typeof WOW !== 'undefined') new WOW().init();
    }

    // ─── Inject Visa Type Links into Existing Country Cards ───
    function enhanceCountryCards(pageInfo) {
        var mergedVisaTypes = buildMergedVisaTypes(pageInfo.category);

        document.querySelectorAll('.service-content').forEach(function (card) {
            var titleEl = card.querySelector('h4');
            if (!titleEl) return;

            // Find the country from the card title
            var titleText = titleEl.textContent;
            var countryMatch = null;
            for (var key in COUNTRIES) {
                if (titleText.toLowerCase().indexOf(COUNTRIES[key].name.toLowerCase()) !== -1) {
                    countryMatch = { slug: key, data: COUNTRIES[key] };
                    break;
                }
            }
            if (!countryMatch) return;

            // Skip if visa type links already added (e.g. for dynamically injected cards)
            if (card.querySelector('.visa-type-links')) return;

            // Get merged visa types for this country
            var visaTypes = mergedVisaTypes[countryMatch.data.name] || [];
            if (visaTypes.length === 0) return;

            // Create visa type links
            var linksHtml = '<div class="visa-type-links mt-3 px-4 pb-2">';
            visaTypes.forEach(function (type) {
                var typeSlug = slugify(type);
                var url = 'visa-info.html?page=' + encodeURIComponent(pageInfo.category) + '&country=' + countryMatch.slug + '&type=' + typeSlug;
                linksHtml += '<a href="' + url + '" class="visa-type-link">' +
                    '<i class="fas fa-arrow-right me-1"></i>' + type + '</a>';
            });
            linksHtml += '</div>';

            // Insert before the last button in the card
            var btnContainer = card.querySelector('.px-4');
            if (btnContainer) {
                btnContainer.insertAdjacentHTML('beforeend', linksHtml);
            }
        });
    }

    // ─── Update Country Card Links ───
    function updateCardLinks(pageInfo) {
        // Find country slug from card and set country name link
        document.querySelectorAll('.service-title-name .bg-primary a').forEach(function (link) {
            var text = link.textContent;
            for (var key in COUNTRIES) {
                if (text.indexOf(COUNTRIES[key].name) !== -1) {
                    link.href = pageInfo.page + '?country=' + key;
                    break;
                }
            }
        });

        // Update Check Eligibility / Learn More buttons to go to country-detail.html
        document.querySelectorAll('.service-item').forEach(function (card) {
            var countryLink = card.querySelector('.bg-primary a');
            if (!countryLink) return;

            var countrySlug = '';
            for (var key in COUNTRIES) {
                if (countryLink.textContent.indexOf(COUNTRIES[key].name) !== -1) {
                    countrySlug = key;
                    break;
                }
            }
            if (!countrySlug) return;

            var detailUrl = 'country-detail.html?page=' + encodeURIComponent(pageInfo.category) + '&country=' + countrySlug;

            // Update all buttons (Check Eligibility / Learn More) inside the card
            card.querySelectorAll('.service-title-name .btn, .service-content .btn').forEach(function (btn) {
                btn.href = detailUrl;
            });

            // Update hover content h4 links
            card.querySelectorAll('.service-content h4 a, .service-content > a:not(.btn):not(.visa-type-link)').forEach(function (link) {
                link.href = detailUrl;
            });
        });
    }

    // ─── Render Country-Filtered Posts ───
    function renderFilteredPosts(pageInfo, params) {
        var container = document.getElementById('category-posts-grid');
        if (!container) return;

        var posts = getPublished(pageInfo.category);

        // Filter by country
        if (params.country) {
            var countryData = findCountryBySlug(params.country);
            if (countryData) {
                posts = posts.filter(function (p) { return p.country === countryData.name; });
            }
        }

        // Filter by visa type
        if (params.type) {
            posts = posts.filter(function (p) {
                return p.visaType && slugify(p.visaType) === params.type;
            });
        }

        var section = container.closest('.category-posts-section');
        if (posts.length === 0) {
            if (section && !params.country) section.style.display = 'none';
            else if (section) {
                section.style.display = '';
                container.innerHTML = '<div class="col-12 text-center py-4"><p class="text-muted fs-5">No posts yet for this selection. Check back soon!</p></div>';
            }
            return;
        }

        if (section) section.style.display = '';

        // Update section title
        var sectionTitle = section ? section.querySelector('h1') : null;
        if (sectionTitle && params.country) {
            var cd = findCountryBySlug(params.country);
            if (cd && params.type) {
                var tl = params.type.replace(/-/g, ' ').replace(/\b\w/g, function (l) { return l.toUpperCase(); });
                sectionTitle.textContent = tl + ' in ' + cd.name;
            } else if (cd) {
                sectionTitle.textContent = pageInfo.label + ' — ' + cd.name;
            }
        }

        container.innerHTML = posts.map(function (post, i) {
            var postUrl = 'blog-post.html?slug=' + post.slug;
            var badges = '';
            if (post.country) {
                var cf = findCountryByName(post.country);
                var flagHtml = (cf && cf.data.flag) ? '<img src="' + cf.data.flag + '" style="width:16px;vertical-align:middle;margin-right:4px;">' : '';
                badges += '<span class="badge bg-primary me-1">' + flagHtml + post.country + '</span>';
            }
            if (post.visaType) {
                badges += '<span class="badge bg-secondary">' + post.visaType + '</span>';
            }

            // Only show image section if post has an image
            var imageHtml = '';
            if (post.image) {
                imageHtml = '<div class="blog-card-img">' +
                    '<img src="' + post.image + '" alt="' + post.title + '">' +
                    '<span class="blog-category">' + post.category + '</span>' +
                '</div>';
            }

            return '<div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="' + (0.1 + (i * 0.1)) + 's">' +
                '<div class="blog-card">' +
                    imageHtml +
                    '<div class="blog-card-body">' +
                        '<div class="blog-meta">' +
                            '<span><i class="fas fa-calendar-alt"></i> ' + formatDate(post.date) + '</span>' +
                            '<span><i class="fas fa-user"></i> ' + post.author + '</span>' +
                        '</div>' +
                        (badges ? '<div class="mb-2">' + badges + '</div>' : '') +
                        '<h5><a href="' + postUrl + '">' + post.title + '</a></h5>' +
                        '<p class="blog-excerpt">' + post.excerpt + '</p>' +
                    '</div>' +
                    '<div class="blog-card-footer">' +
                        '<a href="' + postUrl + '" class="read-more">Read More <i class="fas fa-arrow-right ms-1"></i></a>' +
                    '</div>' +
                '</div>' +
            '</div>';
        }).join('');
    }

    // ─── Show/Hide Country Cards Based on URL ───
    function handleCountryFilter(params) {
        if (!params.country) return;

        var countryCards = document.querySelectorAll('.service-item');
        var countryData = findCountryBySlug(params.country);
        if (!countryData) return;

        countryCards.forEach(function (card) {
            var titleEl = card.querySelector('.service-content h4, .bg-primary a');
            if (!titleEl) return;
            var text = titleEl.textContent.toLowerCase();
            if (text.indexOf(countryData.name.toLowerCase()) === -1) {
                card.closest('.col-lg-6, .col-xl-4').style.display = 'none';
            }
        });
    }

    // ─── Init ───
    function init() {
        var pageInfo = getPageCategory();
        if (!pageInfo) return;

        // Build dynamic countries map first
        buildDynamicCountries();

        var params = getParams();

        // Inject dynamic cards for admin-added countries (before enhancing)
        injectDynamicCountryCards(pageInfo);

        // Always update card links and add visa type links
        updateCardLinks(pageInfo);
        enhanceCountryCards(pageInfo);

        // If URL has country/type params, update everything
        if (params.country || params.type) {
            updateBreadcrumbs(pageInfo, params);
            updatePageHeader(pageInfo, params);
            handleCountryFilter(params);
            renderFilteredPosts(pageInfo, params);
        }
    }

    document.addEventListener('DOMContentLoaded', init);
})();
