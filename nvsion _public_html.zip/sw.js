// NVConsult Service Worker — Push Notifications & New Post Alerts
var CACHE_NAME = 'nvonsult-v2';
var POST_CHECK_INTERVAL = 30000; // Check every 30 seconds

// Install — immediately activate
self.addEventListener('install', function (event) {
    self.skipWaiting();
});

// Activate — claim all clients
self.addEventListener('activate', function (event) {
    event.waitUntil(
        caches.keys().then(function (names) {
            return Promise.all(
                names.filter(function (name) { return name !== CACHE_NAME; })
                    .map(function (name) { return caches.delete(name); })
            );
        }).then(function () {
            return self.clients.claim();
        })
    );
});

// ─── Push Event (for future backend/VAPID integration) ───
self.addEventListener('push', function (event) {
    var data = {};
    if (event.data) {
        try { data = event.data.json(); } catch (e) {
            data = { title: 'NVConsult', body: event.data.text() };
        }
    }

    var title = data.title || 'NVConsult — New Update!';
    var options = {
        body: data.body || 'Check out our latest immigration update!',
        icon: 'img/about-2.png',
        badge: 'img/about-2.png',
        tag: data.tag || 'nv-notification',
        vibrate: [200, 100, 200],
        requireInteraction: false,
        data: {
            url: data.url || 'index.html'
        },
        actions: [
            { action: 'read', title: 'Read Now' },
            { action: 'dismiss', title: 'Dismiss' }
        ]
    };

    event.waitUntil(
        self.registration.showNotification(title, options)
    );
});

// ─── Notification Click Handler ───
self.addEventListener('notificationclick', function (event) {
    event.notification.close();

    if (event.action === 'dismiss') return;

    var urlToOpen = (event.notification.data && event.notification.data.url)
        ? event.notification.data.url
        : 'index.html';

    // Make relative URLs absolute
    if (urlToOpen.indexOf('http') !== 0) {
        urlToOpen = self.registration.scope + urlToOpen;
    }

    event.waitUntil(
        clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (windowClients) {
            // Focus existing tab if open
            for (var i = 0; i < windowClients.length; i++) {
                var client = windowClients[i];
                if (client.url.indexOf(urlToOpen) !== -1 && 'focus' in client) {
                    return client.focus();
                }
            }
            // Otherwise open new window
            if (clients.openWindow) {
                return clients.openWindow(urlToOpen);
            }
        })
    );
});

// ─── Message Handler (from admin panel or newsletter.js) ───
self.addEventListener('message', function (event) {
    if (!event.data) return;

    // New post published from admin
    if (event.data.type === 'NEW_POST') {
        var postUrl = event.data.slug
            ? 'blog-post.html?slug=' + event.data.slug
            : 'blog-post.html?id=' + event.data.id;

        self.registration.showNotification('📝 New Post — NVConsult', {
            body: event.data.title || 'A new post has been published!',
            icon: 'img/about-2.png',
            badge: 'img/about-2.png',
            tag: 'nv-new-post-' + (event.data.id || Date.now()),
            vibrate: [200, 100, 200],
            data: { url: postUrl },
            actions: [
                { action: 'read', title: 'Read Now' },
                { action: 'dismiss', title: 'Dismiss' }
            ]
        });
    }

    // Check for new posts periodically
    if (event.data.type === 'CHECK_NEW_POSTS') {
        // Forward to all clients to check localStorage
        self.clients.matchAll().then(function (allClients) {
            allClients.forEach(function (client) {
                client.postMessage({ type: 'CHECK_NEW_POSTS_RESPONSE' });
            });
        });
    }
});
