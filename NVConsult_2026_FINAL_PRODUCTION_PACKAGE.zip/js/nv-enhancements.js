(function(){
 'use strict';
 if(!window.NV) return;
 const esc=window.NV.esc;
 const foot=document.querySelector('.nv-footer');
 if(foot&&!foot.querySelector('#nvNewsletter')){
  const box=document.createElement('div'); box.id='nvNewsletter';
  box.style.cssText='margin:32px 0 0;padding:22px;border:1px solid #29435c;border-radius:16px;background:#092946';
  box.innerHTML='<div style="display:flex;gap:15px;align-items:center;justify-content:space-between;flex-wrap:wrap"><div><strong style="color:#fff">Get useful updates</strong><div style="font-size:12px">Visa news, guides and practical international mobility information.</div></div><form id="nvNewsletterForm" style="display:flex;gap:8px;flex:1;max-width:520px"><input class="nv-input" name="email" type="email" placeholder="Your email address" required><button class="nv-btn blue">Subscribe</button></form></div>';
  const wrap=foot.querySelector('.nv-wrap'); if(wrap) wrap.prepend(box);
  box.querySelector('form').onsubmit=async e=>{e.preventDefault();const email=new FormData(e.target).get('email');try{const r=await fetch('api/index.php?route=newsletter/subscribe',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,source:location.pathname})});if(!r.ok)throw new Error();e.target.reset();alert('Thanks — you are subscribed.')}catch{alert('Subscription could not be completed right now. Please try again later.')}};
 }
 if(!localStorage.getItem('nv_cookie_consent')){
  const b=document.createElement('div');b.style.cssText='position:fixed;left:16px;right:16px;bottom:16px;z-index:7000;background:#fff;border:1px solid #dce6ef;border-radius:16px;box-shadow:0 20px 50px rgba(6,39,70,.18);padding:18px;max-width:760px;margin:auto';
  b.innerHTML='<strong>Privacy & cookies</strong><p style="margin:6px 0;font-size:13px;color:#667a92">NVConsult uses essential website functions and may use optional analytics or third-party services when enabled.</p><div style="display:flex;gap:8px;flex-wrap:wrap"><button id="nvAccept" class="nv-btn">Accept</button><button id="nvEssential" class="nv-btn light">Essential only</button><a class="nv-link" href="cookie-policy.html">Cookie Policy</a></div>';
  document.body.appendChild(b);b.querySelector('#nvAccept').onclick=()=>{localStorage.setItem('nv_cookie_consent','accepted');b.remove()};b.querySelector('#nvEssential').onclick=()=>{localStorage.setItem('nv_cookie_consent','essential');b.remove()};
 }
 if(!document.querySelector('#nvChat')){
  const t=document.createElement('button');t.id='nvChat';t.className='nv-btn blue';t.textContent='Chat';t.style.cssText='position:fixed;right:18px;bottom:18px;z-index:6900;border-radius:999px;box-shadow:0 10px 28px rgba(6,39,70,.2)';document.body.appendChild(t);
  const box=document.createElement('div');box.style.cssText='display:none;position:fixed;right:18px;bottom:72px;width:min(370px,calc(100vw - 36px));height:480px;z-index:6901;background:#fff;border:1px solid #dce6ef;border-radius:18px;box-shadow:0 20px 60px rgba(6,39,70,.22);overflow:hidden';
  box.innerHTML='<div style="background:#062746;color:#fff;padding:14px 16px;display:flex;justify-content:space-between"><strong>NVConsult Assistant</strong><button id="chatClose" style="background:none;color:#fff;border:0;font-size:20px">×</button></div><div id="chatLog" style="height:370px;overflow:auto;padding:14px"><div class="nv-notice">Ask about destinations, jobs, study or immigration. For current rules, verify official sources.</div></div><form id="chatForm" style="display:flex;gap:6px;padding:10px;border-top:1px solid #dce6ef"><input class="nv-input" name="message" placeholder="Type your question…" required><button class="nv-btn">Send</button></form>';
  document.body.appendChild(box);t.onclick=()=>{box.style.display='block';t.style.display='none'};box.querySelector('#chatClose').onclick=()=>{box.style.display='none';t.style.display='inline-flex'};
  box.querySelector('#chatForm').onsubmit=async e=>{e.preventDefault();const input=e.target.message,msg=input.value.trim();if(!msg)return;const log=box.querySelector('#chatLog');log.insertAdjacentHTML('beforeend',`<p><strong>You:</strong> ${esc(msg)}</p>`);input.value='';try{const r=await fetch('api/chat.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages:[{role:'user',content:msg}]})});const d=await r.json();const ans=d.choices?.[0]?.message?.content||'The assistant is not configured right now. Please contact NVConsult.';log.insertAdjacentHTML('beforeend',`<p><strong>NVConsult:</strong> ${esc(ans)}</p>`)}catch{log.insertAdjacentHTML('beforeend','<p><strong>NVConsult:</strong> The assistant is temporarily unavailable. Please use the contact or consultation options.</p>')}log.scrollTop=log.scrollHeight};
 }
})();
