(async function(){
 const F=window.NV_PAGE_DATA, esc=NV.esc;
 let countries=await NV.getJSON('api/index.php?route=countries',F.countries);
 const map=L.map('nv-map',{zoomControl:false,scrollWheelZoom:false}).setView([25,10],2);
 L.control.zoom({position:'bottomright'}).addTo(map);
 L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap contributors',maxZoom:6}).addTo(map);
 let markers=[]; const hero=document.querySelector('#home-countries');
 function renderCards(list){
  hero.innerHTML=list.map(c=>`<article class="nv-card media"><img src="${esc(c.image||'img/about-2.png')}" alt="${esc(c.name)}"><div class="nv-card-body"><div class="country-name">${c.flag||''} ${esc(c.name)}</div><p>${esc(c.description||'Explore work, study, immigration and jobs.')}</p><div class="nv-tags"><span class="nv-tag">Work</span><span class="nv-tag">Study</span><span class="nv-tag">Immigration</span><span class="nv-tag">Jobs</span></div><a class="nv-link" href="country-detail.html?slug=${encodeURIComponent(c.slug)}">Explore destination →</a></div></article>`).join('') || '<div class="nv-empty" style="grid-column:1/-1">No destinations found.</div>';
 }
 function drawMap(list){
  markers.forEach(m=>map.removeLayer(m)); markers=[];
  list.filter(c=>Number(c.show_in_explorer)).forEach(c=>{
   if(c.map_lat==null||c.map_lng==null)return;
   markers.push(L.circleMarker([Number(c.map_lat),Number(c.map_lng)],{radius:7,weight:2,fillOpacity:.9}).addTo(map).bindPopup(`<strong>${esc(c.flag||'')} ${esc(c.name)}</strong><br><a href="country-detail.html?slug=${encodeURIComponent(c.slug)}">Explore →</a>`));
  });
 }
 function apply(){
  const g=document.querySelector('.nv-pill.active[data-goal]')?.dataset.goal||'all';
  const r=document.querySelector('.nv-pill.active[data-region]')?.dataset.region||'All Regions';
  const q=document.querySelector('#countrySearch').value.toLowerCase();
  const list=countries.filter(c=>(g==='all'||Number(c[g]))&&(r==='All Regions'||c.region===r)&&(!q||c.name.toLowerCase().includes(q)));
  renderCards(list.filter(c=>c.featured||g==='all').slice(0,6)); drawMap(list);
 }
 document.querySelectorAll('[data-goal]').forEach(b=>b.onclick=()=>{document.querySelectorAll('[data-goal]').forEach(x=>x.classList.remove('active'));b.classList.add('active');apply()});
 document.querySelectorAll('[data-region]').forEach(b=>b.onclick=()=>{document.querySelectorAll('[data-region]').forEach(x=>x.classList.remove('active'));b.classList.add('active');apply()});
 document.querySelector('#countrySearch').oninput=apply; apply();
 const content=await NV.getJSON('api/index.php?route=content',F.content);
 document.querySelector('#home-news').innerHTML=content.slice(0,6).map(x=>`<article class="nv-card"><span class="nv-badge">${x.content_type==='visa_news'?'Visa News':'Guide'}</span><h3>${esc(x.title)}</h3><p>${esc(x.excerpt||'')}</p><a class="nv-link" href="post.html?slug=${encodeURIComponent(x.slug)}">Read more →</a></article>`).join('');
})();
