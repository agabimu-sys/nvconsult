# NVConsult 2026 — Final Scratch-Rebuilt Handover

## Objective
A clean public frontend rebuilt from scratch around the approved NVConsult visual system, while preserving existing NVConsult content, assets, CV Studio functionality, booking concept and database/API capabilities.

## Public architecture
- `index.html`: destination-led homepage and interactive Country Explorer.
- `countries.html`: searchable/filterable destination directory.
- `country-detail.html?slug=...`: database-driven destination view.
- `service.html`: Work.
- `study-visas.html`: Study.
- `immigration.html`: Immigration.
- `jobs-abroad.html`: Jobs.
- `job-detail.html?id=...`: Job detail.
- `blog.html`: Visa News and Guides.
- `post.html?slug=...`: database-driven article.
- `pathway.html?slug=...`: database-driven pathway.
- `check-options.html`: discovery questionnaire.
- `page.html?type=...`: flexible landing-page entry point.
- `cv-maker.html`: existing CV Studio retained as a specialist application.
- `admin-cms.html`: server-side CMS.

## CMS capabilities
Countries, content, jobs, pathways, study programs, pages, templates, page sections, taxonomies, collections, reusable components, options questions/rules, social accounts, sharing, settings, booking, analytics, newsletter, audit log and media uploads.

## Reusable components
Hero, Rich Text, Image, Two Columns, Stats, Country Cards, Job Cards, Visa News Cards, Guide Cards, Pathway Cards, Study Program Cards, Success Stories, FAQ, Accordion, Timeline, Comparison, CTA, Newsletter, Video and Collection.

## Data
`database/schema.sql` defines the application schema. `database/seed_production.sql` contains the production baseline country/content/pathway/job/settings data migrated from the prior implementation. `data/*.json` provides a frontend fallback when PHP/MySQL is unavailable during local development.

## Existing assets
All 19 original image assets were copied into `img/`. Original JS/CSS modules (except the insecure chatbot credential file) are retained under `legacy-original/` for reference.

## Security
- Never put database, AI or social credentials in frontend JS.
- Configure `api/config.php` from `config.example.php` with environment/server secrets.
- Rotate the credential previously exposed in the original chatbot JS.
- Use HTTPS, secure session cookies and regular database/filesystem backups.
- Review upload permissions and allowed MIME types on the production host.

## Social publishing
Native share composers are supported. Direct page/account publishing requires official provider OAuth/API credentials and must be implemented server-side.

## Booking
Cal.com settings remain centralized in `booking_settings` and editable through the CMS. The public UI exposes a booking modal that reads those settings.

## Deployment
1. Back up current Hostinger `public_html` and database.
2. Create a staging directory/subdomain.
3. Upload package contents.
4. Create MySQL database and import `database/schema.sql`, then `database/seed_production.sql`.
5. Copy `api/config.example.php` to `api/config.php` and set real secrets.
6. Create the first admin using the provided admin creation flow.
7. Verify PHP version, PDO MySQL, sessions, file uploads and HTTPS.
8. Configure real Cal.com and social accounts.
9. Test every public page on desktop/tablet/mobile.
10. Test login, CRUD, publishing, uploads, newsletter, options, booking and social share.
11. Confirm expired jobs are not shown as current.
12. Deploy to the live root only after staging approval.

## Important content policy
AI-generated or imported visa information must be reviewed by a human before publication. Visa News should record published/updated/last-verified dates and official sources. Do not publish unverified job sponsorship claims.
