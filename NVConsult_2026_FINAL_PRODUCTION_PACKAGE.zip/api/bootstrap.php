<?php
declare(strict_types=1);
$configFile=__DIR__.'/config.php'; if(!is_file($configFile)){http_response_code(500);header('Content-Type: application/json');echo json_encode(['error'=>'API not configured.']);exit;}
$config=require $configFile;
if(session_status()!==PHP_SESSION_ACTIVE){session_name($config['session_name']??'nvconsult_admin');session_set_cookie_params(['httponly'=>true,'secure'=>(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'),'samesite'=>'Lax']);session_start();}
$dsn=sprintf('mysql:host=%s;dbname=%s;charset=%s',$config['db']['host'],$config['db']['name'],$config['db']['charset']??'utf8mb4');
try{$pdo=new PDO($dsn,$config['db']['user'],$config['db']['pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);}catch(Throwable $e){http_response_code(500);header('Content-Type: application/json');echo json_encode(['error'=>'Database connection failed.']);exit;}
function json_response($data,int $status=200):never{http_response_code($status);header('Content-Type: application/json; charset=utf-8');echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
function body_json():array{$d=json_decode(file_get_contents('php://input')?:'{}',true);return is_array($d)?$d:[];}
function slugify(string $v):string{$v=iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$v)?:$v;$v=strtolower($v);$v=preg_replace('/[^a-z0-9]+/','-',$v)??'';return trim($v,'-');}
function require_admin():void{if(empty($_SESSION['admin_id']))json_response(['error'=>'Authentication required'],401);}
function require_role(array $roles):void{require_admin();if(!in_array($_SESSION['role']??'', $roles,true))json_response(['error'=>'Insufficient permissions'],403);}
function require_csrf():void{$t=$_SERVER['HTTP_X_CSRF_TOKEN']??'';if(!$t||empty($_SESSION['csrf'])||!hash_equals($_SESSION['csrf'],$t))json_response(['error'=>'Invalid CSRF token'],419);}
function audit(PDO $pdo,string $action,string $type='',?int $id=null,array $details=[]):void{$s=$pdo->prepare('INSERT INTO audit_log(admin_id,action,entity_type,entity_id,details_json) VALUES(?,?,?,?,?)');$s->execute([$_SESSION['admin_id']??null,$action,$type,$id,json_encode($details)]);}
function setting(PDO $pdo,string $key,$default=null){$s=$pdo->prepare('SELECT value_json FROM settings WHERE `key`=?');$s->execute([$key]);$r=$s->fetch();if(!$r)return $default;$v=json_decode($r['value_json'],true);return $v===null?$r['value_json']:$v;}
