<?php
return [
  'db'=>['host'=>'localhost','name'=>'nvconsult','user'=>'YOUR_DB_USER','pass'=>'YOUR_DB_PASSWORD','charset'=>'utf8mb4'],
  'session_name'=>'nvconsult_admin',
  'ai'=>['endpoint'=>'','api_key'=>''],
  'app_key'=>'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET',
];
