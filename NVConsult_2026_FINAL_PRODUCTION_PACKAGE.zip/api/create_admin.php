<?php
// Run once from CLI or temporarily through a protected environment, then delete this file.
if(PHP_SAPI!=='cli'){http_response_code(403);exit('CLI only');}
require __DIR__.'/bootstrap.php';
$email=$argv[1]??'';$password=$argv[2]??'';$role=$argv[3]??'super_admin';
if(!$email||strlen($password)<12)exit("Usage: php create_admin.php email password [role]\n");
$hash=password_hash($password,PASSWORD_DEFAULT);$s=$pdo->prepare('INSERT INTO admin_users(email,password_hash,role) VALUES(?,?,?)');$s->execute([$email,$hash,$role]);echo "Admin created.\n";
