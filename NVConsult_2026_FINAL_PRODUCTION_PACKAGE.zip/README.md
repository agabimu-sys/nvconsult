# NVConsult 2026 — Final Scratch-Rebuilt Production Package

This package is the clean public-site rebuild. It is intentionally not a patch over the old Travisa/Bootstrap page UI.

## Included
- Full public frontend with one NVConsult design system
- Destination-led homepage with interactive Leaflet Country Explorer
- Countries, country detail, Work, Study, Immigration, Jobs, Visa News, Guides, Success Stories, Pricing, Contact, Resources, Options and legal pages
- Existing CV Studio retained as a specialist application and rebranded with NVConsult navigation
- Secure PHP/MySQL API and CMS foundation
- Database schema and production seed data
- 12 destination records, migrated content/pathways/jobs/settings from the prior implementation
- Media library, reusable components, templates, collections and page sections
- Check My Options questions/rules
- Booking configuration for Cal.com
- Social accounts and native share composers
- Server-side AI proxy; no AI API key in frontend
- Newsletter subscription API
- Analytics event API and audit log
- PWA/service-worker foundation
- Original image assets retained
- Original JS/CSS reference modules retained under `legacy-original/` except the insecure chatbot credential file

## Deployment
Use staging first. Back up the live website and database. Import `database/schema.sql`, then `database/seed_production.sql`. Configure `api/config.php` from `api/config.example.php` with real secrets. Create the first administrator using `api/create_admin.php` and remove/disable the installer afterward.

## Production secrets
Do not commit database, AI, OAuth, SMTP or social API credentials. Rotate the AI credential exposed by the old chatbot.js before deployment.

## Content safety
Imported/AI-assisted immigration information requires human verification before publication. Do not publish expired or unverified job listings as current. Keep official sources and last-verified dates for policy content.
