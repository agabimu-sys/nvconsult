# Original NVConsult frontend reference

This folder preserves the original JavaScript/CSS modules for developer reference and migration audit. They are **not loaded by the rebuilt public pages**.

The original browser-exposed chatbot credential was intentionally not copied. The production chatbot uses `api/chat.php` and a server-side provider credential.
